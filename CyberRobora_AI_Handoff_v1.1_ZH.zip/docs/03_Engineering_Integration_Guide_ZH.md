# CyberRobora AI 助手
## 工程集成指南
版本 1.1 中文版 | 2026 年 9 月 10 日 | 实施交接材料，不代表已通过生产上线验收

中文版说明：本文保留原 v1.1 报告的范围、结果与限制。文中的“本次检查／验证”均指原报告记录的工作；本次仅翻译交接资料，没有新增功能、重跑工程测试或实施部署。

## 1. 集成方案
继续使用 React 作为游戏前端、Node/Express 作为游戏后端、PostgreSQL 作为游戏数据库，并将 Python 作为独立的模型适配服务。聊天请求使用现有游戏 API 的源地址，让浏览器能够沿用限定于该主机的游戏会话 Cookie。

| 组件 | 职责 | 不能作出的假设 |
| --- | --- | --- |
| React 前端 | 机器人按钮、面板、服务商选择、聊天界面 | 前端不保管模型密钥，也不能提供具有权威性的游戏结果 |
| Node 游戏后端 | 会话、聊天网关、访问与预算控制，以及未来的题目上下文查询 | 匿名会话不等于具名用户登录 |
| Python 服务 | 指令、固定游戏参考资料、服务商请求 | 除非通过明确的接口向其提供上下文，否则它无法访问游戏数据库 |
| PostgreSQL | 现有游戏情境、选择与进度 | 数据库与 Python 同属一个项目，并不意味着两者已经连通 |
| Qwen / Groq | 托管模型推理 | 上下文保留存在上限，具体行为取决于服务商 |

ARCHITECTURE_DIAGRAM

浏览器通过 GET {GAME_API}/api/chat/models 和 POST {GAME_API}/api/chat/chat 发起请求。重复的 chat 路径后缀用于保持客户端现有的 models/chat 接口约定。Node 使用仅供服务端使用的服务密钥，将请求转发至 Python 的 /models 和 /chat。随后，Python 仅调用用户选中的模型服务商。

## 2. 交接包结构与使用范围
| 路径 | 用途 |
| --- | --- |
| frontend/ | 可完整运行的实验版本快照；不要用它覆盖整个正式仓库 |
| chat-service/ | Python 源码、参考知识、依赖清单、测试脚本和 Dockerfile |
| patches/frontend-integration.patch | 相对于最新上传的前端压缩包（2）的聊天功能改动 |
| patches/frontend-changed-files.json | 用于合并的精确文件清单 |
| backend-integration/ | 参考网关源码、测试和应用挂载补丁 |
| docs/ | 报告、上下文接口约定和冒烟测试清单 |
| evidence/ | 本地验证日志，明确区分模拟验证与真实服务验证 |

压缩包有意排除了已安装的依赖、私有环境配置文件、Git 元数据和构建产物。原项目应保留已有文档、CI 工作流和 Git LFS 规则。交接包中的前端快照未包含部分此类历史文件；这并不表示应当删除正式仓库中的对应文件。

## 3. 前端开发人员操作步骤
将正式前端仓库克隆到新的工作目录，更新团队约定的基准分支，然后创建功能分支。以下命令从仓库的默认分支开始；如果团队约定的基准分支不同，请先切换到该分支。
```powershell
git clone https://github.com/FIT5120-26S2-TA36/The-Quest-of-Cyberia-frontend.git
Set-Location The-Quest-of-Cyberia-frontend
git switch -c feature/cyberrobo-chat
```
随包提供的补丁仅包含文本改动。在前端仓库根目录中，使用补丁文件的绝对路径运行 git apply --check。只有检查通过后，才能应用补丁。如果正式源码已有后续变化，应根据文件清单逐项移植这些小范围改动，不要强行应用补丁或覆盖整个应用。
```powershell
git apply --check "C:\path\to\handoff\patches\frontend-integration.patch"
git apply "C:\path\to\handoff\patches\frontend-integration.patch"
npm.cmd ci
npm.cmd run typecheck
npm.cmd test
npm.cmd run build
npm.cmd run check:bundle-integrity
```
如果地图图片仍是 Git LFS 指针文件，请使用仓库已配置的 LFS 访问方式运行 git lfs pull，或将随包提供的、与原文件完全一致的 PNG 复制到 src/assets/world/cyberia-map.png。保留 .gitattributes。图片恢复操作与文本补丁是分开的。

保留 README 的现有内容，并在合适的章节说明新增配置。保留原有 package-lock.json：聊天集成没有新增 npm 依赖。检查 package.json/vite.config.ts 中仅供本地使用的监听主机改动；生产环境的静态构建不使用 Vite 的监听服务。

在预发布环境中，将 VITE_CHAT_API_BASE_URL 设为 VITE_API_BASE_URL 所使用的同一源地址，并在后面加上 /api/chat。以下仅为占位示例：
```text
VITE_API_BASE_URL=https://YOUR-GAME-API
VITE_CHAT_API_BASE_URL=https://YOUR-GAME-API/api/chat
```
请使用现有 API 的真实 HTTPS 主机地址，不要使用上述占位内容或 localhost。设置该变量后，客户端会随请求携带凭据。修改后需要重新构建并部署前端。如果未设置该变量，本地 Vite 代理会直接连接 Python，不会经过 Node 网关的控制措施。

仅提交经过审查的源码，并创建 PR（拉取请求）。TEST-5120 中的实验分支是混合了后端和前端的测试仓库；不要将整个实验分支合并到独立的前端仓库中。

## 4. 后端开发人员操作步骤
在正式后端仓库中创建功能分支。将 chat-service/ 以及参考网关源码和测试复制到适当位置。示例网关是针对已检查的 Express 代码设计的，但仍须对照正式仓库当前的 HEAD（最新提交）进行审查。挂载说明位于 backend-integration/。

现有应用使用全局 32 KiB JSON 解析器。聊天路由中允许更大请求、但仍有上限的解析器必须先于该全局解析器运行，而且此时应已具备 cookieParser 和现有的会话挂载逻辑。网关路由必须挂载在兜底 404 处理之前。现有游戏路由的全局 32 KiB 限制应保持不变。

将 CHAT_SERVICE_URL 设为 Python 服务的私有基础地址，将 CHAT_SERVICE_KEY 设为与 Python 配置相同的高熵凭据（难以猜测的随机密钥）。不要在 CHAT_SERVICE_URL 后追加 /chat。现有 FRONTEND_ORIGIN 必须与真实前端源地址完全一致。Node 不接收 Qwen 或 Groq 的模型服务商密钥。

参考网关会检查所选路由、浏览器 Origin、JSON 格式和大小、已挂载的会话、允许的请求字段，以及 Qwen 响应 ID 的归属。它设置了请求处理时限，并返回安全的错误信息。其请求频率计数和响应 ID 跟踪均保存在单个进程内，且只是临时状态。参考预发布配置应使用一个 Node 进程或副本；在将此设计扩展为多个副本之前，需要引入 Redis 等共享状态存储。

现有会话中间件会创建匿名游戏会话。它的 Cookie 用于保持会话连续性，不用于验证用户身份。公开发布前，需要明确允许使用的人群和模型服务商预算，按需实施基础设施层面的滥用防护，并审查参考实现中的具体限制。不要将 CORS 或匿名会话视为费用可控的保证。

运行现有的 Node 测试、类型检查和构建，以及随包提供的网关测试。确认 Python 停止时，游戏情境和流程仍能正常运行。创建后端 PR，并将 Python 部署和配置改动与原有游戏行为的改动分别说明。

## 5. 在现有 AWS 架构中部署
仓库文档描述的架构包含 Amplify 前端、CloudFront API、ALB、ECS/Fargate 和 RDS。这是基于源码资料确定的部署基线，并非对当前 AWS 环境的实际审计。未经团队决定，不应使用之前关于 Railway/Vercel 的通用建议替换现有脚本。

Node 的 Dockerfile 目前只运行 Node。使用 chat-service/Dockerfile 构建 Python 服务。该 Dockerfile 在容器内绑定 8000 端口，以非 root 用户运行，并通过 /health 进行健康检查。它读取运行时配置，包含 game_knowledge.txt，且不会将密钥写入镜像。本次工作尚未验证其 Docker 构建和云端启动。

如需进行本地容器冒烟测试，请先根据模板填写私有的 chat-service/.env 文件。设置 CHAT_ENV=production，并使用至少 32 个字符的服务密钥。以下命令只会将 Python 端口暴露到本机回环地址：
```powershell
docker build -t cyberrobora-chat:handoff-v1.1 .\chat-service
docker run --rm --env-file .\chat-service\.env `
  -p 127.0.0.1:8000:8000 cyberrobora-chat:handoff-v1.1
```
此时，运行在宿主机上的 Node 进程可以将 http://127.0.0.1:8000 用作 CHAT_SERVICE_URL。处于独立网络命名空间中的 Node 容器无法通过该回环地址访问 Python；应改为配置私有容器或服务主机名。

对于 AWS，单独部署一个私有 Python ECS 服务是合适的初始方案：准备 Python 镜像和任务定义修订版本、机密配置、访问模型服务商的出站网络、私有服务发现，以及仅允许 Node 任务访问 8000 端口的安全组。保留原有 Node 数据库迁移任务。采用团队选定的任务平台和架构；当前后端脚本构建的是 ARM64 镜像。

另一种方案是在同一 awsvpc 任务中运行 Python 伴生容器（sidecar），但不要直接追加该容器：scripts/aws/common.sh 使用服务的任务定义来运行数据库迁移，等待整个任务停止，并通过数组下标读取容器。长期运行的伴生容器可能导致迁移任务一直无法结束。应先分离迁移任务定义，或有针对性地修改其生命周期与容器选择逻辑。

现有 scripts/aws/update.sh 用于更新 Node 镜像，不会创建 Python 服务、服务发现或模型密钥配置。需要记录这些基础设施改动，并纳入版本管理。在 CloudFront/ALB 上配置聊天路径：允许 GET/POST/OPTIONS，转发 Origin、Cookie 和 Content-Type，正确返回 Set-Cookie，并禁用聊天响应的共享缓存。代理超时应与网关的 65 秒处理时限和浏览器的 70 秒计时器相匹配；如果需要缩短超时，应同步缩短整条请求链的时间预算。

直接使用现有 API 源地址，可以避免新增第二个聊天主机名。通过 Amplify 重写实现同源访问也是备选方案，但团队必须同时解决游戏 Cookie 的连续性。面向浏览器的不同主机会分别接收到各自仅限该主机的 cr_session Cookie。此外，浏览器隐私设置可能阻止跨站 Cookie；应使用两个真实浏览器会话进行测试，不能只用 curl 验证。

## 6. Groq 记忆：已调整的限制与后续设计
原基线最多使用 12 组完整、成功的问答，以及 24,000 个历史字符。达到上限时，它会删除最早的完整问答对，并不会在 12 轮后终止对话。较早的消息可能仍在界面上显示，但已不再发送给模型。

本交接版本默认使用最多 50 组完整问答和 60,000 个历史字符。这两个上限均由 Python 配置控制；前端不再悄悄将容量重新限制为 12 组。界面从 /models 获取并显示容量，并在仍显示于界面的较早消息已超出模型上下文范围时提示用户。最新问题和固定指令属于额外输入，不计入历史字符额度。

这些数值是上限，并不保证能保留全部 50 组问答。字符上限、服务商 token 上限或配额可能会先达到。每次重新发送更多历史记录会增加输入用量，还可能增加延迟或触发服务商限制。字符数不等于 token 数。重新加载页面、点击“新对话”或切换模型服务商，仍会清空客户端的对话状态。

Groq 当前的 Responses 文档将 store 和 previous_response_id 列为不支持的参数，因此该适配器会显式发送保留下来的历史消息。Qwen 使用已存储响应的续接机制，并重新发送当前指令。其续接同样受服务商行为和可用性限制，不属于永久记忆。参考：[Groq Responses](https://console.groq.com/docs/responses-api) 和 [Qwen Responses](https://www.alibabacloud.com/help/en/model-studio/qwen-api-via-openai-responses)。

若需要更长期的回忆能力，下一阶段应按会话将对话保存到由服务端管理的存储中，保留近期消息，为较早的轮次生成可回溯原文的摘要，并在需要时检索相关历史内容。摘要可能遗漏或歪曲细节，因此不能宣称这是无损记忆。实施前应明确保留期限、删除机制和跨服务商共享规则。上述存储与检索阶段属于设计建议，不包含在本次发布中。

## 7. 解释当前题目：明确的下一步集成工作
现有聊天请求仅包含 provider、message、previous_response_id 和 history。请求中没有附加当前题目、情境标识符、已选答案、已提交结果或数据库查询结果。Python 服务只读取静态的 game_knowledge.txt。将这些代码移入正式仓库，不会改变这一事实。

需要区分两种现象：如果游戏本身无法加载题目，应检查 Node、数据库和 API 配置；如果游戏可以显示题目，但机器人无法解释“这道题”，缺少的是题目上下文连接。当前可以将可见题目文本粘贴到聊天中作为辅助，但这些仍是用户提供的上下文，并不是正式后端提供的证据。

计划中的 v2 接口边界见 docs/Current_Question_Context_CONTRACT_ZH.md。前端应只发送当前已下发的情境或旅程引用。后端通过现有会话验证归属，获取用户可见的题目和证据，并根据服务端状态判断所处阶段。提交答案之前，应排除隐藏答案和结果。选择提交并正式确认后，再附加服务端确认的选择、结果和解释。随后，Python 将这些受限的上下文视为参考数据，而非指令。

不要信任浏览器提供的“答案正确”标记、分数或任意情境 ID。不要将数据库转储或生产数据库凭据传给模型。不要假设 GET /scenarios/next 是只读的上下文查询：再次下发题目可能改变状态，或选中不同的题目变体。应通过经过会话授权的服务方法，复用已经下发的题目记录。

当前指令刻意避免在用户作出选择前透露隐藏结果。如果产品希望采用另一套辅导策略，应将其写入文档并进行测试。经过验证的答后解释应与答前提示划分为不同阶段。本次发布的网关有意只接受当前聊天接口约定，因此，未来增加 question_context 字段时，需要同步修改数据结构、网关、前端和测试。

## 8. 验收、发布与回滚
预发布环境必须检查以下项目：两个模型服务商均能回复；跨会话使用 Qwen 响应续接时会被拒绝；超过 12 组问答后，Groq 仍能记住较早提及的一条简短事实；新对话或切换模型会清空上下文；无效 JSON、无效服务商或超大历史记录会被拒绝；过期或忙碌的会话会收到可恢复的错误；请求频率限制、超时和网络失败得到安全处理；聊天响应不会被缓存或共享；浏览器中不存在服务密钥；Python 仅能通过私有网络访问；正常游戏情境仍可运行。

交接包包含本地自动化验证证据。这些测试并不能证明真实模型服务商、实际账户配额、Windows 和浏览器行为、生产 Cookie、AWS 安全组、CDN 规则、Docker 构建以及云端发布均已通过验证。当前题目解释、持久记忆和推荐功能不是 v1.1 中已经实现的验收项目，应单独跟踪。

按以下顺序发布：批准 API 接口约定；合并已审查的功能 PR；私有部署 Python；部署 Node 网关并设置运行时配置；使用网关 URL 重新构建前端；完成预发布验收；将约定的前端、Node 和 Python 版本配套发布。记录提交 SHA、镜像标签、实际部署 URL、测试人员和日期。

回滚时，重新部署上一版前端构建和 Node 镜像，然后在 Python 服务无人使用时将其缩容。不要通过将线上构建的 VITE_CHAT_API_BASE_URL 设为空来回滚：空值会选择仅供本地使用的 /chat-api 路径。这些改动无需数据库迁移。未来若增加聊天持久化，需要单独制定数据库迁移和回滚方案。

## 9. 来源与证据
源仓库：https://github.com/skyzzz-zzz/TEST-5120/tree/experiment/cyberrobo-chat 。9 月 10 日检查的已发布实验提交为 9042488627eb21b99fbeda4427de8f2961f2d48a。本交接材料是额外制作的本地交接包，并不是仓库中新发布的提交。

通过当前可用连接无法读取正式前端和后端仓库（返回 404）；应用补丁之前，请核实其当前分支。上述基础设施信息来自已检查的 docs/deployment/aws-architecture.md、Dockerfile 和 scripts/aws/ 文件。外部参考：[Vite 环境配置](https://vite.dev/guide/env-and-mode)、[Vite 代理选项](https://vite.dev/config/server-options)、[Amplify 重写](https://docs.aws.amazon.com/amplify/latest/userguide/redirects.html)和 [ECS 任务网络](https://docs.aws.amazon.com/AmazonECS/latest/developerguide/task-networking-awsvpc.html)。
