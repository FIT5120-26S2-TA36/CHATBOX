# CyberRobora AI Assistant
## Installation and Team Handover Report
Version 1.1 | 10 September 2026 | Audience: frontend, backend and model developers

## 1. What this package delivers
The package connects the existing CyberRobo game buttons to a Python service that calls Qwen or Groq. It includes a working frontend snapshot, the Python adapter, a reference Node gateway, patches and verification evidence. It does not contain trained model weights: inference is provided by external model APIs.

The user has reported that the local game now opens successfully. Earlier user-supplied results demonstrated successful Qwen requests and conversation continuation. This handoff adds configurable Groq history and deployment support; those new files have not been installed on the user's Windows machine or deployed to the production site by this run.

| Deliverable | Recipient | First action |
| --- | --- | --- |
| frontend/ and patches/frontend-integration.patch | Frontend developer | Review the patch against the current frontend branch |
| chat-service/ | Model and backend developers | Run the Python checks and configure server-side credentials |
| backend-integration/ | Backend developer | Review the gateway and its mount patch before integration |
| docs/02_Code_Change_Report_EN.md | Reviewer | Check which changes belong to the chat feature |
| docs/03_Engineering_Integration_Guide_EN.md | Both developers | Agree on API origin, session behavior and release steps |
| evidence/ | Test owner | Read local test results and complete the staging acceptance list |

Recommendation/learner profiling is not implemented in this package. Current-question context is also not connected; Section 7 of the engineering guide defines the next integration contract.

## 2. Prerequisites and configuration
Use the frontend's existing Node.js 22.x requirement. Python 3.13 matches the user's local environment; create a separate virtual environment. Git is needed for branch/PR work. Docker is optional for a container-based staging deployment. A working game backend and its PostgreSQL database remain necessary for gameplay and game sessions.

| Variable | Set in | Meaning |
| --- | --- | --- |
| DASHSCOPE_API_KEY | Python runtime | Qwen credential |
| DASHSCOPE_BASE_URL | Python runtime | Exact workspace endpoint already verified by the model owner |
| QWEN_MODEL | Python runtime | Default qwen3.7-plus; verify access in the team's account |
| GROQ_API_KEY | Python runtime | Groq credential; optional locally |
| GROQ_MODEL | Python runtime | Default openai/gpt-oss-20b, served by Groq |
| GROQ_HISTORY_PAIRS | Python runtime | Default 50; allowed 1-100 complete exchanges |
| GROQ_HISTORY_CHARACTERS | Python runtime | Default 60000; allowed 1000-100000 |
| CHAT_ENV | Python runtime | development locally; production for hosted service |
| CHAT_SERVICE_KEY | Python and Node only | Shared internal credential; at least 32 characters in production |
| CHAT_SERVICE_URL | Node runtime | Fixed private Python base URL, without /chat |
| VITE_API_BASE_URL | Frontend build | Existing public game API origin |
| VITE_CHAT_API_BASE_URL | Frontend build | Same game API origin followed by /api/chat |

Provider keys and the internal service key must never be placed in frontend variables or committed files. The Python .env.example is a template, not a secret. Python does not automatically load .env: use process environment variables, the hosting secret settings, or Docker --env-file.

## 3. Fresh local installation on Windows
Extract the ZIP into a new directory, for example C:\Users\zyc\CyberRobora-AI-Handoff-v1.1. Use a new directory so existing local changes are preserved. The following commands assume that directory name. Run one command at a time; do not copy PowerShell prompt text.

In PowerShell window A:
```powershell
Set-Location "$env:USERPROFILE\CyberRobora-AI-Handoff-v1.1\chat-service"
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-test.txt
```

Load already saved Windows user settings without displaying credentials:
```powershell
$env:DASHSCOPE_API_KEY = [Environment]::GetEnvironmentVariable("DASHSCOPE_API_KEY", "User")
$env:DASHSCOPE_BASE_URL = [Environment]::GetEnvironmentVariable("DASHSCOPE_BASE_URL", "User")
$env:GROQ_API_KEY = [Environment]::GetEnvironmentVariable("GROQ_API_KEY", "User")
```
If the Qwen endpoint was not saved, set DASHSCOPE_BASE_URL to the exact verified workspace endpoint supplied privately by the model owner. If a key has not yet been saved, enter it locally with Read-Host -AsSecureString and assign it to the process environment; never paste it into a report or source file.

For the direct local experiment, leave the internal gateway key unset:
```powershell
$env:CHAT_ENV = "development"
$env:CHAT_SERVICE_KEY = ""
$env:GROQ_HISTORY_PAIRS = "50"
$env:GROQ_HISTORY_CHARACTERS = "60000"
.\.venv\Scripts\python.exe check_api.py
.\.venv\Scripts\python.exe -m uvicorn api_server:app --host 127.0.0.1 --port 8000
```
The automated checks use fake providers. They test request handling, not real-model quality. Keep window A running. Open http://127.0.0.1:8000/models: history_limits should report messages=100 and characters=60000. configured=true means a credential was loaded, not that the provider accepted it.

In PowerShell window B:
```powershell
Set-Location "$env:USERPROFILE\CyberRobora-AI-Handoff-v1.1\frontend"
npm.cmd ci
$env:VITE_CHAT_API_BASE_URL = ""
npm.cmd run dev
```
Open http://localhost:8443/map, using the port actually shown by Vite. The chat opens from the map robot. Keep both windows running. Node/backend and PostgreSQL setup follow the team's existing instructions; this package does not clone or migrate a production database.

The actual 3.7 MB map PNG is included. An original 132-byte file beginning with Git LFS metadata is a pointer, not a usable image. Preserve the official repository's LFS configuration when merging.

## 4. Upgrade the user's existing local experiment
Stop the Python and Vite processes with Ctrl+C. Keep a backup of any local edits. Copy these files from the handoff package into the matching locations under TEST-5120-Chat-Test:

- chat-service/api_server.py and chat-service/chat.html
- chat-service/check_api.py, requirements.txt and requirements-test.txt
- frontend/src/api/chatApi.ts and frontend/src/api/chatApi.test.ts
- frontend/src/components/CyberRoboChat.tsx

The complete map asset is included if the old pointer is still present. No Node game-backend change is needed for direct local chat. Reinstall Python dependencies if the environment differs from requirements.txt, restart both services, and refresh the whole page to reload model capacity. Merely changing an environment variable does not change a process that is already running.

## 5. Local acceptance and common problems
| Observation | Meaning / next action |
| --- | --- |
| localhost refuses the connection | Start the corresponding service; verify the terminal port and keep the process running |
| npm is not recognized | Install Node.js 22, reopen PowerShell, then use npm.cmd |
| Only Qwen is available | Check GROQ_API_KEY in the Python process and restart; refresh the page |
| /models returns 401 locally | An internal service key is enabled; use the Node gateway or clear it only for direct local development |
| Health succeeds but chat fails | Health does not test provider credentials, quota, model access or network connectivity |
| The map is blank | Check that cyberia-map.png is the real image, not a Git LFS pointer |
| Game questions do not load | Check the existing Node game API, VITE_API_BASE_URL and database |
| Bot cannot explain the current question | Current question context has not been wired into chat; repository location cannot fix this |
| New capacity still says 12 | The old frontend/service is running, or the browser cached /models; restart and fully refresh |

Test one English question, one Chinese question, both provider choices, Qwen continuation, Groq conversation beyond 12 short exchanges, New chat, model switching, closing/reopening, and a provider/network failure. A failed request must not silently switch providers. Compare the visible transcript with the context-limit notice during long Groq conversations.

## 6. Handover and release order
Send the ZIP and three reports to the developers through the team's usual channel. Share credentials through the team's secret-management process separately. The model owner supplies the verified model IDs, endpoint, approved game reference and a few expected-answer examples. The frontend developer owns UI and build variables; the backend developer owns gateway/session handling, hosting, networking and secrets.

Create feature branches in the official frontend/backend repositories, apply reviewed changes, run tests, and open separate PRs. Deploy to staging first: Python service, then Node gateway, then frontend build configuration. Only after real-browser and real-provider acceptance should the team release to the live environment. Uploading source to GitHub and running services in a hosting environment are separate steps.

Official repositories returned 404 to this run. Therefore no claim is made that the patches apply cleanly to their current HEAD. No official repository was changed or merged.

## 7. Reference sources
This report's file behavior is based on the inspected source and included checks. VITE-prefixed values are public build-time configuration; changing a production value requires rebuilding the frontend. See https://vite.dev/guide/env-and-mode . Provider interfaces: https://console.groq.com/docs/responses-api and https://www.alibabacloud.com/help/en/model-studio/qwen-api-via-openai-responses .
