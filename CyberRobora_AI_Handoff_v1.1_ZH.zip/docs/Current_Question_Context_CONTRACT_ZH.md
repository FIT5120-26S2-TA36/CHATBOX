# 当前题目上下文：建议的 v2 接口约定

状态：仅为接口规范，v1.1 尚未接入。

## 浏览器 -> Node（未来请求结构）
```json
{
  "provider": "qwen",
  "message": "Why was my choice risky?",
  "previous_response_id": null,
  "history": [],
  "question_reference": {
    "kind": "issued_scenario",
    "id": "SERVER_ISSUED_ID"
  }
}
```

另一种 kind 可以是 committed_journey，对应 journey ID nimbo 或 corva。发题 ID 的准确含义需要与后端负责人确认。浏览器不提供预期答案、被当作最终依据的答题阶段、分数、session ID 或提示词指令；当前游戏 session 通过 cookie 识别。

## Node -> 内部 Python 服务（未来请求结构）
```json
{
  "provider": "qwen",
  "message": "Why was my choice risky?",
  "previous_response_id": null,
  "history": [],
  "question_context": {
    "version": 1,
    "reference": "SERVER_ISSUED_ID",
    "stage": "after_submission",
    "title": "SERVER_TITLE",
    "visible_question": "SERVER_VISIBLE_QUESTION",
    "visible_clues": [],
    "visible_options": [],
    "selected_action": "SERVER_CONFIRMED_ACTION",
    "outcome": "SERVER_CONFIRMED_OUTCOME",
    "explanation": "SERVER_APPROVED_EXPLANATION"
  }
}
```

答题阶段、记录归属和结果都来自服务器记录。提交答案前，应移除 selected_action、outcome、explanation，以及所有隐藏的结果资料，只提供玩家当前可见的内容。应限制序列化后的参考上下文长度，例如经过审核后，先采用 8,000 字符的上限；不要无提示地截断涉及安全的重要解释。区分资料版本与题目引用；切换题目时必须替换当前上下文，不能继续把旧题目作为当前事实依据。

## 分工

- 前端：从 Mission／Investigation／Decision／Outcome 页面的状态中，取出已经展示的题目或 journey 引用，传给聊天控制组件；没有上下文时，要明确处理。
- 后端：在当前 session 内解析并校验引用的访问权限，不重新发放场景。根据答题前后阶段提取允许使用的数据，只通过经过身份验证的内部服务接口发送。
- 模型负责人：扩展 Python 请求结构，把有长度限制的上下文作为参考资料加入模型请求。用户问题与系统规则分开处理。缺少上下文时给出明确回答；以保存的结果解释为依据，不由模型编造评分。
- 测试负责人：验证答题前提示、提交后结果解释、题目切换、拒绝其他 session 的未授权引用、拒绝客户端伪造正确性、上下文缺失，以及线索内含类似提示注入指令的情况。

仅为了解释当前一道题，不需要导出整个数据库，不需要给 Python 新增数据库凭据，也不需要检索索引或推荐系统。持久化记忆和题目推荐仍是独立交付项。
