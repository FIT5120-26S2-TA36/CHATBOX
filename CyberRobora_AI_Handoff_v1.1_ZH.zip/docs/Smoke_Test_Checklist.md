# Staging smoke test record
Status: not executed in this environment. Fill Tester / Date / Build / Evidence / Actual result.

| ID | Test | Expected result |
|---|---|---|
| S01 | Open map and existing robot | Real map displays; chat opens with keyboard and mouse |
| S02 | Qwen first question + follow-up | Correct provider selected; earlier short fact available |
| S03 | Groq 14 short exchanges + earliest-fact question | No old 12-exchange clamp; evaluate actual recall |
| S04 | Groq character limit / 51 completed exchanges | Oldest complete pairs leave context; notice is visible |
| S05 | New chat; switch provider; browser refresh | Intended context resets; no old reply enters a new chat |
| S06 | Close/reopen and move game route | Completed transcript remains until reset/refresh |
| S07 | Foreign session Qwen continuation | Gateway rejects it before Python call |
| S08 | Invalid Origin / content type / JSON / huge body | Safe 4xx response; no upstream call |
| S09 | Repeated requests / concurrent sends | Configured limits enforced; no surprise fallback |
| S10 | Provider unavailable, timeout, invalid credential | Clear safe error; draft remains; no credential exposure |
| S11 | Two separate browser profiles | Sessions and continuations remain isolated |
| S12 | Production /api/chat request | Correct POST/JSON/status propagation; no cached response or SPA HTML |
| S13 | Inspect built browser assets/config | No provider/internal key; correct production API URL |
| S14 | Stop Python then use original game | Gameplay routes continue independently |
| S15 | Container/task deployment and rollback | Health, private reachability, migration completion, version rollback verified |

Do not mark current-question explanations PASS without the separate v2 context integration.
