# CyberRobora AI 助手
## 安装与团队交接报告
版本 1.1 中文版 | 2026 年 9 月 10 日 | 适用读者：前端、后端和模型开发人员

中文版说明：本文保留原 v1.1 报告的范围、结果与限制。文中的“本次检查／验证”均指原报告记录的工作；本次仅翻译交接资料，没有新增功能、重跑工程测试或实施部署。

## 1. 本交付包提供什么
本交付包将现有 CyberRobo 游戏按钮连接到一个 Python 服务，由该服务调用 Qwen 或 Groq。包内包含可运行的前端代码快照、Python 适配服务、供参考的 Node 网关、补丁和验证记录。本包不包含训练好的模型权重；模型推理通过外部模型 API 提供。

用户已反馈，本地游戏现在可以成功打开。用户此前提供的结果也表明，Qwen 请求和对话续接已成功运行。本次交接增加了可配置的 Groq 历史上下文和部署支持；本次操作尚未将这些新增文件安装到用户的 Windows 电脑，也未将其部署到生产站点。

| 交付内容 | 接收人员 | 首先要做的事 |
| --- | --- | --- |
| frontend/ 和 patches/frontend-integration.patch | 前端开发人员 | 对照当前前端分支审查补丁 |
| chat-service/ | 模型和后端开发人员 | 运行 Python 检查，并配置服务端凭据 |
| backend-integration/ | 后端开发人员 | 集成前审查网关及其挂载补丁 |
| docs/02_Code_Change_Report_ZH.md | 审查人员 | 确认哪些改动属于聊天功能 |
| docs/03_Engineering_Integration_Guide_ZH.md | 前端和后端开发人员 | 商定 API 源地址、会话行为和发布步骤 |
| evidence/ | 测试负责人 | 阅读本地测试结果，并完成预发布环境验收清单 |

本包尚未实现推荐功能或学习者画像。当前题目上下文也尚未接入；工程集成指南第 7 节定义了下一步的集成约定。

## 2. 前置条件与配置
沿用前端现有的 Node.js 22.x 版本要求。Python 3.13 与用户本地环境一致；请创建独立的虚拟环境。分支和 PR（合并请求）工作需要 Git。如果通过容器部署预发布环境，可以选用 Docker。游戏运行和游戏会话仍然需要可用的游戏后端及其 PostgreSQL 数据库。

| 变量 | 设置位置 | 含义 |
| --- | --- | --- |
| DASHSCOPE_API_KEY | Python 运行环境 | Qwen 凭据 |
| DASHSCOPE_BASE_URL | Python 运行环境 | 模型负责人已验证的准确工作空间接口地址 |
| QWEN_MODEL | Python 运行环境 | 默认值为 qwen3.7-plus；需确认团队账号有权访问 |
| GROQ_API_KEY | Python 运行环境 | Groq 凭据；本地运行时可不配置 |
| GROQ_MODEL | Python 运行环境 | 默认值为 openai/gpt-oss-20b，由 Groq 提供服务 |
| GROQ_HISTORY_PAIRS | Python 运行环境 | 默认值为 50；允许保留 1-100 轮完整问答 |
| GROQ_HISTORY_CHARACTERS | Python 运行环境 | 默认值为 60000；允许范围为 1000-100000 |
| CHAT_ENV | Python 运行环境 | 本地使用 development；托管服务使用 production |
| CHAT_SERVICE_KEY | 仅 Python 和 Node | 共享的内部凭据；生产环境中至少需要 32 个字符 |
| CHAT_SERVICE_URL | Node 运行环境 | 固定的私有 Python 服务基础地址，不含 /chat |
| VITE_API_BASE_URL | 前端构建环境 | 现有的公开游戏 API 源地址 |
| VITE_CHAT_API_BASE_URL | 前端构建环境 | 与游戏 API 相同的源地址，后接 /api/chat |

服务商密钥和内部服务密钥绝不能放入前端变量或提交到版本库的文件。Python 的 .env.example 是模板，不是密钥文件。Python 不会自动加载 .env：请使用进程环境变量、托管平台的密钥设置，或 Docker --env-file。

## 3. 在 Windows 上全新安装到本地
将 ZIP 解压到一个新目录，例如 C:\Users\zyc\CyberRobora-AI-Handoff-v1.1。使用新目录可以保留现有的本地修改。下列命令假定使用该目录名。每次运行一条命令；不要复制 PowerShell 的提示符文字。

在 PowerShell 窗口 A 中运行：
```powershell
Set-Location "$env:USERPROFILE\CyberRobora-AI-Handoff-v1.1\chat-service"
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-test.txt
```

加载已保存的 Windows 用户设置，过程中不显示凭据：
```powershell
$env:DASHSCOPE_API_KEY = [Environment]::GetEnvironmentVariable("DASHSCOPE_API_KEY", "User")
$env:DASHSCOPE_BASE_URL = [Environment]::GetEnvironmentVariable("DASHSCOPE_BASE_URL", "User")
$env:GROQ_API_KEY = [Environment]::GetEnvironmentVariable("GROQ_API_KEY", "User")
```
如果尚未保存 Qwen 接口地址，请将 DASHSCOPE_BASE_URL 设置为模型负责人私下提供且已验证的准确工作空间接口地址。如果尚未保存某个密钥，请在本地使用 Read-Host -AsSecureString 输入，并将其赋值给进程环境变量；绝不要将密钥粘贴到报告或源代码文件中。

进行本地直接连接实验时，不设置内部网关密钥：
```powershell
$env:CHAT_ENV = "development"
$env:CHAT_SERVICE_KEY = ""
$env:GROQ_HISTORY_PAIRS = "50"
$env:GROQ_HISTORY_CHARACTERS = "60000"
.\.venv\Scripts\python.exe check_api.py
.\.venv\Scripts\python.exe -m uvicorn api_server:app --host 127.0.0.1 --port 8000
```
自动化检查使用模拟服务商，验证的是请求处理逻辑，而非真实模型的回答质量。保持窗口 A 运行。打开 http://127.0.0.1:8000/models：history_limits 应显示 messages=100 和 characters=60000。configured=true 表示已加载凭据，不代表服务商已接受该凭据。

在 PowerShell 窗口 B 中运行：
```powershell
Set-Location "$env:USERPROFILE\CyberRobora-AI-Handoff-v1.1\frontend"
npm.cmd ci
$env:VITE_CHAT_API_BASE_URL = ""
npm.cmd run dev
```
打开 http://localhost:8443/map；端口请以 Vite 实际显示的值为准。点击地图上的机器人即可打开聊天。保持两个窗口都在运行。Node 后端和 PostgreSQL 的配置请遵循团队现有说明；本包不会克隆或迁移生产数据库。

包内已包含实际的 3.7 MB 地图 PNG 图片。原先那个以 Git LFS 元数据开头、大小为 132 字节的文件只是指针，不是可用图片。合并代码时，请保留官方仓库的 LFS 配置。

## 4. 升级用户现有的本地实验
使用 Ctrl+C 停止 Python 和 Vite 进程。备份所有本地修改。将交付包中的以下文件复制到 TEST-5120-Chat-Test 下的对应位置：

- chat-service/api_server.py 和 chat-service/chat.html
- chat-service/check_api.py、requirements.txt 和 requirements-test.txt
- frontend/src/api/chatApi.ts 和 frontend/src/api/chatApi.test.ts
- frontend/src/components/CyberRoboChat.tsx

如果旧的图片指针文件仍然存在，可使用包内提供的完整地图资源。本地直接聊天不需要修改 Node 游戏后端。如果环境中的 Python 依赖与 requirements.txt 不一致，请重新安装依赖。随后重启两个服务，并完整刷新页面，以重新加载模型容量信息。仅修改环境变量不会改变已经运行中的进程。

## 5. 本地验收与常见问题
| 现象 | 含义或下一步操作 |
| --- | --- |
| localhost 拒绝连接 | 启动对应服务；核对终端显示的端口，并保持进程运行 |
| 系统无法识别 npm | 安装 Node.js 22，重新打开 PowerShell，然后使用 npm.cmd |
| 只能选择 Qwen | 检查 Python 进程中的 GROQ_API_KEY 并重启服务；刷新页面 |
| 本地 /models 返回 401 | 已启用内部服务密钥；请通过 Node 网关访问，或仅在本地直接连接开发时清空该密钥 |
| 健康检查成功，但聊天失败 | 健康检查不会验证服务商凭据、额度、模型访问权限或网络连通性 |
| 地图为空白 | 检查 cyberia-map.png 是否为真实图片，而非 Git LFS 指针 |
| 游戏题目无法加载 | 检查现有的 Node 游戏 API、VITE_API_BASE_URL 和数据库 |
| 机器人无法解释当前题目 | 当前题目上下文尚未接入聊天；改变仓库位置无法解决此问题 |
| 新容量仍显示为 12 | 旧版前端或服务仍在运行，或浏览器缓存了 /models；请重启并完整刷新页面 |

请测试以下场景：一个英文问题、一个中文问题、两种服务商选择、Qwen 对话续接、Groq 超过 12 轮的简短问答、新建聊天、切换模型、关闭后重新打开，以及服务商或网络故障。请求失败时，不得在没有提示的情况下切换服务商。进行较长的 Groq 对话时，请对照页面可见的聊天记录与上下文限制提示。

## 6. 交接与发布顺序
通过团队惯用渠道，将 ZIP 和三份报告发送给开发人员。凭据应通过团队的密钥管理流程单独共享。模型负责人提供已验证的模型 ID、接口地址、经批准的游戏参考资料，以及几个预期回答示例。前端开发人员负责界面和构建变量；后端开发人员负责网关、会话处理、托管、网络和密钥。

在官方前端和后端仓库中创建功能分支，应用已审查的改动，运行测试，并分别创建 PR。先部署到预发布环境：依次部署 Python 服务、Node 网关，再配置前端构建。只有通过真实浏览器和真实服务商的验收后，团队才应发布到正式环境。将源代码上传到 GitHub 与在托管环境中运行服务，是两个独立步骤。

本次运行访问官方仓库时收到 404 响应。因此，本报告不声称这些补丁可以直接应用到官方仓库当前的 HEAD（分支最新提交）。本次没有修改或合并任何官方仓库。

## 7. 参考来源
本报告对文件行为的说明基于已检查的源代码和随包提供的检查程序。以 VITE 为前缀的值属于公开的构建时配置；修改生产环境中的这些值后，需要重新构建前端。参见 https://vite.dev/guide/env-and-mode 。服务商接口文档：https://console.groq.com/docs/responses-api 和 https://www.alibabacloud.com/help/en/model-studio/qwen-api-via-openai-responses 。
