# CyberRobora AI Assistant
## Engineering Integration Guide
Version 1.1 | 10 September 2026 | Implementation handoff, not production sign-off

## 1. Integration decision
Keep React as the game frontend, Node/Express as the game backend, PostgreSQL as the game database, and Python as a separate model adapter. Use the existing game API origin for chat so the browser can use the same host-scoped game session cookie.

| Component | Responsibility | Must not assume |
| --- | --- | --- |
| React frontend | Robot button, panel, selected provider, chat UI | It does not own model keys or authoritative results |
| Node game backend | Session, chat gateway, access/budget controls, future question-context lookup | An anonymous session is not a named-user login |
| Python service | Instructions, fixed game reference, provider requests | It cannot see the game database unless an explicit interface supplies context |
| PostgreSQL | Existing game scenarios, decisions and progress | Being in the same project does not connect it to Python |
| Qwen / Groq | Hosted inference | Context retention is bounded and provider-specific |

ARCHITECTURE_DIAGRAM

Browser requests use GET {GAME_API}/api/chat/models and POST {GAME_API}/api/chat/chat. The repeated chat suffix preserves the existing models/chat client contract. Node forwards to Python /models and /chat with a server-only service key. Python then calls only the selected provider.

## 2. Package layout and supported use
| Path | Purpose |
| --- | --- |
| frontend/ | Complete runnable experiment snapshot; do not overwrite the whole official repository with it |
| chat-service/ | Python source, reference knowledge, requirements, test script and Dockerfile |
| patches/frontend-integration.patch | Chat changes relative to latest uploaded frontend archive (2) |
| patches/frontend-changed-files.json | Exact merge inventory |
| backend-integration/ | Reference gateway source, tests and app mounting patch |
| docs/ | English reports, context contract and smoke checklist |
| evidence/ | Local verification logs, with fake-vs-live boundaries |

The archive intentionally excludes dependencies, private environment files, Git metadata and build output. The original project keeps its existing documentation, CI workflows and Git LFS rules. The package's frontend snapshot omits some of those historical files; their absence is not a deletion instruction.

## 3. Frontend developer procedure
Clone the actual frontend repository into a new working directory, update the agreed base branch and create a feature branch. The commands below start from the repository default branch; switch to the agreed team base first if it differs.
```powershell
git clone https://github.com/FIT5120-26S2-TA36/The-Quest-of-Cyberia-frontend.git
Set-Location The-Quest-of-Cyberia-frontend
git switch -c feature/cyberrobo-chat
```
The supplied patch is text-only. From the frontend repository root, run git apply --check with the absolute patch path. Apply it only if that succeeds. If the official source has moved on, port the small changes using the inventory rather than forcing a patch or overwriting the application.
```powershell
git apply --check "C:\path\to\handoff\patches\frontend-integration.patch"
git apply "C:\path\to\handoff\patches\frontend-integration.patch"
npm.cmd ci
npm.cmd run typecheck
npm.cmd test
npm.cmd run build
npm.cmd run check:bundle-integrity
```
If the map image is still a pointer, run git lfs pull using the repository's configured LFS access, or copy the supplied exact original PNG to src/assets/world/cyberia-map.png. Keep .gitattributes. This restoration is separate from the text patch.

Preserve existing README material and describe the new configuration in its appropriate section. Preserve the original package-lock.json: the chat integration adds no npm dependency. Review the local-only host change in package.json/vite.config.ts; the production static build does not use Vite's listener.

For staging, set VITE_CHAT_API_BASE_URL to the same origin used by VITE_API_BASE_URL, followed by /api/chat. Example placeholders:
```text
VITE_API_BASE_URL=https://YOUR-GAME-API
VITE_CHAT_API_BASE_URL=https://YOUR-GAME-API/api/chat
```
Use the actual existing HTTPS API host, not these placeholders and not localhost. The client includes credentials when this variable is set. Rebuild/redeploy the frontend after changing it. When the variable is unset, the local Vite proxy goes directly to Python and does not exercise Node gateway controls.

Commit only reviewed source and open a PR. The experiment branch in TEST-5120 is a mixed backend/frontend test repository; do not merge its entire branch into the standalone frontend repository.

## 4. Backend developer procedure
Start a feature branch in the actual backend repository. Copy chat-service/ and the reference gateway source/tests into the appropriate paths. The example gateway is designed for the inspected Express code, but must be reviewed against the current official HEAD. Its mount instructions are in backend-integration/.

The existing app has a global 32 KiB JSON parser. The chat router's larger bounded parser must run before it, with cookieParser and the existing session attachment available. The gateway route needs to be mounted before the catch-all 404. Leave the global 32 KiB limit intact for existing game routes.

Set CHAT_SERVICE_URL to the private Python base URL and CHAT_SERVICE_KEY to the same high-entropy credential configured in Python. Do not append /chat to CHAT_SERVICE_URL. The existing FRONTEND_ORIGIN must match the actual frontend origin exactly. Node receives neither the Qwen nor the Groq provider key.

The reference gateway checks the selected routes, browser Origin, JSON format and size, attached session, allowed request fields, and Qwen response-ID ownership. It has a bounded deadline and safe error responses. Its rate counters and response-ID tracking are per-process and temporary. Use one Node process/replica for the reference staging setup; shared state such as Redis is needed before scaling this design across replicas.

The existing session middleware creates anonymous game sessions. Its cookie is continuity, not user authentication. Before a public release, decide the allowed audience and provider budget, implement infrastructure-level abuse controls where needed, and review the exact reference limits. Do not treat CORS or an anonymous session as a cost guarantee.

Run the existing Node tests/typecheck/build plus the included gateway tests. Verify game scenarios and journeys still work when Python is stopped. Open a backend PR with the Python deployment/configuration changes recorded separately from original gameplay behavior.

## 5. Hosting within the existing AWS design
Repository documentation describes Amplify frontend, CloudFront API, ALB, ECS/Fargate and RDS. This is a source-grounded deployment baseline, not a live AWS audit. Earlier generic Railway/Vercel suggestions should not replace these existing scripts without a team decision.

The Node Dockerfile currently runs Node only. Build Python with chat-service/Dockerfile. The Dockerfile binds port 8000 inside the container, runs as a non-root user and checks /health. It reads runtime configuration, includes game_knowledge.txt and never bakes keys into the image. Its Docker build and cloud launch remain unverified in this run.

For a local container smoke check, populate a private chat-service/.env from the template first. Use CHAT_ENV=production and a service key of at least 32 characters. This command publishes Python only to local loopback:
```powershell
docker build -t cyberrobora-chat:handoff-v1.1 .\chat-service
docker run --rm --env-file .\chat-service\.env `
  -p 127.0.0.1:8000:8000 cyberrobora-chat:handoff-v1.1
```
A host Node process can then use http://127.0.0.1:8000 as CHAT_SERVICE_URL. A Node container in a separate network namespace cannot use that loopback address to reach Python; configure a private container/service hostname instead.

For AWS, a separate private Python ECS service is a suitable first option: provision a Python image/revision, secrets, outbound provider access, private service discovery and a security group accepting port 8000 only from Node tasks. Keep the original Node migration tasks unchanged. Use the task platform/architecture selected by the team; the current backend scripts build ARM64.

A Python sidecar in the same awsvpc task is another option, but do not append it blindly: scripts/aws/common.sh runs migrations using the service task definition, waits for the entire task to stop, and reads a container by array index. A long-running sidecar can leave migration jobs running indefinitely. Separate the migration task definition or deliberately revise its lifecycle/container selection first.

The existing scripts/aws/update.sh updates the Node image. It does not provision the Python service, service discovery or model secrets. Record and version those infrastructure changes. Configure chat paths at CloudFront/ALB to allow GET/POST/OPTIONS, forward Origin, Cookie and Content-Type, return Set-Cookie correctly, and disable shared caching for chat responses. Match proxy timeouts to the gateway's 65-second deadline and the browser's 70-second timer, or lower the whole budget together.

The direct existing API-origin route avoids introducing a second chat hostname. A same-origin Amplify rewrite is an alternative only if the team also resolves game-cookie continuity. Different browser-facing hosts receive different host-only cr_session cookies. Cross-site cookies can additionally be blocked by browser privacy settings; test two actual browser sessions, not just curl.

## 6. Groq memory: resolved limit and remaining design
The baseline used at most 12 complete successful exchanges and 24,000 historical characters. It trimmed oldest complete pairs; it did not stop the conversation after 12 turns. Older messages could still be visible while no longer being sent to the model.

This handoff defaults to 50 complete exchanges and 60,000 historical characters. Python configuration controls both; the frontend no longer silently clamps capacity back to 12. The UI reports capacity from /models and tells the user when displayed older messages are outside model context. The latest question and fixed instructions are additional input, outside the historical-character allowance.

These are ceilings, not a promise to retain every one of 50 exchanges. Character limits, provider token limits and quota can be reached sooner. Resending more history increases input usage and may increase latency or trigger provider limits. Characters are not tokens. A fresh page load, New chat or provider switch still clears this client-side conversation state.

Groq's current Responses documentation lists store and previous_response_id as unsupported; this adapter therefore sends the retained history explicitly. Qwen uses stored response continuation and resends current instructions. Its continuation is also bounded by provider behavior and availability, not permanent memory. [Groq Responses](https://console.groq.com/docs/responses-api) and [Qwen Responses](https://www.alibabacloud.com/help/en/model-studio/qwen-api-via-openai-responses).

For longer-lived recall, the next phase should save conversations per session in a server-owned store, retain recent messages, summarize older turns with links back to originals, and retrieve relevant older material when needed. Summaries can omit or distort details; do not claim lossless memory. Decide retention, deletion and cross-provider sharing before implementation. That storage/retrieval phase is a design recommendation, not included in this release.

## 7. Current question explanation: explicit next integration
The existing chat request has provider, message, previous_response_id and history only. No current question, scenario identifier, chosen answer, committed result or database lookup is attached. The Python service reads only static game_knowledge.txt. Moving this code into the official repository does not change that.

Separate two symptoms: if the game itself cannot load a question, inspect Node/database/API configuration. If the game displays the question but the bot cannot explain 'this question', the missing link is question context. Pasting the visible text into chat can help today, but it remains user-reported context and is not official backend evidence.

Use docs/Current_Question_Context_CONTRACT.md for the planned v2 boundary. The frontend should send only the current issued scenario/journey reference. The backend verifies ownership through the existing session, fetches the visible question/evidence, and determines the stage from server state. Before submission, omit hidden answers and outcomes. After a committed choice, attach the server-confirmed choice/result/explanation. Python then uses that bounded context as reference data, not instructions.

Do not trust a browser-provided correct-answer flag, score or arbitrary scenario ID. Do not pass a database dump or production DB credential to the model. Do not assume GET /scenarios/next is a read-only context fetch: issuing another question may change state or select a different variant. Reuse the issued record through a session-authorized service method.

Current instructions deliberately avoid revealing hidden outcomes before a decision. If the product wants another tutoring policy, document it and test it. A verified post-answer explanation should be a distinct stage from pre-answer hints. This release's gateway intentionally accepts only the current chat contract, so the future question_context field will require coordinated schema, gateway, frontend and tests changes.

## 8. Acceptance, release and rollback
Required staging checks: both providers reply; Qwen continuation is rejected across sessions; Groq retains an early short fact past 12 exchanges; New chat/model switch clears context; invalid JSON/provider/oversized history is rejected; expired or busy sessions receive recoverable errors; rate/timeout/network failures are safe; no chat response is cached/shared; the service key is absent from the browser; Python is private; normal game scenarios still run.

The package includes local automated evidence. Real providers, live account quotas, Windows/browser behavior, production cookies, AWS security groups, CDN rules, Docker build and cloud rollout are not certified by those tests. Current-question explanations, persistent memory and recommendations are not implemented acceptance items for v1.1; track them separately.

Release in this order: approve API contract; merge reviewed feature PRs; deploy Python privately; deploy Node gateway with runtime settings; rebuild frontend with the gateway URL; complete staging acceptance; release the agreed frontend/Node/Python versions together. Record commit SHAs, image tags, live URLs, tester and date.

Rollback: redeploy the previous frontend build and Node image, then scale down the Python service if unused. Do not set VITE_CHAT_API_BASE_URL to blank in a live build as a rollback: blank selects the local-only /chat-api path. These changes require no database migration. Future chat persistence will need its own migration and rollback plan.

## 9. Sources and evidence
Source repository: https://github.com/skyzzz-zzz/TEST-5120/tree/experiment/cyberrobo-chat . Published experiment commit inspected on 10 September: 9042488627eb21b99fbeda4427de8f2961f2d48a. The handoff is an additional local package, not a new published repository commit.

Official frontend/backend repositories were not readable through the available connection (404); verify their current branches before applying patches. Infrastructure facts above come from the inspected docs/deployment/aws-architecture.md, Dockerfile and scripts/aws/ files. External references: [Vite environment configuration](https://vite.dev/guide/env-and-mode), [Vite proxy options](https://vite.dev/config/server-options), [Amplify rewrites](https://docs.aws.amazon.com/amplify/latest/userguide/redirects.html), and [ECS task networking](https://docs.aws.amazon.com/AmazonECS/latest/developerguide/task-networking-awsvpc.html).
