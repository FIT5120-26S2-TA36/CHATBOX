# Current-question context: proposed v2 contract
Status: specification only; NOT connected in v1.1.

## Browser -> Node (future schema)
```json
{
  "provider": "qwen",
  "message": "Why was my choice risky?",
  "previous_response_id": null,
  "history": [],
  "question_reference": {
    "kind": "issued_scenario",
    "id": "SERVER_ISSUED_ID"
  }
}
```
Alternative kind: committed_journey with journey id nimbo or corva. Confirm exact issued-ID semantics with the backend owner. The browser supplies no expected answer, authoritative stage, score, session ID or prompt instructions. The cookie identifies the current game session.

## Node -> private Python (future schema)
```json
{
  "provider": "qwen",
  "message": "Why was my choice risky?",
  "previous_response_id": null,
  "history": [],
  "question_context": {
    "version": 1,
    "reference": "SERVER_ISSUED_ID",
    "stage": "after_submission",
    "title": "SERVER_TITLE",
    "visible_question": "SERVER_VISIBLE_QUESTION",
    "visible_clues": [],
    "visible_options": [],
    "selected_action": "SERVER_CONFIRMED_ACTION",
    "outcome": "SERVER_CONFIRMED_OUTCOME",
    "explanation": "SERVER_APPROVED_EXPLANATION"
  }
}
```
Stage, ownership and outcome come from server records. Before submission, remove selected_action/outcome/explanation and all hidden result material. Supply only the currently visible material. Bound the serialized reference context (e.g. an initial reviewed 8,000-character budget), and do not silently truncate safety-critical explanations. Distinguish source version and question reference; changing questions must replace the current-context block, not leave an old question authoritative.

## Work assignment
- Frontend: pass the already displayed question/journey reference from Mission/Investigation/Decision/Outcome route state to the chat controller. Handle missing context plainly.
- Backend: resolve and authorize the reference in the current session without issuing another scenario. Build the before/after-answer projection and send it only over the private authenticated service boundary.
- Model owner: extend Python schema and include the bounded context as reference data. Keep user question and system policy separate. Add a clear missing-context response. Use result explanation as evidence, not model-invented grading.
- Test owner: one before-answer hint, one committed-result explanation, question switching, foreign-session reference rejection, forged client correctness rejection, missing context and prompt-injection-like text inside clues.

No database dump, new database credentials in Python, retrieval index or recommender is required just to explain one current question. Persistent memory and recommendation remain separate deliverables.
