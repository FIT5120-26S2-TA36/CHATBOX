/** @file Pre-choice content integrity and stable decision/evidence contracts. */
import { describe, expect, it } from "vitest";
import { gameSessionReducer, initialGameSession } from "../game/session";
import { dataDistrictScenario } from "./dataDistrict";
import {
  getIdentityCitadelClues,
  getIdentityCitadelDecisionContent,
  identityCitadelScenario,
} from "./identityCitadel";

function expectUnique(values: string[]) {
  expect(new Set(values).size).toBe(values.length);
}

describe("pre-choice scenario content contracts", () => {
  it("uses stable, unique clue and decision IDs", () => {
    for (const scenario of [dataDistrictScenario, identityCitadelScenario]) {
      expectUnique(scenario.clues.map(({ id }) => id));
      expectUnique(scenario.decisions.map(({ id }) => id));
    }
  });

  it("contains no locally owned consequence table", () => {
    for (const scenario of [dataDistrictScenario, identityCitadelScenario]) {
      expect(Object.keys(scenario)).not.toContain("consequences");
      expect(JSON.stringify(scenario)).not.toMatch(/outcomeLabel|saferAction|relevantEvidence/);
    }
  });

  it("limits Corva personal context to the active pre-choice variant", () => {
    expect(getIdentityCitadelClues(false).map(({ id }) => id)).not.toContain("personal-context");
    expect(getIdentityCitadelClues(true).map(({ id }) => id)).toContain("personal-context");
  });

  it("derives Corva evidence totals from the active variant", () => {
    expect(getIdentityCitadelClues(false)).toHaveLength(5);
    expect(getIdentityCitadelDecisionContent(false).evidenceTotalLabel).toBe("5 items");
    expect(getIdentityCitadelClues(true)).toHaveLength(6);
    expect(getIdentityCitadelDecisionContent(true).evidenceTotalLabel).toBe("6 items");
  });

  it("keeps stable decisions produced by valid reducer transitions", () => {
    const dataStarted = gameSessionReducer(initialGameSession, {
      type: "START_DATA_DISTRICT_INVESTIGATION",
    });
    const dataSession = gameSessionReducer(dataStarted, {
      type: "CONFIRM_DATA_DISTRICT_DECISION",
      decision: "customise",
    });
    expect(dataDistrictScenario.decisions.map(({ id }) => id)).toContain(
      dataSession.dataDistrictDecision,
    );
    const dataCompleted = gameSessionReducer(dataSession, { type: "COMPLETE_DATA_DISTRICT" });
    const corvaStarted = gameSessionReducer(dataCompleted, { type: "START_CORVA_INVESTIGATION" });
    const corvaSession = gameSessionReducer(corvaStarted, {
      type: "CONFIRM_CORVA_DECISION",
      decision: "open-app",
    });
    expect(identityCitadelScenario.decisions.map(({ id }) => id)).toContain(
      corvaSession.corvaDecision,
    );
  });
});
