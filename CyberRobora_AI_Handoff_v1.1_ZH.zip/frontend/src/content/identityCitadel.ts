/**
 * Identity Citadel keeps generic and contextualised variants explicit. Personal details appear
 * only when committed Data District exposure enables that context, and revelation copy describes
 * plausible information flow without asserting provenance the scenario cannot establish.
 */
import type { CorvaDecision, CorvaEvidenceId } from "../game/types";
import type { DecisionScreenContent, EvidenceClue, ScenarioDefinition } from "./types";

/** Defines the shared CorvaVariant contract. */
export type CorvaVariant = "generic" | "contextualised";

function getCorvaVariant(isContextualised: boolean): CorvaVariant {
  return isContextualised ? "contextualised" : "generic";
}

/** Defines the shared identityCitadelClues value. */
export const identityCitadelClues: readonly EvidenceClue<CorvaEvidenceId>[] = [
  {
    id: "sender-address",
    label: "Sender address",
    explanation:
      "Sender domain is 'corvaexpress-delivery.net' — not the official domain of any registered Australian postal carrier.",
  },
  {
    id: "link-destination",
    label: "Link destination",
    explanation:
      "Link leads to 'corvaexpress-delivery.net/confirm/4821' — a domain different from any official carrier site.",
  },
  {
    id: "redelivery-fee",
    label: "$3.95 redelivery fee",
    explanation: "Australian postal carriers do not charge redelivery fees via a link in an email.",
  },
  {
    id: "time-pressure",
    label: "48-hour deadline",
    explanation:
      "A 48-hour deadline to act — creates urgency that reduces time to verify the sender.",
  },
  {
    id: "unexpected-parcel",
    label: "Unexpected delivery",
    explanation:
      "No delivery was expected. The message claims a parcel exists with no prior confirmation or tracking number.",
  },
  {
    id: "personal-context",
    label: "Personal details",
    explanation:
      "Message references a specific address (Grantham Street, Clayton), an order number (NB-40318), and a contact name (Priya R.) — information specific to this recipient.",
    variant: "contextualised",
  },
];

/** Returns only evidence that exists in the active Corva message variant. */
export function getIdentityCitadelClues(
  isContextualised: boolean,
): readonly EvidenceClue<CorvaEvidenceId>[] {
  return identityCitadelClues.filter(
    ({ variant }) => variant !== "contextualised" || isContextualised,
  );
}

/** Defines the shared corvaDecisionLabels value. */
export const corvaDecisionLabels: Readonly<Record<CorvaDecision, string>> = {
  "pay-fee": "Pay the $3.95 fee",
  "open-link": "Open the link just to look",
  "open-app": "Open the Corva Express app yourself",
  "delete-report": "Delete and report to Scamwatch",
};

/** Defines the shared identityCitadelDecisionContent value. */
export const identityCitadelDecisionContent: DecisionScreenContent<CorvaDecision> = {
  headerContext: "Identity Citadel · Decision",
  intro:
    "A delivery message has arrived claiming a parcel could not be delivered. It is asking you to confirm an address and pay a $3.95 redelivery fee within 48 hours.",
  legend: "Choose what you would like to do about this delivery message",
  choices: [
    {
      id: "pay-fee",
      action: corvaDecisionLabels["pay-fee"],
      description:
        "Follow the link, confirm your address, and pay the redelivery fee to arrange delivery.",
    },
    {
      id: "open-link",
      action: corvaDecisionLabels["open-link"],
      description: "Open the link to see what is there — without necessarily paying anything.",
    },
    {
      id: "open-app",
      action: corvaDecisionLabels["open-app"],
      description:
        "Find the official Corva Express app or website independently — not via this link.",
    },
    {
      id: "delete-report",
      action: corvaDecisionLabels["delete-report"],
      description: "Delete the message and submit a report to Scamwatch at scamwatch.gov.au.",
    },
  ],
  idleDialogue: '"The details feel specific. Does that make the sender genuine?"',
  selectedDialogue: '"Take a moment. Confirm when you\'re ready."',
  contextRows: [
    { label: "Source", value: "Email — Corva Express" },
    { label: "Claim", value: "Failed delivery attempt" },
    { label: "Requesting", value: "Address confirmation + $3.95 fee" },
  ],
  evidenceTotalLabel: `${identityCitadelClues.length} items`,
  note: "Real scam messages often mix genuine-looking details with false claims. There's no expected answer here — only what you would do.",
};

/** Keeps the decision summary total aligned with the evidence available in the active variant. */
export function getIdentityCitadelDecisionContent(
  isContextualised: boolean,
): DecisionScreenContent<CorvaDecision> {
  return {
    ...identityCitadelDecisionContent,
    evidenceTotalLabel: `${getIdentityCitadelClues(isContextualised).length} items`,
  };
}

export const identityCitadelScenario: ScenarioDefinition<
  EvidenceClue<CorvaEvidenceId>,
  CorvaDecision
> = {
  family: "identity-citadel",
  overview: {
    regionLabel: "Region — Identity Citadel",
    title: "The Verification Gate",
    caption: "Verification Gate — Identity Citadel",
    artworkLabel: "Illustration: Verification Gate, Identity Citadel",
    body: "The Verification Gate is where identity claims are processed — where a name, an order number, or a delivery address is checked against what someone says they are. Recently, messages have been arriving in Cyberia that seem to know specific things about their recipients. Something at the Gate is not working as it should.",
    prompt: "Can personal information prove who sent something?",
    stats: [
      { label: "Disturbance", value: "Authentication Anomaly", color: "text-coral" },
      { label: "Est. Investigation", value: "10–12 minutes", color: "text-ink" },
      { label: "Evidence Items", value: "Up to 6 items", color: "text-ink" },
      { label: "Status", value: "New disturbance — active", color: "text-indigo" },
    ],
    cyberRoboDialogue:
      '"The Verification Gate processes every identity claim that passes through Cyberia. I\'ll accompany you — but the observations are yours."',
    startLabel: "Start investigating the Identity Citadel",
    startHint: "Collect evidence before deciding",
  },
  clues: identityCitadelClues,
  decisions: identityCitadelDecisionContent.choices,
  investigationDialogue: {
    lines: [
      "Take a close look at what this message is asking for.",
      "Interesting. What else stands out?",
      "You're building up a picture. Keep going.",
      "You've examined quite a bit. Whenever you're ready.",
      "You've looked at everything. What do you make of it?",
      "You've covered it all. Take your time before deciding.",
    ],
  },
};
