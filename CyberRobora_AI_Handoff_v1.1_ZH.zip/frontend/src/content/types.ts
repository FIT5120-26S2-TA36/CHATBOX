/**
 * @file types authored content and typed learning contracts; it contains no player-owned state.
 */
import type { EvidenceId } from "../game/types";

export type ScenarioFamily = "data-district" | "identity-citadel";
/** Defines the shared ScenarioVariant contract. */
export type ScenarioVariant = "default" | "generic" | "contextualised";

/** A stable, scenario-owned observation that can be marked before a decision is committed. */
export interface EvidenceClue<Id extends EvidenceId = EvidenceId> {
  readonly id: Id;
  readonly label: string;
  readonly explanation: string;
  readonly level?: string;
  readonly presentationDescription?: string;
  readonly variant?: ScenarioVariant;
}

/** Defines the shared DecisionOption contract. */
export interface DecisionOption<Id extends string = string> {
  readonly id: Id;
  readonly action: string;
  readonly description: string;
}

/** Defines the shared CyberRoboDialogue contract. */
export interface CyberRoboDialogue {
  readonly lines: readonly string[];
}

export interface RegionStat {
  readonly label: string;
  readonly value: string;
  readonly color: string;
}

/** Defines the shared RegionOverviewContent contract. */
export interface RegionOverviewContent {
  readonly regionLabel: string;
  readonly title: string;
  readonly body: string;
  readonly prompt?: string;
  readonly caption: string;
  readonly artworkLabel: string;
  readonly stats: readonly RegionStat[];
  readonly cyberRoboDialogue: string;
  readonly startLabel: string;
  readonly startHint: string;
}

/** Defines the shared DecisionScreenContent contract. */
export interface DecisionScreenContent<DecisionId extends string> {
  readonly headerContext: string;
  readonly intro: string;
  readonly legend: string;
  readonly choices: readonly DecisionOption<DecisionId>[];
  readonly idleDialogue: string;
  readonly selectedDialogue: string;
  readonly contextRows: readonly Readonly<{ label: string; value: string }>[];
  readonly evidenceTotalLabel: string;
  readonly note: string;
}

/** Editorial contract joining stable IDs and neutral pre-choice investigation copy. */
export interface ScenarioDefinition<Evidence extends EvidenceClue, DecisionId extends string> {
  readonly family: ScenarioFamily;
  readonly overview: RegionOverviewContent;
  readonly clues: readonly Evidence[];
  readonly decisions: readonly DecisionOption<DecisionId>[];
  readonly investigationDialogue: CyberRoboDialogue;
}
