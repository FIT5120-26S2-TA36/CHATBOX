/**
 * Data District content keeps pre-choice clues observational and decision IDs stable. Consequence
 * explanations and external references are authoritative guidance shown only after commitment;
 * the committed decision is mapped to cross-region exposure in the game-session domain.
 */
import type { DataDistrictDecision, DataDistrictEvidenceId } from "../game/types";
import type { DecisionScreenContent, EvidenceClue, ScenarioDefinition } from "./types";

/** Defines the shared dataDistrictClues value. */
export const dataDistrictClues: readonly EvidenceClue<DataDistrictEvidenceId>[] = [
  {
    id: "location-always",
    label: "Location",
    level: "Always",
    presentationDescription:
      "For accurate, real-time weather at your precise location, including when Nimbo is in the background.",
    explanation:
      "Requests location access continuously — including when the app is closed or not in use.",
  },
  {
    id: "contacts-full",
    label: "Contacts",
    level: "Full access",
    presentationDescription:
      "To let you share weather alerts with people important to you and personalise your experience.",
    explanation:
      "Requests access to your full contacts list — names, phone numbers, and email addresses.",
  },
  {
    id: "photos-all",
    label: "Photos",
    level: "All Photos",
    presentationDescription:
      "So you can share your weather photos and Nimbo can personalise imagery to your area.",
    explanation:
      "Requests access to your entire photo library, not just photos you actively choose to share.",
  },
  {
    id: "notifications",
    label: "Notifications",
    level: "Allowed",
    presentationDescription:
      "For timely weather alerts, storm warnings, and personalised daily forecasts.",
    explanation: "Can send notifications at any time, including overnight and during focus hours.",
  },
  {
    id: "data-sharing",
    label: "Data Sharing",
    level: "Third parties",
    presentationDescription:
      "By continuing you agree to our Terms of Service and Privacy Policy. Your data may be shared with analytics and advertising partners to improve your experience.",
    explanation:
      "Terms state data is shared with advertising and analytics partners — not just Nimbo.",
  },
];

/** Defines the shared dataDistrictDecisionLabels value. */
export const dataDistrictDecisionLabels: Readonly<Record<DataDistrictDecision, string>> = {
  "allow-all": "Allow everything",
  "allow-later": "Allow everything now, fix it later",
  customise: "Customise the permissions",
  "use-website": "Use the website instead",
};

/** Defines the shared dataDistrictDecisionContent value. */
export const dataDistrictDecisionContent: DecisionScreenContent<DataDistrictDecision> = {
  headerContext: "Data District · Decision",
  intro:
    "Nimbo is requesting access to your location, contacts, photos, and notifications — and the right to share data with third parties.",
  legend: "Choose what you would like to do about Nimbo's permission requests",
  choices: [
    {
      id: "allow-all",
      action: dataDistrictDecisionLabels["allow-all"],
      description:
        "Grant all permissions — location, contacts, photos, and notifications — as Nimbo has requested.",
    },
    {
      id: "allow-later",
      action: dataDistrictDecisionLabels["allow-later"],
      description:
        "Install Nimbo with full access for now and plan to revisit the settings at a later point.",
    },
    {
      id: "customise",
      action: dataDistrictDecisionLabels.customise,
      description:
        "Go into settings and choose which individual permissions to grant, rather than accepting all defaults.",
    },
    {
      id: "use-website",
      action: dataDistrictDecisionLabels["use-website"],
      description: "Open nimbo.app in your browser rather than installing the app.",
    },
  ],
  idleDialogue: '"What matters to you in a situation like this?"',
  selectedDialogue: '"Take a moment. Confirm when you\'re ready."',
  contextRows: [
    { label: "App", value: "Nimbo (weather)" },
    { label: "Requesting", value: "Location (Always), Contacts, Photos, Notifications" },
    { label: "Data sharing", value: "Advertising and analytics partners" },
  ],
  evidenceTotalLabel: "5 items",
  note: "These choices reflect real decisions people make with apps every day. There's no expected answer.",
};

/** Defines the shared dataDistrictScenario value. */
export const dataDistrictScenario: ScenarioDefinition<
  EvidenceClue<DataDistrictEvidenceId>,
  DataDistrictDecision
> = {
  family: "data-district",
  overview: {
    regionLabel: "Region — Data District",
    title: "The Circuit Archives",
    caption: "Circuit Archives — Data District",
    artworkLabel: "Illustration: Circuit Archives, Data District",
    body: "The Circuit Archives are the data infrastructure backbone of Cyberia — where records flow in, are stored, and are retrieved by applications across the city. Recently, unfamiliar data packets have been moving through the system. Nothing obviously wrong, but something feels off.",
    stats: [
      { label: "Disturbance", value: "Unauthorized Data Access", color: "text-coral" },
      { label: "Est. Investigation", value: "12–15 minutes", color: "text-ink" },
      { label: "Evidence Items", value: "5 items to inspect", color: "text-ink" },
      { label: "Status", value: "Active — open for entry", color: "text-teal" },
    ],
    cyberRoboDialogue:
      "\"I'll be here as you look around. Take your time — I won't tell you what to think.\"",
    startLabel: "Start investigating the Data District",
    startHint: "Collect evidence before deciding",
  },
  clues: dataDistrictClues,
  decisions: dataDistrictDecisionContent.choices,
  investigationDialogue: {
    lines: [
      "Take your time going through what Nimbo is asking for.",
      "Interesting. Anything else worth a closer look?",
      "You're building up a picture. What are you noticing?",
      "You've examined quite a bit. Whenever you're ready.",
      "You've looked at everything. What do you make of it?",
    ],
  },
};
