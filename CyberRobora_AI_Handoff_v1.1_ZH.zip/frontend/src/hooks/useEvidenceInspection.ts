/**
 * @file useEvidenceInspection React hook and browser-capability adapter.
 */
import { useEffect, useRef, useState } from "react";

const FEEDBACK_DURATION_MS = 1_500;

/**
 * Coordinates idempotent evidence marking with the short, replaceable visual-feedback lifetime.
 * Authoritative evidence remains controlled by the caller; this hook owns no gameplay state.
 */
export default function useEvidenceInspection<EvidenceId extends string>(
  evidence: readonly EvidenceId[],
  onAddEvidence: (evidenceId: EvidenceId) => void,
) {
  const [recentlyAdded, setRecentlyAdded] = useState<EvidenceId | null>(null);
  const feedbackTimeoutRef = useRef<number | null>(null);
  const inspectedIds = new Set(evidence);

  useEffect(
    () => () => {
      if (feedbackTimeoutRef.current !== null) {
        window.clearTimeout(feedbackTimeoutRef.current);
      }
    },
    [],
  );

  function inspectEvidence(evidenceId: EvidenceId) {
    if (inspectedIds.has(evidenceId)) return;

    onAddEvidence(evidenceId);
    setRecentlyAdded(evidenceId);
    if (feedbackTimeoutRef.current !== null) {
      window.clearTimeout(feedbackTimeoutRef.current);
    }
    feedbackTimeoutRef.current = window.setTimeout(() => {
      setRecentlyAdded(null);
      feedbackTimeoutRef.current = null;
    }, FEEDBACK_DURATION_MS);
  }

  return { inspectedIds, recentlyAdded, inspectEvidence };
}
