/**
 * @file usePrefersReducedMotion React hook and browser-capability adapter.
 */
import { useEffect, useState } from "react";

const reducedMotionQuery = "(prefers-reduced-motion: reduce)";

/** Provides the public motionPreferenceIsReduced behavior used across the application. */
export function motionPreferenceIsReduced(): boolean {
  return (
    typeof window !== "undefined" &&
    typeof window.matchMedia === "function" &&
    window.matchMedia(reducedMotionQuery).matches
  );
}

/** Tracks the system motion preference while allowing an explicit component override to opt out. */
export default function usePrefersReducedMotion(enabled = true): boolean {
  const [reducedMotion, setReducedMotion] = useState(() =>
    enabled ? motionPreferenceIsReduced() : false,
  );

  useEffect(() => {
    if (!enabled || typeof window.matchMedia !== "function") return;

    const query = window.matchMedia(reducedMotionQuery);
    const handleChange = (event: MediaQueryListEvent) => setReducedMotion(event.matches);
    setReducedMotion(query.matches);

    if (typeof query.addEventListener === "function") {
      query.addEventListener("change", handleChange);
      return () => query.removeEventListener("change", handleChange);
    }

    query.addListener(handleChange);
    return () => query.removeListener(handleChange);
  }, [enabled]);

  return reducedMotion;
}
