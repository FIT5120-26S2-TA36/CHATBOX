/** @vitest-environment jsdom */

import { act, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import usePrefersReducedMotion from "./usePrefersReducedMotion";
import "../test/dom";

function createMediaQuery(initialMatches: boolean, modern = true) {
  let matches = initialMatches;
  let listener: ((event: MediaQueryListEvent) => void) | null = null;
  const addEventListener = vi.fn((_type: string, nextListener: EventListener) => {
    listener = nextListener as (event: MediaQueryListEvent) => void;
  });
  const removeEventListener = vi.fn((_type: string, removedListener: EventListener) => {
    if (listener === removedListener) listener = null;
  });
  const addListener = vi.fn((nextListener: (event: MediaQueryListEvent) => void) => {
    listener = nextListener;
  });
  const removeListener = vi.fn((removedListener: (event: MediaQueryListEvent) => void) => {
    if (listener === removedListener) listener = null;
  });
  const query = {
    get matches() {
      return matches;
    },
    media: "(prefers-reduced-motion: reduce)",
    onchange: null,
    addEventListener: modern ? addEventListener : undefined,
    removeEventListener: modern ? removeEventListener : undefined,
    addListener,
    removeListener,
    dispatchEvent: vi.fn(),
  } as MediaQueryList;

  return {
    query,
    addEventListener,
    removeEventListener,
    addListener,
    removeListener,
    setMatches(nextMatches: boolean) {
      matches = nextMatches;
      listener?.({ matches: nextMatches } as MediaQueryListEvent);
    },
  };
}

function PreferenceProbe() {
  const reducedMotion = usePrefersReducedMotion();
  return <output aria-label="Motion preference">{reducedMotion ? "reduced" : "normal"}</output>;
}

describe("usePrefersReducedMotion", () => {
  it.each([
    [false, "normal"],
    [true, "reduced"],
  ])("reads an initial %s preference", (initialMatches, expected) => {
    const controller = createMediaQuery(initialMatches);
    vi.stubGlobal(
      "matchMedia",
      vi.fn(() => controller.query),
    );

    render(<PreferenceProbe />);

    expect(screen.getByLabelText("Motion preference").textContent).toBe(expected);
  });

  it("tracks normal to reduced and reduced to normal changes", () => {
    const controller = createMediaQuery(false);
    vi.stubGlobal(
      "matchMedia",
      vi.fn(() => controller.query),
    );
    render(<PreferenceProbe />);

    act(() => controller.setMatches(true));
    expect(screen.getByLabelText("Motion preference").textContent).toBe("reduced");

    act(() => controller.setMatches(false));
    expect(screen.getByLabelText("Motion preference").textContent).toBe("normal");
  });

  it("subscribes once and removes the modern listener on unmount", () => {
    const controller = createMediaQuery(false);
    vi.stubGlobal(
      "matchMedia",
      vi.fn(() => controller.query),
    );
    const { rerender, unmount } = render(<PreferenceProbe />);

    rerender(<PreferenceProbe />);
    expect(controller.addEventListener).toHaveBeenCalledOnce();

    unmount();
    expect(controller.removeEventListener).toHaveBeenCalledOnce();
  });

  it("uses and cleans up the legacy listener when the modern API is unavailable", () => {
    const controller = createMediaQuery(false, false);
    vi.stubGlobal(
      "matchMedia",
      vi.fn(() => controller.query),
    );
    const { unmount } = render(<PreferenceProbe />);

    expect(controller.addListener).toHaveBeenCalledOnce();
    act(() => controller.setMatches(true));
    expect(screen.getByLabelText("Motion preference").textContent).toBe("reduced");

    unmount();
    expect(controller.removeListener).toHaveBeenCalledOnce();
  });
});
