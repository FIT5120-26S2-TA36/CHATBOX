/** Canonical URL identity only; gameplay progress and unlock state belong to GameSession. */
import { matchPath } from "react-router-dom";

export function regionPath(regionId: string): string {
  return `/regions/${regionId}`;
}

/** Provides the public investigationPath behavior used across the application. */
export function investigationPath(regionId: string, scenarioId: string): string {
  return `${regionPath(regionId)}/${scenarioId}`;
}

export function decisionPath(regionId: string, scenarioId: string): string {
  return `${investigationPath(regionId, scenarioId)}/decision`;
}

/** Provides the public outcomePath behavior used across the application. */
export function outcomePath(regionId: string, scenarioId: string): string {
  return `${investigationPath(regionId, scenarioId)}/outcome`;
}

/** Single source of truth for public, investigation, decision, and outcome URLs. */
export const ROUTES = {
  home: "/",
  howItWorks: "/how-it-works",
  about: "/about",
  map: "/map",
  dataDistrict: regionPath("data-district"),
  dataDistrictMission: investigationPath("data-district", "live-mission"),
  nimbo: investigationPath("data-district", "nimbo"),
  nimboDecision: decisionPath("data-district", "nimbo"),
  nimboOutcome: outcomePath("data-district", "nimbo"),
  identityCitadel: regionPath("identity-citadel"),
  corva: investigationPath("identity-citadel", "corva"),
  corvaDecision: decisionPath("identity-citadel", "corva"),
  corvaOutcome: outcomePath("identity-citadel", "corva"),
} as const;

/** Defines the shared AppRouteId contract. */
export type AppRouteId = keyof typeof ROUTES | "notFound";
export type CanonicalPath = (typeof ROUTES)[keyof typeof ROUTES];

export const canonicalRouteEntries = Object.entries(ROUTES) as Array<
  [Exclude<AppRouteId, "notFound">, CanonicalPath]
>;

/** Provides the public getRouteId behavior used across the application. */
export function getRouteId(pathname: string): AppRouteId {
  const match = canonicalRouteEntries.find(([, path]) => matchPath({ path, end: true }, pathname));
  return match?.[0] ?? "notFound";
}
