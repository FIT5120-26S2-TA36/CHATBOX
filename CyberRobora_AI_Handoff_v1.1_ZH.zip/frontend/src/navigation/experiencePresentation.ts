/**
 * Presentation lifecycle for the single hosted map experience. `handoff` keeps the map mounted
 * across cinematic completion; the state returns to inactive on the canonical map route so later
 * gameplay returns do not replay the intro.
 */
import type { AppRouteId } from "./routes";

/** Defines the shared ExperiencePresentation contract. */
export type ExperiencePresentation = "inactive" | "cinematic" | "handoff";

export function isExperienceVisible(
  presentation: ExperiencePresentation,
  routeId: AppRouteId,
): boolean {
  return presentation !== "inactive" || routeId === "map";
}

/** Provides the public isCinematicPresentation behavior used across the application. */
export function isCinematicPresentation(presentation: ExperiencePresentation): boolean {
  return presentation === "cinematic";
}
