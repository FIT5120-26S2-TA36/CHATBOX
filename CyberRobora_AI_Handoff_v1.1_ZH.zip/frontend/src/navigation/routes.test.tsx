/**
 * @file Regression scope for routes, including its externally observable contracts and edge cases.
 */
import { readFileSync } from "node:fs";
import { renderToStaticMarkup } from "react-dom/server";
import { createMemoryRouter, MemoryRouter, type InitialEntry } from "react-router-dom";
import { describe, expect, it } from "vitest";
import App from "../App";
import { gameSessionReducer, initialGameSession, type GameSession } from "../game/session";
import { canAccessRoute, getRouteRecoveryPath } from "./routeGuards";
import {
  canonicalRouteEntries,
  decisionPath,
  getRouteId,
  investigationPath,
  outcomePath,
  regionPath,
  ROUTES,
} from "./routes";

function renderRoute(path: string, initialSession?: GameSession): string {
  return renderToStaticMarkup(
    <MemoryRouter initialEntries={[path]}>
      <App initialSession={initialSession} />
    </MemoryRouter>,
  );
}

const ddStarted = gameSessionReducer(initialGameSession, {
  type: "START_DATA_DISTRICT_INVESTIGATION",
});
const ddDecision = gameSessionReducer(ddStarted, {
  type: "CONFIRM_DATA_DISTRICT_DECISION",
  decision: "allow-all",
});
const ddComplete = gameSessionReducer(ddDecision, {
  type: "COMPLETE_DATA_DISTRICT",
});
const corvaStarted = gameSessionReducer(ddComplete, {
  type: "START_CORVA_INVESTIGATION",
});
const corvaDecision = gameSessionReducer(corvaStarted, {
  type: "CONFIRM_CORVA_DECISION",
  decision: "delete-report",
});

describe("canonical application routing", () => {
  it("defines every requested canonical route centrally", () => {
    expect(ROUTES).toEqual({
      home: "/",
      howItWorks: "/how-it-works",
      about: "/about",
      map: "/map",
      dataDistrict: "/regions/data-district",
      dataDistrictMission: "/regions/data-district/live-mission",
      nimbo: "/regions/data-district/nimbo",
      nimboDecision: "/regions/data-district/nimbo/decision",
      nimboOutcome: "/regions/data-district/nimbo/outcome",
      identityCitadel: "/regions/identity-citadel",
      corva: "/regions/identity-citadel/corva",
      corvaDecision: "/regions/identity-citadel/corva/decision",
      corvaOutcome: "/regions/identity-citadel/corva/outcome",
    });
    expect(canonicalRouteEntries).toHaveLength(13);
    expect(regionPath("inbox-harbour")).toBe("/regions/inbox-harbour");
    expect(investigationPath("inbox-harbour", "scenario")).toBe("/regions/inbox-harbour/scenario");
    expect(decisionPath("social-square", "scenario").endsWith("/decision")).toBe(true);
    expect(outcomePath("social-square", "scenario").endsWith("/outcome")).toBe(true);
  });

  it("matches canonical paths and sends unknown paths to Not Found", () => {
    for (const [routeId, path] of canonicalRouteEntries) {
      expect(getRouteId(path)).toBe(routeId);
      expect(getRouteId(`${path === "/" ? "" : path}/`)).toBe(routeId);
    }
    expect(getRouteId("/regions/pirate-bay")).toBe("notFound");
    expect(getRouteId("/unknown-route")).toBe("notFound");
  });

  it("directly renders every public destination", () => {
    expect(renderRoute(ROUTES.home)).toContain("Start Adventure");
    expect(renderRoute(ROUTES.howItWorks)).toContain("How It Works");
    expect(renderRoute(ROUTES.about)).toContain("About CyberRobora");
    // Sync markup cannot await /api/session; the map holds until hydration settles.
    const mapMarkup = renderRoute(ROUTES.map);
    expect(mapMarkup).toContain("Loading field operations");
    expect(mapMarkup).not.toContain("Data District — Available for investigation");
  });

  it("renders valid Data District and Identity Citadel gameplay destinations", () => {
    expect(renderRoute(ROUTES.dataDistrict)).toContain("Data District");
    expect(renderRoute(ROUTES.dataDistrictMission, ddStarted)).toContain("Loading mission data");
    expect(renderRoute(ROUTES.nimbo, ddStarted)).toContain("Nimbo permission investigation");
    expect(renderRoute(ROUTES.nimboDecision, ddStarted)).toContain(
      "Nimbo Decision — The Quest of Cyberia",
    );
    expect(renderRoute(ROUTES.nimboOutcome, ddDecision)).toContain("Loading field operations");
    expect(renderRoute(ROUTES.identityCitadel, ddComplete)).toContain("Identity Citadel");
    expect(renderRoute(ROUTES.corva, corvaStarted)).toContain(
      "Corva delivery message investigation",
    );
    expect(renderRoute(ROUTES.corvaDecision, corvaStarted)).toContain(
      "Corva Decision — The Quest of Cyberia",
    );
    expect(renderRoute(ROUTES.corvaOutcome, corvaDecision)).toContain("Loading field operations");
  });

  it("guards inaccessible deep links without mutating progression", () => {
    const before = structuredClone(initialGameSession);
    expect(canAccessRoute("nimbo", initialGameSession)).toBe(false);
    expect(canAccessRoute("dataDistrictMission", initialGameSession)).toBe(false);
    expect(canAccessRoute("nimboOutcome", initialGameSession)).toBe(false);
    expect(canAccessRoute("identityCitadel", initialGameSession)).toBe(false);
    expect(canAccessRoute("corvaOutcome", initialGameSession)).toBe(false);
    expect(getRouteRecoveryPath("identityCitadel", initialGameSession)).toBe(ROUTES.map);
    expect(initialGameSession).toEqual(before);

    expect(canAccessRoute("nimbo", ddStarted)).toBe(true);
    expect(canAccessRoute("dataDistrictMission", ddStarted)).toBe(true);
    expect(canAccessRoute("nimboOutcome", ddDecision)).toBe(true);
    expect(canAccessRoute("identityCitadel", ddComplete)).toBe(true);
    expect(canAccessRoute("corva", corvaStarted)).toBe(true);
    expect(canAccessRoute("corvaOutcome", corvaDecision)).toBe(true);
    expect(getRouteRecoveryPath("corvaOutcome", corvaDecision)).toBeNull();
  });

  it("uses router history for natural back and forward traversal", async () => {
    const entries: InitialEntry[] = [ROUTES.home];
    const router = createMemoryRouter([{ path: "*", element: <span>route</span> }], {
      initialEntries: entries,
    });

    await router.navigate(ROUTES.map);
    await router.navigate(ROUTES.dataDistrict);
    await router.navigate(ROUTES.nimbo);
    expect(router.state.location.pathname).toBe(ROUTES.nimbo);

    await router.navigate(-1);
    expect(router.state.location.pathname).toBe(ROUTES.dataDistrict);
    await router.navigate(-1);
    expect(router.state.location.pathname).toBe(ROUTES.map);
    await router.navigate(1);
    expect(router.state.location.pathname).toBe(ROUTES.dataDistrict);
    router.dispose();
  });

  it("renders a lightweight recovery screen for unknown URLs", () => {
    const markup = renderRoute("/not-a-cyberia-route");
    expect(markup).toContain("Page not found");
    expect(markup).toContain("Return to Cyberia");
    expect(markup).toContain("Return home");
  });

  it("preserves one hosted MapExperience and keeps map UI out of URLs", () => {
    const appSource = readFileSync(new URL("../App.tsx", import.meta.url), "utf8");
    const mapSource = readFileSync(new URL("../pages/Map.tsx", import.meta.url), "utf8");

    expect(appSource.match(/<MapExperience\b/g)).toHaveLength(1);
    expect(appSource).toContain("<ExperienceHost active={showMapExperience}>");
    expect(appSource).toContain('setExperiencePresentation("handoff")');
    expect(appSource).toContain("navigate(ROUTES.map)");
    expect(mapSource).not.toContain("useNavigate");
    expect(mapSource).not.toContain("/atlas");
    expect(mapSource).not.toContain("/journal");
    expect(mapSource).not.toContain("/regions/");
  });
});
