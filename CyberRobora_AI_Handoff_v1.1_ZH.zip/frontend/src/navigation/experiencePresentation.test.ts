/**
 * @file Regression scope for experiencePresentation, including its externally observable contracts and edge cases.
 */
import { describe, expect, it } from "vitest";
import {
  isCinematicPresentation,
  isExperienceVisible,
  type ExperiencePresentation,
} from "./experiencePresentation";
import type { AppRouteId } from "./routes";

describe("persistent experience presentation", () => {
  it("keeps the map mounted for every cinematic-to-map update ordering", () => {
    const routerFirst: Array<[ExperiencePresentation, AppRouteId]> = [
      ["cinematic", "home"],
      ["cinematic", "map"],
      ["handoff", "map"],
      ["inactive", "map"],
    ];
    const presentationFirst: Array<[ExperiencePresentation, AppRouteId]> = [
      ["cinematic", "home"],
      ["handoff", "home"],
      ["handoff", "map"],
      ["inactive", "map"],
    ];

    for (const [presentation, routeId] of [...routerFirst, ...presentationFirst]) {
      expect(isExperienceVisible(presentation, routeId)).toBe(true);
    }
  });

  it("does not mount the map behind Landing or replay the cinematic on direct map", () => {
    expect(isExperienceVisible("inactive", "home")).toBe(false);
    expect(isExperienceVisible("inactive", "map")).toBe(true);
    expect(isCinematicPresentation("inactive")).toBe(false);
    expect(isCinematicPresentation("cinematic")).toBe(true);
    expect(isCinematicPresentation("handoff")).toBe(false);
  });
});
