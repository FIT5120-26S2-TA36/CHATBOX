/**
 * Route guards read canonical GameSession progress but never advance it. Public routes remain open;
 * guarded investigation/outcome URLs require their reducer-established prerequisites.
 */
import type { GameSession } from "../game/session";
import { ROUTES, type AppRouteId, type CanonicalPath } from "./routes";

/** Provides the public canAccessRoute behavior used across the application. */
export function canAccessRoute(routeId: AppRouteId, session: GameSession): boolean {
  switch (routeId) {
    case "dataDistrictMission":
    case "nimbo":
    case "nimboDecision":
      return session.dataDistrictInvestigationStarted;

    case "nimboOutcome":
      return session.dataDistrictDecision !== null;

    case "identityCitadel":
      return session.investigatedRegions.includes("data-district");

    case "corva":
    case "corvaDecision":
      return (
        session.investigatedRegions.includes("data-district") && session.corvaInvestigationStarted
      );

    case "corvaOutcome":
      return (
        session.investigatedRegions.includes("data-district") && session.corvaDecision !== null
      );

    default:
      return true;
  }
}

/** Sends incomplete or contradictory deep links to the always-safe map destination. */
export function getRouteRecoveryPath(
  routeId: AppRouteId,
  session: GameSession,
): CanonicalPath | null {
  return canAccessRoute(routeId, session) ? null : ROUTES.map;
}
