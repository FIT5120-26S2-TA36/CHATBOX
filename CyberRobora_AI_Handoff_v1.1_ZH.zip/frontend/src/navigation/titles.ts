/**
 * @file titles canonical navigation, guard, title, or presentation behavior.
 */
import type { AppRouteId } from "./routes";

export const routeTitles: Readonly<Record<AppRouteId, string>> = {
  home: "The Quest of Cyberia",
  howItWorks: "How It Works — The Quest of Cyberia",
  about: "About CyberRobora — The Quest of Cyberia",
  map: "Cyberia Map — The Quest of Cyberia",
  dataDistrict: "Data District — The Quest of Cyberia",
  dataDistrictMission: "Data District Live Mission — The Quest of Cyberia",
  nimbo: "Nimbo Investigation — The Quest of Cyberia",
  nimboDecision: "Nimbo Decision — The Quest of Cyberia",
  nimboOutcome: "Data District Outcome — The Quest of Cyberia",
  identityCitadel: "Identity Citadel — The Quest of Cyberia",
  corva: "Corva Investigation — The Quest of Cyberia",
  corvaDecision: "Corva Decision — The Quest of Cyberia",
  corvaOutcome: "Identity Citadel Revelation — The Quest of Cyberia",
  notFound: "Page Not Found — The Quest of Cyberia",
};

/** Defines the shared cinematicTitle value. */
export const cinematicTitle = "Entering Cyberia — The Quest of Cyberia";

export function getRouteTitle(routeId: AppRouteId, cinematicActive = false): string {
  return cinematicActive ? cinematicTitle : routeTitles[routeId];
}

/** Provides the public getRouteAnnouncement behavior used across the application. */
export function getRouteAnnouncement(routeId: AppRouteId, cinematicActive = false): string {
  return `${getRouteTitle(routeId, cinematicActive)}. Page loaded.`;
}
