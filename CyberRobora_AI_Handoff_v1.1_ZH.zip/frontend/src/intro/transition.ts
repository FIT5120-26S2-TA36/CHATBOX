/**
 * Presentation-only cinematic state. Normal motion advances through timed phases; reduced motion
 * begins at the narrative and completes on its single reduced duration. SKIP moves directly to
 * complete and never mutates gameplay state.
 */
export type IntroPhase =
  | "entering"
  | "narrative"
  | "cyberrobo"
  | "first-signal"
  | "map-reveal"
  | "complete";

/** Defines the shared IntroTransitionState contract. */
export interface IntroTransitionState {
  phase: IntroPhase;
}

export type IntroTransitionAction = { type: "ADVANCE" } | { type: "SKIP" };

/** Defines the shared introPhaseDurations value. */
export const introPhaseDurations: Record<Exclude<IntroPhase, "complete">, number> = {
  entering: 1400,
  narrative: 4800,
  cyberrobo: 4000,
  "first-signal": 1900,
  "map-reveal": 1400,
};

/** Defines the shared reducedMotionIntroDuration value. */
export const reducedMotionIntroDuration = 1500;

export function createIntroTransitionState(reducedMotion = false): IntroTransitionState {
  return { phase: reducedMotion ? "narrative" : "entering" };
}

/** Provides the public introTransitionReducer behavior used across the application. */
export function introTransitionReducer(
  state: IntroTransitionState,
  action: IntroTransitionAction,
): IntroTransitionState {
  if (action.type === "SKIP") return { phase: "complete" };

  const nextPhase: Record<IntroPhase, IntroPhase> = {
    entering: "narrative",
    narrative: "cyberrobo",
    cyberrobo: "first-signal",
    "first-signal": "map-reveal",
    "map-reveal": "complete",
    complete: "complete",
  };

  return { phase: nextPhase[state.phase] };
}

/** Provides the public getIntroPhaseDuration behavior used across the application. */
export function getIntroPhaseDuration(phase: IntroPhase, reducedMotion: boolean): number | null {
  if (phase === "complete") return null;
  return reducedMotion ? reducedMotionIntroDuration : introPhaseDurations[phase];
}

/** Provides the public getTimedIntroAction behavior used across the application. */
export function getTimedIntroAction(reducedMotion: boolean): IntroTransitionAction {
  return { type: reducedMotion ? "SKIP" : "ADVANCE" };
}

/** Prevents phase effects or repeated renders from reporting cinematic completion more than once. */
export function shouldReportIntroCompletion(phase: IntroPhase, alreadyReported: boolean): boolean {
  return phase === "complete" && !alreadyReported;
}
