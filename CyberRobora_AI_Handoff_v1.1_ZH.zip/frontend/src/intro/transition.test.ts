/**
 * @file Regression scope for transition, including its externally observable contracts and edge cases.
 */
import { describe, expect, it } from "vitest";
import {
  createIntroTransitionState,
  getIntroPhaseDuration,
  getTimedIntroAction,
  introTransitionReducer,
  reducedMotionIntroDuration,
  shouldReportIntroCompletion,
} from "./transition";

describe("cinematic intro transition", () => {
  it("advances through the explicit presentation phases and completes", () => {
    let state = createIntroTransitionState();

    expect(state.phase).toBe("entering");
    state = introTransitionReducer(state, { type: "ADVANCE" });
    expect(state.phase).toBe("narrative");
    state = introTransitionReducer(state, { type: "ADVANCE" });
    expect(state.phase).toBe("cyberrobo");
    state = introTransitionReducer(state, { type: "ADVANCE" });
    expect(state.phase).toBe("first-signal");
    state = introTransitionReducer(state, { type: "ADVANCE" });
    expect(state.phase).toBe("map-reveal");
    state = introTransitionReducer(state, { type: "ADVANCE" });
    expect(state.phase).toBe("complete");
  });

  it("skips immediately from every active phase", () => {
    for (const phase of [
      "entering",
      "narrative",
      "cyberrobo",
      "first-signal",
      "map-reveal",
    ] as const) {
      expect(introTransitionReducer({ phase }, { type: "SKIP" })).toEqual({
        phase: "complete",
      });
    }
  });

  it("uses a short static narrative path for reduced motion", () => {
    expect(createIntroTransitionState(true).phase).toBe("narrative");
    expect(getIntroPhaseDuration("narrative", true)).toBe(reducedMotionIntroDuration);
    expect(getTimedIntroAction(true)).toEqual({ type: "SKIP" });
  });

  it("provides stable reading time within a 13.5 second journey", () => {
    expect(getIntroPhaseDuration("entering", false)).toBe(1400);
    expect(getIntroPhaseDuration("narrative", false)).toBe(4800);
    expect(getIntroPhaseDuration("cyberrobo", false)).toBe(4000);
    expect(getIntroPhaseDuration("first-signal", false)).toBe(1900);
    expect(getIntroPhaseDuration("map-reveal", false)).toBe(1400);
    expect(reducedMotionIntroDuration).toBeLessThanOrEqual(2000);
  });

  it("reports completion exactly once", () => {
    expect(shouldReportIntroCompletion("map-reveal", false)).toBe(false);
    expect(shouldReportIntroCompletion("complete", false)).toBe(true);
    expect(shouldReportIntroCompletion("complete", true)).toBe(false);
  });

  it("does not schedule work after completion", () => {
    expect(getIntroPhaseDuration("complete", false)).toBeNull();
    expect(introTransitionReducer({ phase: "complete" }, { type: "ADVANCE" })).toEqual({
      phase: "complete",
    });
    expect(introTransitionReducer({ phase: "complete" }, { type: "SKIP" })).toEqual({
      phase: "complete",
    });
  });
});
