/**
 * @file CyberRoboSVG reusable presentation component used by routed gameplay experiences.
 */
interface Props {
  size?: number;
  className?: string;
}

/** Renders the CyberRoboSVG experience/component and coordinates its user-facing callbacks. */
export default function CyberRoboSVG({ size = 140, className = "" }: Props) {
  const h = Math.round(size * 1.55);
  return (
    <svg
      width={size}
      height={h}
      viewBox="0 0 100 155"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-label="CyberRobo, your field companion"
      role="img"
    >
      {/* Antenna post */}
      <line
        x1="50"
        y1="10"
        x2="50"
        y2="1"
        stroke="#2B2420"
        strokeWidth="1.6"
        strokeLinecap="round"
      />
      {/* Antenna tip */}
      <circle cx="50" cy="-1" r="3.5" fill="#C15738" stroke="#2B2420" strokeWidth="1.1" />
      {/* Antenna signal rings */}
      <path
        d="M44,1 Q39,-4 42,-9"
        fill="none"
        stroke="#2B2420"
        strokeWidth="0.9"
        strokeDasharray="1.5,1.5"
      />
      <path
        d="M56,1 Q61,-4 58,-9"
        fill="none"
        stroke="#2B2420"
        strokeWidth="0.9"
        strokeDasharray="1.5,1.5"
      />

      {/* Head */}
      <rect
        x="20"
        y="10"
        width="60"
        height="44"
        rx="6"
        fill="#CFD5ED"
        stroke="#2B2420"
        strokeWidth="1.6"
      />
      {/* Head inner panel line */}
      <line
        x1="20"
        y1="28"
        x2="80"
        y2="28"
        stroke="#2B2420"
        strokeWidth="0.7"
        strokeOpacity="0.25"
      />

      {/* Main eye lens */}
      <circle cx="43" cy="32" r="13" fill="#F5EFE3" stroke="#2B2420" strokeWidth="1.5" />
      <circle cx="43" cy="32" r="9" fill="#4A5A8B" stroke="#2B2420" strokeWidth="1" />
      <circle cx="43" cy="32" r="5" fill="#3B7A7B" />
      <circle cx="46" cy="28" r="2.5" fill="white" fillOpacity="0.75" />
      <circle cx="38" cy="36" r="1" fill="white" fillOpacity="0.4" />

      {/* Side indicators */}
      <rect
        x="63"
        y="18"
        width="9"
        height="9"
        rx="2"
        fill="#C15738"
        stroke="#2B2420"
        strokeWidth="1"
      />
      <circle cx="67.5" cy="22.5" r="2" fill="#EDD4CC" />
      <line
        x1="63"
        y1="31"
        x2="72"
        y2="31"
        stroke="#2B2420"
        strokeWidth="0.9"
        strokeLinecap="round"
      />
      <line
        x1="63"
        y1="34"
        x2="70"
        y2="34"
        stroke="#2B2420"
        strokeWidth="0.9"
        strokeLinecap="round"
      />
      <line
        x1="63"
        y1="37"
        x2="72"
        y2="37"
        stroke="#2B2420"
        strokeWidth="0.9"
        strokeLinecap="round"
      />

      {/* Ear panels */}
      <rect
        x="14"
        y="20"
        width="7"
        height="22"
        rx="3"
        fill="#B8C2DE"
        stroke="#2B2420"
        strokeWidth="1.2"
      />
      <rect
        x="79"
        y="20"
        width="7"
        height="22"
        rx="3"
        fill="#B8C2DE"
        stroke="#2B2420"
        strokeWidth="1.2"
      />

      {/* Neck */}
      <rect
        x="40"
        y="54"
        width="20"
        height="9"
        rx="2"
        fill="#B8C2DE"
        stroke="#2B2420"
        strokeWidth="1.4"
      />

      {/* Body */}
      <rect
        x="16"
        y="63"
        width="68"
        height="54"
        rx="6"
        fill="#CFD5ED"
        stroke="#2B2420"
        strokeWidth="1.6"
      />

      {/* Body chest panel */}
      <rect
        x="26"
        y="71"
        width="48"
        height="30"
        rx="3"
        fill="#B8C2DE"
        stroke="#2B2420"
        strokeWidth="1.1"
      />

      {/* Circuit traces on chest */}
      <path
        d="M30,77 L38,77 L38,83 L44,83"
        stroke="#4A5A8B"
        strokeWidth="0.9"
        fill="none"
        strokeLinecap="round"
      />
      <circle cx="30" cy="77" r="2" fill="#3B7A7B" />
      <circle cx="44" cy="83" r="2.5" fill="#B8892B" stroke="#2B2420" strokeWidth="0.8" />
      <path d="M54,75 L66,75" stroke="#4A5A8B" strokeWidth="0.9" strokeLinecap="round" />
      <path d="M54,79 L62,79" stroke="#4A5A8B" strokeWidth="0.9" strokeLinecap="round" />
      <path d="M54,83 L65,83" stroke="#4A5A8B" strokeWidth="0.9" strokeLinecap="round" />
      <circle cx="66" cy="75" r="1.5" fill="#3B7A7B" />

      {/* Lower body ventilation slots */}
      <line
        x1="28"
        y1="107"
        x2="44"
        y2="107"
        stroke="#2B2420"
        strokeWidth="0.8"
        strokeOpacity="0.35"
        strokeLinecap="round"
      />
      <line
        x1="28"
        y1="110"
        x2="40"
        y2="110"
        stroke="#2B2420"
        strokeWidth="0.8"
        strokeOpacity="0.35"
        strokeLinecap="round"
      />
      <line
        x1="56"
        y1="107"
        x2="72"
        y2="107"
        stroke="#2B2420"
        strokeWidth="0.8"
        strokeOpacity="0.35"
        strokeLinecap="round"
      />
      <line
        x1="60"
        y1="110"
        x2="72"
        y2="110"
        stroke="#2B2420"
        strokeWidth="0.8"
        strokeOpacity="0.35"
        strokeLinecap="round"
      />

      {/* Left arm */}
      <rect
        x="2"
        y="66"
        width="13"
        height="36"
        rx="5"
        fill="#CFD5ED"
        stroke="#2B2420"
        strokeWidth="1.5"
      />
      <rect
        x="0"
        y="96"
        width="17"
        height="11"
        rx="4"
        fill="#B8C2DE"
        stroke="#2B2420"
        strokeWidth="1.3"
      />
      <line x1="4" y1="80" x2="12" y2="80" stroke="#2B2420" strokeWidth="0.8" strokeOpacity="0.3" />

      {/* Right arm */}
      <rect
        x="85"
        y="66"
        width="13"
        height="36"
        rx="5"
        fill="#CFD5ED"
        stroke="#2B2420"
        strokeWidth="1.5"
      />
      <rect
        x="83"
        y="96"
        width="17"
        height="11"
        rx="4"
        fill="#B8C2DE"
        stroke="#2B2420"
        strokeWidth="1.3"
      />
      <line
        x1="88"
        y1="80"
        x2="96"
        y2="80"
        stroke="#2B2420"
        strokeWidth="0.8"
        strokeOpacity="0.3"
      />

      {/* Left leg */}
      <rect
        x="24"
        y="117"
        width="19"
        height="30"
        rx="5"
        fill="#B8C2DE"
        stroke="#2B2420"
        strokeWidth="1.5"
      />
      <rect
        x="19"
        y="141"
        width="29"
        height="10"
        rx="4"
        fill="#CFD5ED"
        stroke="#2B2420"
        strokeWidth="1.3"
      />

      {/* Right leg */}
      <rect
        x="57"
        y="117"
        width="19"
        height="30"
        rx="5"
        fill="#B8C2DE"
        stroke="#2B2420"
        strokeWidth="1.5"
      />
      <rect
        x="52"
        y="141"
        width="29"
        height="10"
        rx="4"
        fill="#CFD5ED"
        stroke="#2B2420"
        strokeWidth="1.3"
      />
    </svg>
  );
}
