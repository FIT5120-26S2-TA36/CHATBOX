/**
 * @file Button reusable presentation component used by routed gameplay experiences.
 */
import { type ButtonHTMLAttributes, type ReactNode } from "react";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  children: ReactNode;
  variant?: "primary" | "outline" | "ghost" | "danger";
  size?: "sm" | "md" | "lg";
}

/** Renders the Button experience/component and coordinates its user-facing callbacks. */
export default function Button({
  children,
  variant = "primary",
  size = "md",
  className = "",
  disabled,
  ...props
}: ButtonProps) {
  const base =
    "inline-flex items-center gap-2 font-medium transition-colors duration-150 rounded-sm cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed";

  const variants = {
    primary:
      "bg-ink text-paper border border-ink hover:bg-teal hover:border-teal active:bg-teal-deep",
    outline:
      "bg-transparent text-ink border border-ink hover:border-teal hover:text-teal active:bg-teal-soft",
    ghost: "bg-transparent text-muted border border-transparent hover:text-ink hover:bg-paper-dark",
    danger: "bg-coral text-paper border border-coral hover:opacity-90",
  };

  const sizes = {
    sm: "px-4 py-2 text-xs tracking-wide",
    md: "px-6 py-3 text-sm",
    lg: "px-8 py-4 text-base",
  };

  return (
    <button
      disabled={disabled}
      className={`${base} ${variants[variant]} ${sizes[size]} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
}
