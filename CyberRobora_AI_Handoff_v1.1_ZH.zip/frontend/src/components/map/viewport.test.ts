/**
 * @file Regression scope for viewport, including its externally observable contracts and edge cases.
 */
import { describe, expect, it } from "vitest";
import {
  getBaseMapSize,
  getInitialMapCamera,
  getMaxMapScale,
  getPanLimits,
  INITIAL_MAP_CAMERA,
  MAP_INTRINSIC_SIZE,
  MAX_SOURCE_PIXEL_MULTIPLIER,
  MIN_MAP_SCALE,
  panMapCamera,
  projectMapPoint,
  resetMapCamera,
  zoomMapCamera,
} from "./viewport";

const desktop = { width: 1440, height: 900 };

describe("fullscreen map viewport model", () => {
  it("starts with the shared cinematic handoff framing", () => {
    expect(getInitialMapCamera()).toEqual(INITIAL_MAP_CAMERA);
    expect(INITIAL_MAP_CAMERA).toEqual({ scale: MIN_MAP_SCALE, x: 0, y: 0 });
  });

  it("uses cover geometry so the map fills landscape and portrait viewports", () => {
    expect(getBaseMapSize(desktop)).toEqual({ width: 1440, height: 960 });
    expect(getBaseMapSize({ width: 320, height: 568 })).toEqual({
      width: 568 * 1.5,
      height: 568,
    });
  });

  it("never exposes empty space at minimum zoom", () => {
    for (const viewport of [
      desktop,
      { width: 1280, height: 720 },
      { width: 390, height: 844 },
      { width: 320, height: 568 },
    ]) {
      const base = getBaseMapSize(viewport);
      expect(base.width * MIN_MAP_SCALE).toBeGreaterThanOrEqual(viewport.width);
      expect(base.height * MIN_MAP_SCALE).toBeGreaterThanOrEqual(viewport.height);
    }
  });

  it("clamps zoom at the overview and derived pixel-quality limits", () => {
    expect(zoomMapCamera(getInitialMapCamera(), 0.1, desktop).scale).toBe(MIN_MAP_SCALE);
    expect(zoomMapCamera(getInitialMapCamera(), 9, desktop).scale).toBe(getMaxMapScale(desktop));
  });

  it("never renders the bitmap beyond twice its intrinsic dimensions", () => {
    for (const viewport of [
      desktop,
      { width: 1280, height: 720 },
      { width: 390, height: 844 },
      { width: 320, height: 568 },
    ]) {
      const base = getBaseMapSize(viewport);
      const maxScale = getMaxMapScale(viewport);
      expect(base.width * maxScale).toBeLessThanOrEqual(
        MAP_INTRINSIC_SIZE.width * MAX_SOURCE_PIXEL_MULTIPLIER,
      );
      expect(base.height * maxScale).toBeLessThanOrEqual(
        MAP_INTRINSIC_SIZE.height * MAX_SOURCE_PIXEL_MULTIPLIER,
      );
    }
  });

  it("clamps pan so the transformed map cannot leave the viewport", () => {
    const camera = { scale: 1.8, x: 0, y: 0 };
    const limits = getPanLimits(camera.scale, desktop);
    const panned = panMapCamera(camera, { x: 10000, y: -10000 }, desktop);

    expect(panned.x).toBe(limits.x);
    expect(panned.y).toBe(-limits.y);
  });

  it("lets the player pan to both source edges on the overflowing axis", () => {
    const portrait = { width: 320, height: 568 };
    const portraitLimits = getPanLimits(MIN_MAP_SCALE, portrait);
    const leftEdge = panMapCamera(resetMapCamera(portrait), { x: -10000, y: 0 }, portrait);
    const rightEdge = panMapCamera(resetMapCamera(portrait), { x: 10000, y: 0 }, portrait);

    expect(portraitLimits.x).toBeGreaterThan(0);
    expect(leftEdge.x).toBe(-portraitLimits.x);
    expect(rightEdge.x).toBe(portraitLimits.x);
    expect(leftEdge.y).toBe(0);

    const landscapeLimits = getPanLimits(MIN_MAP_SCALE, desktop);
    const topEdge = panMapCamera(resetMapCamera(desktop), { x: 0, y: -10000 }, desktop);
    const bottomEdge = panMapCamera(resetMapCamera(desktop), { x: 0, y: 10000 }, desktop);

    expect(landscapeLimits.y).toBeGreaterThan(0);
    expect(topEdge.y).toBe(-landscapeLimits.y);
    expect(bottomEdge.y).toBe(landscapeLimits.y);
    expect(topEdge.x).toBe(0);
  });

  it("projects geographic anchors into rounded screen-space coordinates", () => {
    expect(projectMapPoint({ x: 50, y: 50 }, INITIAL_MAP_CAMERA, desktop)).toEqual({
      x: 720,
      y: 450,
    });
    expect(projectMapPoint({ x: 75, y: 25 }, { scale: 2, x: 10, y: -6 }, desktop)).toEqual({
      x: 1450,
      y: -36,
    });
  });

  it("resets to the centred fullscreen cover framing", () => {
    expect(resetMapCamera(desktop)).toEqual({
      scale: MIN_MAP_SCALE,
      x: 0,
      y: 0,
    });
  });

  it("keeps the focal map point stable while zooming around a pointer", () => {
    const camera = { scale: 1.2, x: 0, y: 0 };
    const focal = { x: 900, y: 500 };
    const zoomed = zoomMapCamera(camera, 1.6, desktop, focal);

    expect(zoomed.x).toBeLessThan(0);
    expect(zoomed.y).toBeLessThan(0);
  });
});
