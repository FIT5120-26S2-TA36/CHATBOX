/**
 * @file FirstSignalOverlay map module, separating spatial/presentation behavior from authoritative game progress.
 */
import type { CSSProperties } from "react";
import { GAME_REGION_MAP_LOCATIONS } from "./mapLocations";

/** Defines the shared FirstSignalOverlayState contract. */
export type FirstSignalOverlayState = "active" | "handoff";

interface Props {
  state: FirstSignalOverlayState;
  stageStyle: CSSProperties;
}

/** Renders the FirstSignalOverlay experience/component and coordinates its user-facing callbacks. */
export default function FirstSignalOverlay({ state, stageStyle }: Props) {
  const dataDistrict = GAME_REGION_MAP_LOCATIONS["data-district"];

  return (
    <div
      className="first-signal-map-stage pointer-events-none absolute left-1/2 top-1/2 z-[60] select-none"
      style={stageStyle}
      data-first-signal-overlay={state}
      aria-hidden="true"
    >
      <div
        className="intro-signal-marker"
        style={{ left: `${dataDistrict.x}%`, top: `${dataDistrict.y}%` }}
      >
        <span className="intro-signal-marker__ring" />
        <span className="intro-signal-marker__pin" />
        <span className="intro-signal-marker__label">First Signal</span>
      </div>
    </div>
  );
}
