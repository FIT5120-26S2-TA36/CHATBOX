/** @vitest-environment jsdom */

import { act, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import type { MapDisplayStatus } from "../../game/mapState";
import type { RegionId } from "../../game/types";
import CyberiaMapViewport from "./CyberiaMapViewport";
import "../../test/dom";

const displayStatuses: Record<RegionId, MapDisplayStatus> = {
  "data-district": "available",
  "identity-citadel": "locked",
  "social-square": "locked",
  "inbox-harbour": "locked",
};

function renderViewport() {
  return render(
    <CyberiaMapViewport
      reducedMotion={false}
      selectedId={null}
      hoveredId={null}
      displayStatuses={displayStatuses}
      connectionRevealed={false}
      onLocationSelect={() => {}}
      onLocationHover={() => {}}
    />,
  );
}

describe("CyberiaMapViewport resize capability", () => {
  it("measures immediately and continues through ResizeObserver when available", () => {
    let width = 800;
    let height = 600;
    vi.spyOn(HTMLElement.prototype, "getBoundingClientRect").mockImplementation(
      () => new DOMRect(0, 0, width, height),
    );

    let callback: ResizeObserverCallback | null = null;
    const observe = vi.fn();
    const disconnect = vi.fn();
    class ControlledResizeObserver implements ResizeObserver {
      constructor(nextCallback: ResizeObserverCallback) {
        callback = nextCallback;
      }
      observe = observe;
      unobserve() {}
      disconnect = disconnect;
    }
    vi.stubGlobal("ResizeObserver", ControlledResizeObserver);

    const { container, unmount } = renderViewport();
    const viewport = screen.getByRole("group", { name: /Interactive illustrated map/ });
    const stage = container.querySelector<HTMLElement>(".cyberia-map-stage");
    expect(observe).toHaveBeenCalledWith(viewport);
    expect(stage?.style.width).toBe("900px");

    width = 1000;
    height = 500;
    act(() => callback?.([], {} as ResizeObserver));
    expect(stage?.style.width).toBe("1000px");

    unmount();
    expect(disconnect).toHaveBeenCalledOnce();
  });

  it("measures and responds to window resize when ResizeObserver is unavailable", () => {
    let width = 600;
    let height = 600;
    vi.spyOn(HTMLElement.prototype, "getBoundingClientRect").mockImplementation(
      () => new DOMRect(0, 0, width, height),
    );
    vi.stubGlobal("ResizeObserver", undefined);
    const removeEventListener = vi.spyOn(window, "removeEventListener");

    const { container, unmount } = renderViewport();
    const stage = container.querySelector<HTMLElement>(".cyberia-map-stage");
    expect(stage?.style.width).toBe("900px");

    width = 1200;
    height = 600;
    act(() => window.dispatchEvent(new Event("resize")));
    expect(stage?.style.width).toBe("1200px");

    unmount();
    expect(removeEventListener).toHaveBeenCalledWith("resize", expect.any(Function));
  });
});
