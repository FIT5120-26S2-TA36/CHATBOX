/**
 * @file mapJournal map module, separating spatial/presentation behavior from authoritative game progress.
 */
import type { SessionProgress } from "../../api/cyberroboraApi";
import { isMapConnectionRevealed } from "../../game/mapState";
import type { RegionId } from "../../game/types";

/** Defines the shared JournalEntry contract. */
export interface JournalEntry {
  id: number;
  date: string;
  title: string;
  content: string;
}

const BASE_JOURNAL: JournalEntry[] = [
  {
    id: 1,
    date: "Day 1, 08:14",
    title: "Field Briefing",
    content:
      "Arrived in Cyberia. CyberRobo has identified anomalies across multiple territories. Initial investigation point: Data District — Circuit Archives.",
  },
];

/** Assembles map Journal entries from completed regions and the existing Corva world context. */
export function getMapJournalEntries(
  investigatedRegions: RegionId[],
  journalContent: SessionProgress["journalEntries"] = {},
): JournalEntry[] {
  const dataDistrictEntry: JournalEntry | null = journalContent["data-district"]
    ? {
        id: 2,
        date: "Day 1, 14:32",
        title: "Data District — Investigation Complete",
        content: journalContent["data-district"],
      }
    : null;
  const citadelEntry: JournalEntry | null = journalContent["identity-citadel"]
    ? {
        id: 3,
        date: "Day 2, 10:18",
        title: "Identity Citadel — Investigation Complete",
        content: journalContent["identity-citadel"],
      }
    : null;
  if (isMapConnectionRevealed(investigatedRegions)) {
    return [
      ...BASE_JOURNAL,
      ...(dataDistrictEntry ? [dataDistrictEntry] : []),
      ...(citadelEntry ? [citadelEntry] : []),
    ];
  }
  if (investigatedRegions.includes("data-district") && dataDistrictEntry) {
    return [...BASE_JOURNAL, dataDistrictEntry];
  }
  return BASE_JOURNAL;
}
