/**
 * @file Regression scope for mapUi, including its externally observable contracts and edge cases.
 */
import { describe, expect, it } from "vitest";
import { initialGameSession } from "../../game/session";
import { initialMapUiState, mapUiReducer } from "./mapUi";

describe("fullscreen map presentation state", () => {
  it("synchronises map and Atlas selection through one selected region", () => {
    const fromMap = mapUiReducer(initialMapUiState, {
      type: "TOGGLE_MAP_LOCATION",
      locationId: "data-district",
    });
    const fromAtlas = mapUiReducer(
      { ...initialMapUiState, openPanel: "atlas" },
      { type: "SELECT_ATLAS_REGION", regionId: "data-district" },
    );

    expect(fromMap.selectedId).toBe(fromAtlas.selectedId);
    expect(fromAtlas.openPanel).toBeNull();
  });

  it("keeps Atlas and Journal mutually exclusive", () => {
    const atlas = mapUiReducer(initialMapUiState, {
      type: "OPEN_PANEL",
      panel: "atlas",
    });
    const journal = mapUiReducer(atlas, {
      type: "OPEN_PANEL",
      panel: "journal",
    });

    expect(journal.openPanel).toBe("journal");
  });

  it("keeps camera, selection, and drawer state out of GameSession", () => {
    expect(initialGameSession).not.toHaveProperty("scale");
    expect(initialGameSession).not.toHaveProperty("mapCamera");
    expect(initialGameSession).not.toHaveProperty("selectedId");
    expect(initialGameSession).not.toHaveProperty("openPanel");
  });

  it("does not mutate gameplay state when presentation state changes", () => {
    const before = structuredClone(initialGameSession);
    const selectedWorldLocation = mapUiReducer(initialMapUiState, {
      type: "TOGGLE_MAP_LOCATION",
      locationId: "laglands",
    });

    expect(selectedWorldLocation.selectedId).toBe("laglands");
    expect(initialGameSession).toEqual(before);
  });
});
