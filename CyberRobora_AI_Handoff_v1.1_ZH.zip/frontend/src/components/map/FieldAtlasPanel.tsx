/**
 * @file FieldAtlasPanel map module, separating spatial/presentation behavior from authoritative game progress.
 */
import type { MapDisplayStatus } from "../../game/mapState";
import { mapStatusLabels } from "../../game/mapState";
import type { RegionId } from "../../game/types";
import type { GameplayMapLocation, MapLocationId } from "./mapLocations";
import MapOverlayPanel from "./MapOverlayPanel";
import MapStatusGlyph from "./MapStatusGlyph";

interface Props {
  regions: readonly GameplayMapLocation[];
  displayStatuses: Readonly<Record<RegionId, MapDisplayStatus>>;
  selectedId: MapLocationId | null;
  dataDistrictDone: boolean;
  connectionRevealed: boolean;
  onSelectRegion: (regionId: RegionId) => void;
  onClose: () => void;
}

/** Non-spatial, accessible region index for the current map state. */
export default function FieldAtlasPanel({
  regions,
  displayStatuses,
  selectedId,
  dataDistrictDone,
  connectionRevealed,
  onSelectRegion,
  onClose,
}: Props) {
  return (
    <MapOverlayPanel titleId="field-atlas-title" onClose={onClose}>
      <div className="border-b border-ink/10 px-5 pb-4 pt-5 pr-16 sm:px-6 sm:pt-6">
        <p className="text-[9px] uppercase tracking-[0.22em] text-muted">Field Atlas</p>
        <h2
          id="field-atlas-title"
          className="font-display text-2xl font-bold text-ink"
          style={{ fontFamily: "'Caveat', cursive" }}
        >
          Cyberia locations
        </h2>
        <p className="mt-1 text-xs text-muted">
          A complete non-spatial index of current field status.
        </p>
      </div>

      {(dataDistrictDone || connectionRevealed) && (
        <div
          className="border-b border-ink/10 bg-paper-dark/60 px-5 py-3 text-xs text-ink/75 sm:px-6"
          role="status"
        >
          {connectionRevealed
            ? "Connection revealed: Data District and Identity Citadel."
            : "New signal: Identity Citadel is now available."}
        </div>
      )}

      <nav className="grid gap-2 p-4 sm:p-5" aria-label="Cyberia region index">
        {regions.map((region) => {
          const status = displayStatuses[region.id];
          return (
            <button
              key={region.id}
              type="button"
              onClick={() => onSelectRegion(region.id)}
              aria-pressed={selectedId === region.id}
              className="flex min-h-14 w-full items-center gap-3 rounded-sm border border-ink/15 bg-paper-dark/50 px-3 py-2 text-left hover:border-ink/35 hover:bg-paper"
            >
              <span
                className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full border border-ink/20"
                style={{ backgroundColor: region.fill }}
                aria-hidden="true"
              >
                <MapStatusGlyph status={status} />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-sm font-medium text-ink">{region.name}</span>
                <span className="block text-[10px] leading-4 text-muted">{region.subtitle}</span>
                <span className="block text-[10px] leading-4 text-muted">
                  {mapStatusLabels[status]}
                </span>
              </span>
            </button>
          );
        })}
      </nav>
    </MapOverlayPanel>
  );
}
