/**
 * @file mapLocations map module, separating spatial/presentation behavior from authoritative game progress.
 */
import type { RegionId } from "../../game/types";

export type WorldLocationId =
  | "signal-network"
  | "laglands"
  | "pirate-bay"
  | "cloud-heights"
  | "market-quarter";

/** Defines the shared MapLocationId contract. */
export type MapLocationId = RegionId | WorldLocationId;

export interface MapCoordinate {
  readonly x: number;
  readonly y: number;
}

interface BaseMapLocation extends MapCoordinate {
  readonly id: MapLocationId;
  readonly name: string;
  readonly subtitle: string;
  readonly description: string;
  readonly dialogue: string;
}

/** Defines the shared GameplayMapLocation contract. */
export interface GameplayMapLocation extends BaseMapLocation {
  readonly type: "gameplay";
  readonly id: RegionId;
  readonly category: string;
  readonly disturbanceDialogue?: string;
  readonly investigatedDialogue?: string;
  readonly fill: string;
}

/** Defines the shared WorldMapLocation contract. */
export interface WorldMapLocation extends BaseMapLocation {
  readonly type: "world";
  readonly id: WorldLocationId;
}

/** Defines the shared MapLocation contract. */
export type MapLocation = GameplayMapLocation | WorldMapLocation;

/**
 * Central metadata for labels positioned in percentage coordinates over the approved 1536×1024
 * map. These records describe geography and copy only: gameplay availability comes from
 * GameSession-derived map state, and world annotations can never advance progress.
 */
type GameplayMapLocationsById = {
  readonly [Id in RegionId]: GameplayMapLocation & { readonly id: Id };
};

/** Defines the shared GAME_REGION_MAP_LOCATIONS value. */
export const GAME_REGION_MAP_LOCATIONS: GameplayMapLocationsById = {
  "data-district": {
    type: "gameplay",
    id: "data-district",
    name: "Data District",
    subtitle: "The Circuit Archives",
    description:
      "Unrecognised data traces are moving through the Archives. Their origin is still unclear.",
    category: "Unrecognised data activity",
    dialogue:
      "The Circuit Archives are the backbone of Cyberia's data network. Your first clues await here.",
    investigatedDialogue:
      "The Archives are quiet for now. Your findings are recorded in the journal.",
    fill: "#C8DFDF",
    x: 44,
    y: 50,
  },
  "identity-citadel": {
    type: "gameplay",
    id: "identity-citadel",
    name: "Identity Citadel",
    subtitle: "The Verification Gate",
    description:
      "An unfamiliar signal flickers near the Verification Gate. Its meaning remains obscured.",
    category: "Unverified signal",
    dialogue: "The Gate is visible through the haze, but the route is not yet clear.",
    disturbanceDialogue:
      "Something is registering here that was not visible before. Approach carefully.",
    investigatedDialogue:
      "The Verification Gate is quiet again. The journal holds what we observed.",
    fill: "#CDD3EC",
    x: 72,
    y: 57,
  },
  "social-square": {
    type: "gameplay",
    id: "social-square",
    name: "Social Square",
    subtitle: "The Network Forum",
    description: "Signals around the Network Forum are difficult to read from this distance.",
    category: "Distant disturbance",
    dialogue: "The Forum is full of overlapping signals. We cannot trace them from here.",
    fill: "#ECDEC4",
    x: 32,
    y: 81,
  },
  "inbox-harbour": {
    type: "gameplay",
    id: "inbox-harbour",
    name: "Inbox Harbour",
    subtitle: "The Message Docks",
    description:
      "An indistinct signal is moving across the Message Docks. Its source cannot yet be confirmed.",
    category: "Faint signal",
    dialogue: "The harbour is visible, but the signal is too faint to follow safely.",
    fill: "#C8DFDF",
    x: 19,
    y: 44,
  },
};

/** Defines the shared GAMEPLAY_MAP_LOCATIONS value. */
export const GAMEPLAY_MAP_LOCATIONS: readonly GameplayMapLocation[] =
  Object.values(GAME_REGION_MAP_LOCATIONS);

export const WORLD_MAP_LOCATIONS: readonly WorldMapLocation[] = [
  {
    type: "world",
    id: "signal-network",
    name: "Signal Network",
    subtitle: "Remote communications outpost",
    description:
      "Its towers carry signals across the northern reaches of Cyberia. The outpost lies beyond the current investigation area.",
    dialogue: "Those towers are listening to parts of Cyberia we cannot reach.",
    x: 31,
    y: 14,
  },
  {
    type: "world",
    id: "laglands",
    name: "The Laglands",
    subtitle: "Distant mountain region",
    description:
      "Few reliable signals reach the mountainous interior. The current route does not extend that far north.",
    dialogue: "Even the map grows uncertain beyond those peaks.",
    x: 54,
    y: 20,
  },
  {
    type: "world",
    id: "pirate-bay",
    name: "Pirate Bay",
    subtitle: "Isolated coastal settlement",
    description:
      "Unusual traffic has been reported at the edge of the chart. The bay remains beyond reach.",
    dialogue: "There is movement offshore, but no safe route from here.",
    x: 84,
    y: 17,
  },
  {
    type: "world",
    id: "cloud-heights",
    name: "Cloud Heights",
    subtitle: "Settlement above the southern coast",
    description:
      "Cloud Heights drifts beyond the current investigation route. Its signals are faint at this distance.",
    dialogue: "A whole settlement above the clouds — and still beyond our reach.",
    x: 8.5,
    y: 84,
  },
  {
    type: "world",
    id: "market-quarter",
    name: "Market Quarter",
    subtitle: "South-east trading district",
    description:
      "A busy trading district lies along the southern coast. It is marked on the field map but is not open for investigation.",
    dialogue: "The market is active, though our present route leads elsewhere.",
    x: 87,
    y: 84,
  },
];

/** Defines the shared MAP_LOCATIONS value. */
export const MAP_LOCATIONS: readonly MapLocation[] = [
  ...GAMEPLAY_MAP_LOCATIONS,
  ...WORLD_MAP_LOCATIONS,
];

/** Provides the public isGameplayMapLocation behavior used across the application. */
export function isGameplayMapLocation(location: MapLocation): location is GameplayMapLocation {
  return location.type === "gameplay";
}

export function getMapLocation(id: MapLocationId | null): MapLocation | null {
  return MAP_LOCATIONS.find((location) => location.id === id) ?? null;
}
