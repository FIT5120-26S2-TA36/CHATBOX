/**
 * @file MapOverlayPanel map module, separating spatial/presentation behavior from authoritative game progress.
 */
import { useEffect, useRef, type ReactNode } from "react";
import { getFocusWrapTarget } from "../../a11y/dialog";

interface Props {
  titleId: string;
  onClose: () => void;
  children: ReactNode;
}

/** Modal sheet shared by map tools; owns initial focus, focus wrapping, Escape and backdrop close. */
export default function MapOverlayPanel({ titleId, onClose, children }: Props) {
  const panelRef = useRef<HTMLDivElement>(null);
  const closeButtonRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    // Initial focus and document-level Escape/Tab handling make the sheet a modal for keyboard users.
    closeButtonRef.current?.focus({ preventScroll: true });

    function handleKeyDown(event: KeyboardEvent) {
      if (event.key === "Escape") {
        event.preventDefault();
        onClose();
        return;
      }
      if (event.key !== "Tab" || !panelRef.current) return;
      const focusable = Array.from(
        panelRef.current.querySelectorAll<HTMLElement>(
          'button:not([disabled]), a[href], [tabindex]:not([tabindex="-1"])',
        ),
      );
      const activeIndex = focusable.findIndex((element) => element === document.activeElement);
      const targetIndex = getFocusWrapTarget(activeIndex, focusable.length, event.shiftKey);
      if (targetIndex !== null) {
        event.preventDefault();
        focusable[targetIndex]?.focus();
      }
    }

    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-end sm:items-stretch"
      role="dialog"
      aria-modal="true"
      aria-labelledby={titleId}
    >
      <div className="absolute inset-0 bg-ink/25" onClick={onClose} aria-hidden="true" />
      <div
        ref={panelRef}
        className="relative z-10 flex max-h-[82dvh] w-full flex-col overflow-y-auto rounded-t-sm border-l border-t border-ink/15 bg-paper shadow-xl sm:h-full sm:max-h-none sm:max-w-sm sm:rounded-none sm:border-t-0"
      >
        <button
          ref={closeButtonRef}
          type="button"
          onClick={onClose}
          className="absolute right-3 top-3 z-10 flex h-11 w-11 items-center justify-center rounded-sm text-muted hover:bg-paper-dark hover:text-ink"
          aria-label="Close panel"
        >
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true">
            <path
              d="M4 4l10 10M14 4 4 14"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
            />
          </svg>
        </button>
        {children}
      </div>
    </div>
  );
}
