/**
 * @file Regression scope for mapLocations, including its externally observable contracts and edge cases.
 */
import { describe, expect, it } from "vitest";
import { canEnterMapRegion } from "../../game/mapState";
import {
  GAMEPLAY_MAP_LOCATIONS,
  GAME_REGION_MAP_LOCATIONS,
  MAP_LOCATIONS,
  WORLD_MAP_LOCATIONS,
  getMapLocation,
  isGameplayMapLocation,
} from "./mapLocations";

describe("Cyberia map location model", () => {
  it("defines exactly the four authoritative gameplay regions", () => {
    expect(Object.keys(GAME_REGION_MAP_LOCATIONS)).toEqual(
      GAMEPLAY_MAP_LOCATIONS.map(({ id }) => id),
    );
  });

  it("makes all nine named locations selectable while keeping world IDs separate", () => {
    const gameplayIds = new Set(Object.keys(GAME_REGION_MAP_LOCATIONS));

    expect(MAP_LOCATIONS).toHaveLength(9);
    expect(WORLD_MAP_LOCATIONS).toHaveLength(5);
    expect(WORLD_MAP_LOCATIONS.every(({ id }) => !gameplayIds.has(id))).toBe(true);
  });

  it("preserves every audited geographic anchor", () => {
    expect(Object.fromEntries(MAP_LOCATIONS.map(({ id, x, y }) => [id, { x, y }]))).toEqual({
      "data-district": { x: 44, y: 50 },
      "identity-citadel": { x: 72, y: 57 },
      "social-square": { x: 32, y: 81 },
      "inbox-harbour": { x: 19, y: 44 },
      "signal-network": { x: 31, y: 14 },
      laglands: { x: 54, y: 20 },
      "pirate-bay": { x: 84, y: 17 },
      "cloud-heights": { x: 8.5, y: 84 },
      "market-quarter": { x: 87, y: 84 },
    });
  });

  it("resolves a world location as non-gameplay Inspector content", () => {
    const laglands = getMapLocation("laglands");

    expect(laglands?.name).toBe("The Laglands");
    expect(laglands && isGameplayMapLocation(laglands)).toBe(false);
    expect(laglands?.description).toContain("mountainous interior");
  });

  it("keeps Data District initially enterable and every world location non-gameplay", () => {
    expect(canEnterMapRegion("data-district", [])).toBe(true);
    expect(WORLD_MAP_LOCATIONS.every((location) => !isGameplayMapLocation(location))).toBe(true);
  });

  it("uses Australian English and spoiler-light copy in map location content", () => {
    const copy = MAP_LOCATIONS.map(
      ({ name, subtitle, description, dialogue }) =>
        `${name} ${subtitle} ${description} ${dialogue}`,
    ).join(" ");
    const lockedGameplayCopy = MAP_LOCATIONS.filter(
      (location) => location.type === "gameplay" && location.id !== "data-district",
    )
      .map(({ description, dialogue }) => `${description} ${dialogue}`)
      .join(" ");

    expect(copy).toContain("Unrecognised");
    expect(copy).not.toMatch(
      /\b(?:unauthorized|unrecognized|organization|personalize|behavior|traveling|analyze|recognize)\b/i,
    );
    expect(lockedGameplayCopy).not.toMatch(
      /phishing|credential theft|impersonation|misinformation/i,
    );
  });
});
