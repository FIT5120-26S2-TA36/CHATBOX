/**
 * Camera math bridges three spaces: percentage points on the source artwork, CSS pixels in the
 * measured viewport, and camera translation/scale. Every public transform clamps to the visible
 * canvas and the source-resolution/UX zoom budget.
 */
export interface MapCamera {
  scale: number;
  x: number;
  y: number;
}

/** Defines the shared ViewportSize contract. */
export interface ViewportSize {
  width: number;
  height: number;
}

/** Defines the shared ViewportPoint contract. */
export interface ViewportPoint {
  x: number;
  y: number;
}

/** Defines the shared MAP_ASPECT_RATIO value. */
export const MAP_ASPECT_RATIO = 3 / 2;
export const MAP_INTRINSIC_SIZE: Readonly<ViewportSize> = {
  width: 1536,
  height: 1024,
};
/** Defines the shared MAX_SOURCE_PIXEL_MULTIPLIER value. */
export const MAX_SOURCE_PIXEL_MULTIPLIER = 2;
export const MAX_MAP_UX_SCALE = 3;
export const MIN_MAP_SCALE = 1;
export const MAP_ZOOM_STEP = 0.2;
export const INITIAL_MAP_CAMERA: Readonly<MapCamera> = {
  scale: MIN_MAP_SCALE,
  x: 0,
  y: 0,
};

/** Provides the public getInitialMapCamera behavior used across the application. */
export function getInitialMapCamera(): MapCamera {
  return { ...INITIAL_MAP_CAMERA };
}

export function getBaseMapSize(viewport: ViewportSize): ViewportSize {
  const width = Math.max(viewport.width, viewport.height * MAP_ASPECT_RATIO);
  return { width, height: width / MAP_ASPECT_RATIO };
}

/** Provides the public getMaxMapScale behavior used across the application. */
export function getMaxMapScale(viewport: ViewportSize): number {
  const map = getBaseMapSize(viewport);
  const maxScaleByWidth = (MAP_INTRINSIC_SIZE.width * MAX_SOURCE_PIXEL_MULTIPLIER) / map.width;
  const maxScaleByHeight = (MAP_INTRINSIC_SIZE.height * MAX_SOURCE_PIXEL_MULTIPLIER) / map.height;
  const derivedCap = Math.min(maxScaleByWidth, maxScaleByHeight, MAX_MAP_UX_SCALE);

  // Keep floating-point multiplication from exceeding the source-pixel budget
  // by a fractional machine unit at the exact derived boundary.
  return Math.max(MIN_MAP_SCALE, derivedCap * (1 - Number.EPSILON));
}

/** Provides the public clampMapScale behavior used across the application. */
export function clampMapScale(scale: number, viewport: ViewportSize): number {
  return Math.min(getMaxMapScale(viewport), Math.max(MIN_MAP_SCALE, scale));
}

export function getPanLimits(scale: number, viewport: ViewportSize): ViewportPoint {
  const map = getBaseMapSize(viewport);
  return {
    x: Math.max(0, (map.width * scale - viewport.width) / 2),
    y: Math.max(0, (map.height * scale - viewport.height) / 2),
  };
}

/** Provides the public clampMapCamera behavior used across the application. */
export function clampMapCamera(camera: MapCamera, viewport: ViewportSize): MapCamera {
  const scale = clampMapScale(camera.scale, viewport);
  const limits = getPanLimits(scale, viewport);
  return {
    scale,
    x: Math.min(limits.x, Math.max(-limits.x, camera.x)),
    y: Math.min(limits.y, Math.max(-limits.y, camera.y)),
  };
}

/** Provides the public panMapCamera behavior used across the application. */
export function panMapCamera(
  camera: MapCamera,
  delta: ViewportPoint,
  viewport: ViewportSize,
): MapCamera {
  return clampMapCamera({ ...camera, x: camera.x + delta.x, y: camera.y + delta.y }, viewport);
}

/** Provides the public zoomMapCamera behavior used across the application. */
export function zoomMapCamera(
  camera: MapCamera,
  nextScale: number,
  viewport: ViewportSize,
  focalPoint: ViewportPoint = {
    x: viewport.width / 2,
    y: viewport.height / 2,
  },
): MapCamera {
  const scale = clampMapScale(nextScale, viewport);
  const ratio = scale / camera.scale;
  const focalOffset = {
    x: focalPoint.x - viewport.width / 2,
    y: focalPoint.y - viewport.height / 2,
  };

  return clampMapCamera(
    {
      scale,
      x: focalOffset.x - (focalOffset.x - camera.x) * ratio,
      y: focalOffset.y - (focalOffset.y - camera.y) * ratio,
    },
    viewport,
  );
}

/** Provides the public resetMapCamera behavior used across the application. */
export function resetMapCamera(viewport: ViewportSize): MapCamera {
  return clampMapCamera({ scale: MIN_MAP_SCALE, x: 0, y: 0 }, viewport);
}

export function projectMapPoint(
  point: ViewportPoint,
  camera: MapCamera,
  viewport: ViewportSize,
): ViewportPoint {
  // Location coordinates are percentages centered at 50/50; labels remain in screen space so
  // their text does not scale with the artwork.
  const map = getBaseMapSize(viewport);
  return {
    x: Math.round(
      viewport.width / 2 + camera.x + ((point.x - 50) / 100) * map.width * camera.scale,
    ),
    y: Math.round(
      viewport.height / 2 + camera.y + ((point.y - 50) / 100) * map.height * camera.scale,
    ),
  };
}
