/**
 * @file JournalPanel map module, separating spatial/presentation behavior from authoritative game progress.
 */
import type { JournalEntry } from "./mapJournal";
import MapOverlayPanel from "./MapOverlayPanel";

interface Props {
  entries: readonly JournalEntry[];
  onClose: () => void;
}

/** Renders the Map Journal while its entries remain derived by the map content adapter. */
export default function JournalPanel({ entries, onClose }: Props) {
  return (
    <MapOverlayPanel titleId="journal-title" onClose={onClose}>
      <div className="border-b border-ink/10 px-5 pb-4 pt-5 pr-16 sm:px-6 sm:pt-6">
        <p className="text-[9px] uppercase tracking-[0.22em] text-muted">Field Record</p>
        <h2
          id="journal-title"
          className="font-display text-2xl font-bold text-ink"
          style={{ fontFamily: "'Caveat', cursive" }}
        >
          Investigation Journal
        </h2>
      </div>
      <div className="flex-1 space-y-5 px-5 py-5 sm:px-6">
        {entries.map((entry) => (
          <article key={entry.id} className="border-b border-ink/10 pb-5 last:border-0">
            <time className="block text-[10px] uppercase tracking-widest text-muted">
              {entry.date}
            </time>
            <h3
              className="mt-1 font-display text-lg font-semibold text-ink"
              style={{ fontFamily: "'Caveat', cursive" }}
            >
              {entry.title}
            </h3>
            <p className="mt-2 text-sm leading-6 text-muted">{entry.content}</p>
          </article>
        ))}
        <p className="pt-2 text-xs italic text-muted/60">
          New findings are recorded automatically as you investigate.
        </p>
      </div>
    </MapOverlayPanel>
  );
}
