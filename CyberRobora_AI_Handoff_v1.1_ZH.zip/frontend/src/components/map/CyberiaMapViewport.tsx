/**
 * Owns camera interaction and projection for the fixed 1536×1024 map artwork. Location metadata
 * arrives as percentage coordinates, is projected into the measured viewport, and never owns or
 * mutates gameplay progress; display statuses are derived by the parent from GameSession.
 */
import { useEffect, useRef, useState } from "react";
import cyberiaMap from "../../assets/world/cyberia-map.png";
import { mapStatusLabels, type MapDisplayStatus } from "../../game/mapState";
import type { RegionId } from "../../game/types";
import {
  GAME_REGION_MAP_LOCATIONS,
  isGameplayMapLocation,
  MAP_LOCATIONS,
  type MapLocationId,
} from "./mapLocations";
import {
  clampMapCamera,
  getBaseMapSize,
  getInitialMapCamera,
  getMaxMapScale,
  MAP_ZOOM_STEP,
  MIN_MAP_SCALE,
  panMapCamera,
  projectMapPoint,
  resetMapCamera,
  zoomMapCamera,
  type MapCamera,
  type ViewportSize,
} from "./viewport";
import FirstSignalOverlay, { type FirstSignalOverlayState } from "./FirstSignalOverlay";

interface Props {
  interactive?: boolean;
  firstSignalState?: FirstSignalOverlayState | null;
  reducedMotion: boolean;
  selectedId: MapLocationId | null;
  hoveredId: MapLocationId | null;
  displayStatuses: Record<RegionId, MapDisplayStatus>;
  connectionRevealed: boolean;
  onLocationSelect: (id: MapLocationId, trigger: HTMLButtonElement) => void;
  onLocationHover: (id: MapLocationId | null) => void;
}

const shortStatusLabels: Record<MapDisplayStatus, string> = {
  available: "Available",
  locked: "Locked",
  investigated: "Investigated",
  "new-disturbance": "New disturbance",
  "faint-disturbance": "Future signal",
};

const statusClasses: Record<MapDisplayStatus, string> = {
  available: "border-teal/70 text-teal",
  locked: "border-locked/55 text-locked",
  investigated: "border-ink/35 text-muted",
  "new-disturbance": "border-ochre/80 text-ochre",
  "faint-disturbance": "border-ochre/55 text-ochre",
};

const defaultViewport: ViewportSize = { width: 1536, height: 1024 };

function MapStatusGlyph({ status }: { status: MapDisplayStatus }) {
  if (status === "available" || status === "investigated") {
    return (
      <svg width="13" height="13" viewBox="0 0 14 14" fill="none" aria-hidden="true">
        <circle
          cx="7"
          cy="7"
          r="5.5"
          fill="currentColor"
          fillOpacity=".16"
          stroke="currentColor"
          strokeWidth="1.2"
        />
        <path
          d="m4 7 2 2 4-4"
          stroke="currentColor"
          strokeWidth="1.4"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    );
  }

  if (status === "new-disturbance") {
    return (
      <svg width="13" height="13" viewBox="0 0 14 14" fill="none" aria-hidden="true">
        <circle
          cx="7"
          cy="7"
          r="5.5"
          fill="currentColor"
          fillOpacity=".16"
          stroke="currentColor"
          strokeWidth="1.2"
        />
        <path d="M7 4.2v3.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
        <circle cx="7" cy="9.6" r=".8" fill="currentColor" />
      </svg>
    );
  }

  return (
    <svg width="13" height="13" viewBox="0 0 14 14" fill="none" aria-hidden="true">
      <rect
        x="2"
        y="7"
        width="10"
        height="7"
        rx="1.5"
        fill="currentColor"
        fillOpacity=".32"
        stroke="currentColor"
        strokeWidth="1.2"
      />
      <path
        d="M4 7V5a3 3 0 0 1 6 0v2"
        stroke="currentColor"
        strokeWidth="1.2"
        strokeLinecap="round"
      />
    </svg>
  );
}

/** Renders the CyberiaMapViewport experience/component and coordinates its user-facing callbacks. */
export default function CyberiaMapViewport({
  interactive = true,
  firstSignalState = null,
  reducedMotion,
  selectedId,
  hoveredId,
  displayStatuses,
  connectionRevealed,
  onLocationSelect,
  onLocationHover,
}: Props) {
  const viewportRef = useRef<HTMLDivElement>(null);
  const cameraRef = useRef<MapCamera>(getInitialMapCamera());
  const frameRef = useRef<number | null>(null);
  const pendingCameraRef = useRef<MapCamera>(cameraRef.current);
  const pointerRef = useRef<{
    id: number;
    x: number;
    y: number;
  } | null>(null);
  const [camera, setCamera] = useState(cameraRef.current);
  const [viewport, setViewport] = useState(defaultViewport);
  const [dragging, setDragging] = useState(false);
  const mapSummary = MAP_LOCATIONS.map((location) =>
    isGameplayMapLocation(location)
      ? `${location.name}: ${mapStatusLabels[displayStatuses[location.id]]}`
      : `${location.name}: beyond reach`,
  ).join(". ");
  const baseMapSize = getBaseMapSize(viewport);
  const maxMapScale = getMaxMapScale(viewport);

  useEffect(() => {
    if (!viewportRef.current) return;
    const element = viewportRef.current;

    function measure() {
      const bounds = element.getBoundingClientRect();
      const nextViewport = {
        width: Math.max(1, bounds.width),
        height: Math.max(1, bounds.height),
      };
      const nextCamera = clampMapCamera(cameraRef.current, nextViewport);
      cameraRef.current = nextCamera;
      pendingCameraRef.current = nextCamera;
      setViewport(nextViewport);
      setCamera(nextCamera);
    }

    // Re-clamp after every container resize so a previously valid pan cannot expose empty canvas.
    measure();
    if (typeof ResizeObserver === "function") {
      const observer = new ResizeObserver(measure);
      observer.observe(element);
      return () => observer.disconnect();
    }

    window.addEventListener("resize", measure);
    return () => window.removeEventListener("resize", measure);
  }, []);

  useEffect(
    () => () => {
      if (frameRef.current !== null) cancelAnimationFrame(frameRef.current);
    },
    [],
  );

  useEffect(() => {
    if (!viewportRef.current) return;
    const element = viewportRef.current;

    function handleWheel(event: WheelEvent) {
      if (!interactive) return;
      event.preventDefault();
      const bounds = element.getBoundingClientRect();
      const wheelViewport = {
        width: Math.max(1, bounds.width),
        height: Math.max(1, bounds.height),
      };
      const focalPoint = {
        x: event.clientX - bounds.left,
        y: event.clientY - bounds.top,
      };
      const delta = event.deltaY < 0 ? MAP_ZOOM_STEP : -MAP_ZOOM_STEP;
      commitCamera(
        zoomMapCamera(
          cameraRef.current,
          cameraRef.current.scale + delta,
          wheelViewport,
          focalPoint,
        ),
      );
    }

    element.addEventListener("wheel", handleWheel, { passive: false });
    return () => element.removeEventListener("wheel", handleWheel);
  }, [interactive]);

  function commitCamera(nextCamera: MapCamera) {
    cameraRef.current = nextCamera;
    pendingCameraRef.current = nextCamera;
    setCamera(nextCamera);
  }

  function scheduleCamera(nextCamera: MapCamera) {
    cameraRef.current = nextCamera;
    pendingCameraRef.current = nextCamera;
    // Pointer moves update the authoritative refs immediately but coalesce React renders per frame.
    if (frameRef.current !== null) return;
    frameRef.current = requestAnimationFrame(() => {
      frameRef.current = null;
      setCamera(pendingCameraRef.current);
    });
  }

  function changeZoom(delta: number) {
    commitCamera(zoomMapCamera(cameraRef.current, cameraRef.current.scale + delta, viewport));
  }

  function handlePointerDown(event: React.PointerEvent<HTMLDivElement>) {
    if (!interactive) return;
    if (event.pointerType === "mouse" && event.button !== 0) return;
    if ((event.target as Element).closest("button")) return;
    if (pointerRef.current) return;

    event.currentTarget.setPointerCapture(event.pointerId);
    pointerRef.current = {
      id: event.pointerId,
      x: event.clientX,
      y: event.clientY,
    };
    setDragging(true);
  }

  function handlePointerMove(event: React.PointerEvent<HTMLDivElement>) {
    const pointer = pointerRef.current;
    if (!pointer || pointer.id !== event.pointerId) return;
    event.preventDefault();

    const delta = { x: event.clientX - pointer.x, y: event.clientY - pointer.y };
    pointerRef.current = { id: pointer.id, x: event.clientX, y: event.clientY };
    scheduleCamera(panMapCamera(cameraRef.current, delta, viewport));
  }

  function endPointer(event: React.PointerEvent<HTMLDivElement>) {
    if (pointerRef.current?.id !== event.pointerId) return;
    if (event.currentTarget.hasPointerCapture(event.pointerId)) {
      event.currentTarget.releasePointerCapture(event.pointerId);
    }
    pointerRef.current = null;
    setDragging(false);
  }

  const stageStyle = {
    width: `${baseMapSize.width}px`,
    height: `${baseMapSize.height}px`,
    transform: `translate(-50%, -50%) translate3d(${camera.x}px, ${camera.y}px, 0) scale(${camera.scale}) translateY(var(--intro-map-y, 0%)) scale(var(--intro-map-scale, 1))`,
  };

  return (
    <div
      className="cyberia-map-scene absolute inset-0"
      data-map-interactive={interactive ? "true" : "false"}
      data-map-camera="persistent"
      data-map-measurement="persistent"
      data-reduced-motion={reducedMotion ? "true" : "false"}
    >
      <div className="cyberia-map-scroll intro-descent__scroll-frame" aria-hidden="true">
        <span className="cyberia-map-scroll__rod cyberia-map-scroll__rod--top" />
        <span className="cyberia-map-scroll__rod cyberia-map-scroll__rod--bottom" />
        <span className="cyberia-map-scroll__edge cyberia-map-scroll__edge--left" />
        <span className="cyberia-map-scroll__edge cyberia-map-scroll__edge--right" />
      </div>

      <div
        ref={viewportRef}
        className={`cyberia-map-viewport absolute overflow-hidden touch-none ${
          dragging ? "is-dragging cursor-grabbing" : "cursor-grab"
        }`}
        role="group"
        aria-hidden={!interactive}
        aria-label={`Interactive illustrated map of Cyberia. ${mapSummary}`}
        aria-describedby="map-interaction-instructions"
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={endPointer}
        onPointerCancel={endPointer}
      >
        <p id="map-interaction-instructions" className="sr-only">
          Drag to pan Cyberia or use the visible zoom and reset controls. Select any named location
          to inspect it. The Field Atlas provides a non-spatial index of gameplay regions.
        </p>

        <div className="cyberia-map-stage" style={stageStyle}>
          <img
            src={cyberiaMap}
            alt=""
            aria-hidden="true"
            draggable={false}
            data-map-image="persistent"
            className="absolute inset-0 h-full w-full select-none object-contain"
          />

          {connectionRevealed && (
            <svg
              className="pointer-events-none absolute inset-0 h-full w-full"
              viewBox="0 0 1536 1024"
              fill="none"
              aria-hidden="true"
            >
              <path
                d="M676 500C820 402 962 410 1105 568"
                stroke="#F5EFE3"
                strokeWidth="13"
                strokeOpacity=".5"
                strokeLinecap="round"
              />
              <path
                d="M676 500C820 402 962 410 1105 568"
                stroke="#7D5A16"
                strokeWidth="4"
                strokeDasharray="13 11"
                strokeLinecap="round"
              />
              <circle cx="676" cy="500" r="10" fill="#ECDEC4" stroke="#7D5A16" strokeWidth="3" />
              <circle cx="1105" cy="568" r="10" fill="#ECDEC4" stroke="#7D5A16" strokeWidth="3" />
              <g transform="translate(845 410)">
                <rect
                  width="170"
                  height="40"
                  rx="4"
                  fill="#F5EFE3"
                  fillOpacity=".92"
                  stroke="#7D5A16"
                  strokeOpacity=".7"
                />
                <text
                  x="85"
                  y="25"
                  textAnchor="middle"
                  fill="#7D5A16"
                  fontFamily="'Caveat', cursive"
                  fontSize="21"
                  fontWeight="700"
                >
                  connection revealed
                </text>
              </g>
            </svg>
          )}

          {displayStatuses["identity-citadel"] === "new-disturbance" && (
            <span
              className="pointer-events-none absolute aspect-square w-[13%] -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-dashed border-ochre/70"
              style={{
                left: `${GAME_REGION_MAP_LOCATIONS["identity-citadel"].x}%`,
                top: `${GAME_REGION_MAP_LOCATIONS["identity-citadel"].y}%`,
              }}
              aria-hidden="true"
            />
          )}

          {displayStatuses["inbox-harbour"] === "faint-disturbance" && (
            <span
              className="pointer-events-none absolute aspect-square w-[12%] -translate-x-1/2 -translate-y-1/2 rounded-full border border-dashed border-ochre/60"
              style={{
                left: `${GAME_REGION_MAP_LOCATIONS["inbox-harbour"].x}%`,
                top: `${GAME_REGION_MAP_LOCATIONS["inbox-harbour"].y}%`,
              }}
              aria-hidden="true"
            />
          )}
        </div>

        <div
          className="map-reveal-labels pointer-events-none absolute inset-0 z-20"
          data-map-label-layer="screen-space"
          aria-hidden={!interactive}
        >
          {MAP_LOCATIONS.map((location) => {
            const point = projectMapPoint(location, camera, viewport);
            const gameplay = isGameplayMapLocation(location);
            const status = gameplay ? displayStatuses[location.id] : null;
            const selected = selectedId === location.id;
            const highlighted = selected || hoveredId === location.id;
            const statusLabel = status ? mapStatusLabels[status] : "Beyond reach — world location";

            return (
              <button
                key={location.id}
                type="button"
                disabled={!interactive}
                tabIndex={interactive ? undefined : -1}
                onClick={(event) => onLocationSelect(location.id, event.currentTarget)}
                onMouseEnter={() => onLocationHover(location.id)}
                onMouseLeave={() => onLocationHover(null)}
                aria-pressed={selected}
                aria-label={`${location.name} — ${statusLabel}`}
                data-map-location={location.id}
                data-location-type={location.type}
                className={`cyberia-location-label pointer-events-auto absolute cursor-pointer rounded-[3px] border bg-paper/92 px-1.5 text-center shadow-[0_1px_3px_rgba(43,36,32,0.12)] transition-colors ${
                  gameplay
                    ? `min-h-[52px] py-1 sm:min-w-[92px] sm:px-2 ${statusClasses[displayStatuses[location.id]]}`
                    : "min-h-11 border-ink/35 py-1 text-muted sm:min-w-[84px]"
                } ${highlighted ? "outline outline-2 outline-offset-2 outline-ink/55" : ""}`}
                style={{
                  left: `${point.x}px`,
                  top: `${point.y}px`,
                  translate: "-50% -50%",
                  fontFamily: "'Outfit', sans-serif",
                }}
              >
                <span
                  className={`block whitespace-nowrap font-display font-bold uppercase leading-none text-ink ${
                    gameplay ? "text-[10px] sm:text-[11px] xl:text-xs" : "text-[9px] sm:text-[10px]"
                  }`}
                  style={{ fontFamily: "'Caveat', cursive" }}
                >
                  {location.name}
                </span>
                <span
                  className={`mt-1 flex items-center justify-center gap-1 font-medium leading-none ${
                    gameplay ? "text-[8px] sm:text-[9px]" : "text-[7px]"
                  }`}
                >
                  <MapStatusGlyph status={status ?? "locked"} />
                  <span className={gameplay ? "hidden sm:inline" : ""}>
                    {status ? shortStatusLabels[status] : "Beyond reach"}
                  </span>
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {firstSignalState && <FirstSignalOverlay state={firstSignalState} stageStyle={stageStyle} />}

      <div
        className={`map-reveal-tools absolute right-3 z-30 flex flex-col overflow-hidden rounded-sm border border-ink/20 bg-paper/90 shadow-md sm:right-4 ${
          selectedId ? "top-16 sm:top-20" : "top-24 sm:top-28"
        }`}
        data-map-camera-controls="right"
        data-map-safe-area={selectedId ? "right-upper" : "right-upper-middle"}
        aria-hidden={!interactive}
      >
        <button
          type="button"
          tabIndex={interactive ? undefined : -1}
          onClick={() => changeZoom(MAP_ZOOM_STEP)}
          disabled={!interactive || camera.scale >= maxMapScale}
          className="flex h-11 w-11 items-center justify-center border-b border-ink/15 text-xl text-ink hover:bg-paper-dark disabled:opacity-40"
          aria-label="Zoom in on Cyberia"
        >
          <span aria-hidden="true">+</span>
        </button>
        <button
          type="button"
          tabIndex={interactive ? undefined : -1}
          onClick={() => changeZoom(-MAP_ZOOM_STEP)}
          disabled={!interactive || camera.scale <= MIN_MAP_SCALE}
          className="flex h-11 w-11 items-center justify-center border-b border-ink/15 text-xl text-ink hover:bg-paper-dark disabled:opacity-40"
          aria-label="Zoom out from Cyberia"
        >
          <span aria-hidden="true">−</span>
        </button>
        <button
          type="button"
          tabIndex={interactive ? undefined : -1}
          disabled={!interactive}
          onClick={() => commitCamera(resetMapCamera(viewport))}
          className="flex h-11 w-11 items-center justify-center text-ink hover:bg-paper-dark"
          aria-label="Reset Cyberia view"
          title="Reset view"
        >
          <svg width="17" height="17" viewBox="0 0 18 18" fill="none" aria-hidden="true">
            <path
              d="M2.5 6V2.5H6M12 2.5h3.5V6M15.5 12v3.5H12M6 15.5H2.5V12"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
            />
          </svg>
        </button>
      </div>
    </div>
  );
}
