/**
 * @file MapStatusGlyph map module, separating spatial/presentation behavior from authoritative game progress.
 */
import type { MapDisplayStatus } from "../../game/mapState";

export type LocationDisplayStatus = MapDisplayStatus | "beyond-reach";

function LockIcon({ className = "" }: { className?: string }) {
  return (
    <svg
      width="14"
      height="14"
      viewBox="0 0 14 14"
      fill="none"
      aria-hidden="true"
      className={className}
    >
      <rect
        x="2"
        y="7"
        width="10"
        height="7"
        rx="1.5"
        fill="currentColor"
        fillOpacity=".4"
        stroke="currentColor"
        strokeWidth="1.2"
      />
      <path
        d="M4 7V5a3 3 0 0 1 6 0v2"
        stroke="currentColor"
        strokeWidth="1.2"
        strokeLinecap="round"
      />
    </svg>
  );
}

function CheckIcon({ className = "" }: { className?: string }) {
  return (
    <svg
      width="14"
      height="14"
      viewBox="0 0 14 14"
      fill="none"
      aria-hidden="true"
      className={className}
    >
      <circle
        cx="7"
        cy="7"
        r="5.5"
        fill="currentColor"
        fillOpacity=".15"
        stroke="currentColor"
        strokeWidth="1.2"
      />
      <path
        d="M4 7l2 2 4-4"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function AlertIcon({ className = "" }: { className?: string }) {
  return (
    <svg
      width="14"
      height="14"
      viewBox="0 0 14 14"
      fill="none"
      aria-hidden="true"
      className={className}
    >
      <circle
        cx="7"
        cy="7"
        r="5.5"
        fill="currentColor"
        fillOpacity=".18"
        stroke="currentColor"
        strokeWidth="1.2"
      />
      <path d="M7 4.5V8" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
      <circle cx="7" cy="9.5" r=".8" fill="currentColor" />
    </svg>
  );
}

/** Color-independent glyph shared by the map Inspector and Field Atlas. */
export default function MapStatusGlyph({ status }: { status: LocationDisplayStatus }) {
  if (status === "new-disturbance") return <AlertIcon />;
  if (status === "locked" || status === "faint-disturbance" || status === "beyond-reach")
    return <LockIcon />;
  return <CheckIcon />;
}
