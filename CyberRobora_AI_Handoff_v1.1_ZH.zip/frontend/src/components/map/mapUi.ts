/**
 * Transient map presentation only. Selection means "inspect this location", not "enter it";
 * GameSession owns progression, while Map restores focus after panel actions at the component layer.
 */
import type { RegionId } from "../../game/types";
import type { MapLocationId } from "./mapLocations";

/** Defines the shared MapPanel contract. */
export type MapPanel = "atlas" | "journal" | null;

export interface MapUiState {
  selectedId: MapLocationId | null;
  openPanel: MapPanel;
}

interface ToggleMapLocationAction {
  type: "TOGGLE_MAP_LOCATION";
  locationId: MapLocationId;
}

interface SelectAtlasRegionAction {
  type: "SELECT_ATLAS_REGION";
  regionId: RegionId;
}

interface OpenMapPanelAction {
  type: "OPEN_PANEL";
  panel: Exclude<MapPanel, null>;
}

/** Defines the shared MapUiAction contract. */
export type MapUiAction =
  | ToggleMapLocationAction
  | SelectAtlasRegionAction
  | OpenMapPanelAction
  | {
      type: "CLOSE_PANEL";
    }
  | { type: "CLEAR_SELECTION" };

/** Defines the shared initialMapUiState value. */
export const initialMapUiState: MapUiState = {
  selectedId: null,
  openPanel: null,
};

/** Provides the public mapUiReducer behavior used across the application. */
export function mapUiReducer(state: MapUiState, action: MapUiAction): MapUiState {
  switch (action.type) {
    case "TOGGLE_MAP_LOCATION":
      return {
        ...state,
        selectedId: state.selectedId === action.locationId ? null : action.locationId,
      };
    case "SELECT_ATLAS_REGION":
      return { selectedId: action.regionId, openPanel: null };
    case "OPEN_PANEL":
      return { ...state, openPanel: action.panel };
    case "CLOSE_PANEL":
      return { ...state, openPanel: null };
    case "CLEAR_SELECTION":
      return { ...state, selectedId: null };
  }
}
