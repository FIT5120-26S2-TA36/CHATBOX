/** @vitest-environment jsdom */
import { act, fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import CyberRoboChat from "./CyberRoboChat";
import { trimChatHistory, type ChatMessage } from "../api/chatApi";
import "../test/dom";

const config = {
  models: [
    { provider: "qwen", model: "qwen3.7-plus", label: "Qwen 3.7 Plus", configured: true },
    {
      provider: "groq",
      model: "openai/gpt-oss-20b",
      label: "GPT-OSS 20B (Groq)",
      configured: true,
    },
  ],
  history_limits: { messages: 24, characters: 24000 },
};
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status });
const reply = (provider = "qwen", text = "Hello", id = "response-1") =>
  json({
    provider,
    model: provider === "qwen" ? "qwen3.7-plus" : "openai/gpt-oss-20b",
    reply: text,
    response_id: provider === "qwen" ? id : null,
  });
async function setup(groq = true) {
  const fetchMock = vi.fn().mockResolvedValueOnce(
    json({
      ...config,
      models: config.models.map((model) => ({
        ...model,
        configured: model.provider === "qwen" || groq,
      })),
    }),
  );
  vi.stubGlobal("fetch", fetchMock);
  const onClose = vi.fn();
  const view = render(<CyberRoboChat open onClose={onClose} />);
  await waitFor(() =>
    expect((screen.getByLabelText("Model") as HTMLSelectElement).disabled).toBe(false),
  );
  return { fetchMock, onClose, view, user: userEvent.setup() };
}
async function ask(text: string) {
  fireEvent.change(screen.getByLabelText("Your message"), { target: { value: text } });
  fireEvent.click(screen.getByRole("button", { name: "Send" }));
  await waitFor(() =>
    expect((screen.getByLabelText("Your message") as HTMLTextAreaElement).readOnly).toBe(false),
  );
}
function lastBody(fetchMock: ReturnType<typeof vi.fn>) {
  return JSON.parse(fetchMock.mock.calls.at(-1)![1].body);
}

describe("CyberRobo chat", () => {
  it("loads models only when opened and lets the player retry a configuration failure", async () => {
    const fetchMock = vi
      .fn()
      .mockRejectedValueOnce(new Error("offline"))
      .mockResolvedValueOnce(json(config));
    vi.stubGlobal("fetch", fetchMock);
    const view = render(<CyberRoboChat open={false} onClose={() => {}} />);
    expect(fetchMock).not.toHaveBeenCalled();
    view.rerender(<CyberRoboChat open onClose={() => {}} />);
    await screen.findByRole("alert");
    fireEvent.click(screen.getByRole("button", { name: "Try again" }));
    await waitFor(() =>
      expect((screen.getByLabelText("Model") as HTMLSelectElement).disabled).toBe(false),
    );
    expect(fetchMock.mock.calls[0][0]).toBe("/chat-api/models");
  });

  it("continues Qwen only from a successful reply and keeps the draft after failure", async () => {
    const { fetchMock } = await setup();
    fetchMock.mockResolvedValueOnce(reply("qwen", "I will remember MUZI.", "r1"));
    await ask("My nickname is MUZI.");
    expect(lastBody(fetchMock)).toEqual({
      provider: "qwen",
      message: "My nickname is MUZI.",
      previous_response_id: null,
      history: [],
    });
    fetchMock.mockResolvedValueOnce(json({ detail: "private upstream detail" }, 503));
    await ask("What is my nickname?");
    expect(screen.getByRole("alert").textContent).not.toContain("private upstream");
    expect((screen.getByLabelText("Your message") as HTMLTextAreaElement).value).toBe(
      "What is my nickname?",
    );
    fetchMock.mockResolvedValueOnce(reply("qwen", "MUZI.", "r2"));
    fireEvent.click(screen.getByRole("button", { name: "Send" }));
    await screen.findByText("MUZI.");
    expect(lastBody(fetchMock).previous_response_id).toBe("r1");
    expect(lastBody(fetchMock).history).toEqual([]);
    expect(fetchMock.mock.calls.at(-1)![1].credentials).toBe("omit");
  });

  it("sends complete Groq exchanges and clears both models when switching back", async () => {
    const { fetchMock, user } = await setup();
    await user.selectOptions(screen.getByLabelText("Model"), "groq");
    fetchMock.mockResolvedValueOnce(reply("groq", "Hello Maple."));
    await ask("Call me Maple.");
    fetchMock.mockResolvedValueOnce(reply("groq", "Your nickname is Maple."));
    await ask("What is my nickname?");
    expect(lastBody(fetchMock)).toEqual({
      provider: "groq",
      message: "What is my nickname?",
      previous_response_id: null,
      history: [
        { role: "user", content: "Call me Maple." },
        { role: "assistant", content: "Hello Maple." },
      ],
    });
    await user.selectOptions(screen.getByLabelText("Model"), "qwen");
    expect(screen.queryByText("Hello Maple.")).toBeNull();
    fetchMock.mockResolvedValueOnce(reply());
    await ask("Hello");
    expect(lastBody(fetchMock).previous_response_id).toBeNull();
    await user.selectOptions(screen.getByLabelText("Model"), "groq");
    fetchMock.mockResolvedValueOnce(reply("groq"));
    await ask("Fresh chat");
    expect(lastBody(fetchMock).history).toEqual([]);
  });

  it("ignores a late old-model reply without clearing the new model's pending request", async () => {
    const { fetchMock, user } = await setup();
    let finishOld!: (response: Response) => void;
    let finishNew!: (response: Response) => void;
    fetchMock.mockImplementationOnce(
      () =>
        new Promise<Response>((resolve) => {
          finishOld = resolve;
        }),
    );
    fireEvent.change(screen.getByLabelText("Your message"), { target: { value: "Old question" } });
    fireEvent.click(screen.getByRole("button", { name: "Send" }));
    const oldSignal = fetchMock.mock.calls.at(-1)![1].signal as AbortSignal;
    await user.selectOptions(screen.getByLabelText("Model"), "groq");
    expect(oldSignal.aborted).toBe(true);
    fetchMock.mockImplementationOnce(
      () =>
        new Promise<Response>((resolve) => {
          finishNew = resolve;
        }),
    );
    fireEvent.change(screen.getByLabelText("Your message"), { target: { value: "New question" } });
    fireEvent.click(screen.getByRole("button", { name: "Send" }));
    await act(async () => finishOld(reply("qwen", "Old answer")));
    expect(screen.queryByText("Old answer")).toBeNull();
    expect((screen.getByRole("button", { name: "Send" }) as HTMLButtonElement).disabled).toBe(true);
    await act(async () => finishNew(reply("groq", "New answer")));
    expect(screen.getByText("New answer")).toBeInstanceOf(HTMLElement);
  });

  it("preserves successful messages on close and clears them with New chat", async () => {
    const { fetchMock, view, onClose } = await setup();
    fetchMock.mockResolvedValueOnce(reply("qwen", "Remembered.", "r1"));
    await ask("Remember me");
    view.rerender(<CyberRoboChat open={false} onClose={onClose} />);
    view.rerender(<CyberRoboChat open onClose={onClose} />);
    expect(screen.getByText("Remembered.")).toBeInstanceOf(HTMLElement);
    fireEvent.click(screen.getByRole("button", { name: "New chat" }));
    expect(screen.queryByText("Remembered.")).toBeNull();
    fetchMock.mockResolvedValueOnce(reply());
    await ask("New conversation");
    expect(lastBody(fetchMock).previous_response_id).toBeNull();
  });

  it("keeps focus in the dialog and supports Escape and IME input", async () => {
    const { fetchMock, user, onClose } = await setup();
    const textarea = screen.getByLabelText("Your message");
    expect(document.activeElement).toBe(textarea);
    fireEvent.change(textarea, { target: { value: "你好" } });
    fireEvent.keyDown(textarea, { key: "Enter", isComposing: true, keyCode: 229 });
    expect(fetchMock).toHaveBeenCalledTimes(1);
    screen.getByRole("button", { name: "Send" }).focus();
    await user.tab();
    expect(document.activeElement).toBe(screen.getByRole("button", { name: "Close chat" }));
    await user.tab({ shift: true });
    expect(document.activeElement).toBe(screen.getByRole("button", { name: "Send" }));
    await user.keyboard("{Escape}");
    expect(onClose).toHaveBeenCalledOnce();
  });

  it("disables unconfigured Groq and renders model output as text", async () => {
    const { fetchMock } = await setup(false);
    expect((screen.getByRole("option", { name: /Groq/ }) as HTMLOptionElement).disabled).toBe(true);
    fetchMock.mockResolvedValueOnce(reply("qwen", '<img src=x onerror="alert(1)">'));
    await ask("Show an HTML example");
    const log = screen.getByRole("log");
    expect(within(log).getByText('<img src=x onerror="alert(1)">')).toBeInstanceOf(HTMLElement);
    expect(log.querySelector("img")).toBeNull();
  });

  it("drops oldest whole exchanges for both history limits", () => {
    const history: ChatMessage[] = Array.from({ length: 28 }, (_, index) => ({
      role: index % 2 ? "assistant" : "user",
      content: `${index} abc`,
    }));
    const recent = trimChatHistory(history, { messages: 24, characters: 24000 });
    expect(recent).toEqual(history.slice(4));
    const short = trimChatHistory(history, { messages: 24, characters: 30 });
    expect(short[0].role).toBe("user");
    expect(short.length % 2).toBe(0);
    expect(short.reduce((sum, item) => sum + item.content.length, 0)).toBeLessThanOrEqual(30);
  });
});
