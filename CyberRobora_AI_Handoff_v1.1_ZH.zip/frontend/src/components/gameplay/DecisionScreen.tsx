/**
 * @file DecisionScreen reusable presentation component used by routed gameplay experiences.
 */
import { useState, type ReactNode } from "react";
import CyberRoboSVG from "../CyberRoboSVG";
import type { DecisionScreenContent } from "../../content/types";
import type { EvidenceId } from "../../game/types";
import { getEvidenceText } from "../../game/evidence";
import PageHeader from "./PageHeader";

/** Defines the shared PresentedDecisionOption contract. */
export interface PresentedDecisionOption<DecisionId extends string> {
  readonly id: DecisionId;
  readonly action: string;
  readonly description: string;
  readonly icon: ReactNode;
}

interface Props<DecisionId extends string> {
  readonly content: DecisionScreenContent<DecisionId>;
  readonly choices: readonly PresentedDecisionOption<DecisionId>[];
  readonly markedEvidenceIds: readonly EvidenceId[];
  readonly accent: "teal" | "indigo";
  readonly onConfirm: (choice: DecisionId) => void;
  readonly onBack: () => void;
  readonly submitting?: boolean;
  readonly submissionError?: string | null;
}

/**
 * Shared presentation for both scenarios. `pendingId` is deliberately local and reversible; only
 * the explicit confirmation callback commits a typed decision to GameSession.
 */
export default function DecisionScreen<DecisionId extends string>({
  content,
  choices,
  markedEvidenceIds,
  accent,
  onConfirm,
  onBack,
  submitting = false,
  submissionError = null,
}: Props<DecisionId>) {
  const [pendingId, setPendingId] = useState<DecisionId | null>(null);
  const [evidenceExpanded, setEvidenceExpanded] = useState(false);
  const pendingChoice = choices.find((choice) => choice.id === pendingId) ?? null;
  const accentDot = accent === "teal" ? "bg-teal" : "bg-indigo";
  const accentSoftDot = accent === "teal" ? "bg-teal/60" : "bg-indigo/60";
  const unselected =
    accent === "teal" ? "border-ink/18 hover:border-ink/35" : "border-ink/15 hover:border-ink/30";
  const confirmHover = accent === "teal" ? "hover:bg-teal" : "hover:bg-indigo";

  return (
    <div className="min-h-dvh bg-paper flex flex-col">
      <PageHeader
        center={content.headerContext}
        onBack={onBack}
        backLabel="Investigation"
        backAriaLabel="Return to investigation"
      />
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-[1fr_320px] xl:grid-cols-[1fr_360px] overflow-auto">
        <div className="p-4 sm:p-6 lg:p-10 w-full max-w-2xl mx-auto min-w-0">
          <div className="mb-6">
            <h1
              className="text-2xl font-semibold text-ink mb-2"
              style={{ fontFamily: "'Outfit', sans-serif" }}
            >
              What would you like to do?
            </h1>
            <p
              className="text-sm text-muted leading-6"
              style={{ fontFamily: "'Outfit', sans-serif" }}
            >
              {content.intro}
            </p>
          </div>
          {markedEvidenceIds.length > 0 && (
            <div className="mb-6 border border-ink/15 rounded-sm overflow-hidden">
              <button
                onClick={() => setEvidenceExpanded((expanded) => !expanded)}
                className="w-full flex items-center justify-between px-4 py-3 bg-paper-dark hover:bg-paper-darker transition-colors text-left"
                aria-expanded={evidenceExpanded}
                aria-controls="evidence-summary"
                style={{ fontFamily: "'Outfit', sans-serif" }}
              >
                <span className="text-xs text-ink flex items-center gap-2">
                  <span className={`w-1.5 h-1.5 rounded-full ${accentDot}`} aria-hidden="true" />
                  {markedEvidenceIds.length} evidence item
                  {markedEvidenceIds.length !== 1 ? "s" : ""} collected
                </span>
                <svg
                  width="14"
                  height="14"
                  viewBox="0 0 14 14"
                  fill="none"
                  aria-hidden="true"
                  className={`transition-transform ${evidenceExpanded ? "rotate-180" : ""}`}
                >
                  <path
                    d="M2 5l5 5 5-5"
                    stroke="#7A6B5D"
                    strokeWidth="1.3"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </button>
              {evidenceExpanded && (
                <ul
                  id="evidence-summary"
                  className="px-4 py-3 space-y-1.5 bg-paper border-t border-ink/10"
                >
                  {markedEvidenceIds.map((id) => (
                    <li
                      key={id}
                      className="flex items-start gap-2 text-xs text-ink/70"
                      style={{ fontFamily: "'Outfit', sans-serif" }}
                    >
                      <span
                        className={`w-1.5 h-1.5 rounded-full ${accentSoftDot} mt-1.5 flex-shrink-0`}
                        aria-hidden="true"
                      />
                      {getEvidenceText(id)}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          )}
          <fieldset>
            <legend className="sr-only">{content.legend}</legend>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-5">
              {choices.map((choice) => {
                const isSelected = pendingId === choice.id;
                return (
                  <button
                    key={choice.id}
                    onClick={() =>
                      setPendingId((previous) => (previous === choice.id ? null : choice.id))
                    }
                    aria-pressed={isSelected}
                    className={`text-left rounded-sm px-5 py-4 transition-all border group ${isSelected ? "bg-paper-dark border-ink/60 shadow-sm" : `bg-paper ${unselected} hover:bg-paper-dark`}`}
                    aria-label={`${choice.action}: ${choice.description}`}
                  >
                    <div className="flex items-start gap-3 mb-2.5">
                      <span
                        className={`flex-shrink-0 mt-0.5 transition-colors ${isSelected ? "text-ink" : "text-muted group-hover:text-ink/70"}`}
                      >
                        {choice.icon}
                      </span>
                      <span
                        className={`text-sm font-semibold leading-snug transition-colors ${isSelected ? "text-ink" : "text-ink/85"}`}
                        style={{ fontFamily: "'Outfit', sans-serif" }}
                      >
                        {choice.action}
                      </span>
                    </div>
                    <p
                      className="text-xs text-muted leading-5 pl-9"
                      style={{ fontFamily: "'Outfit', sans-serif" }}
                    >
                      {choice.description}
                    </p>
                  </button>
                );
              })}
            </div>
          </fieldset>
          {pendingChoice && (
            <div className="border border-ink/20 rounded-sm bg-paper-dark px-5 py-4 space-y-4">
              <div>
                <p
                  className="text-[9px] tracking-[0.2em] uppercase text-muted mb-1"
                  style={{ fontFamily: "'Outfit', sans-serif" }}
                >
                  Selected
                </p>
                <p
                  className="text-sm font-semibold text-ink"
                  style={{ fontFamily: "'Outfit', sans-serif" }}
                >
                  {pendingChoice.action}
                </p>
                <p
                  className="text-xs text-muted leading-5 mt-0.5"
                  style={{ fontFamily: "'Outfit', sans-serif" }}
                >
                  {pendingChoice.description}
                </p>
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setPendingId(null)}
                  disabled={submitting}
                  className="text-xs text-muted hover:text-ink border border-ink/20 px-4 py-2 rounded-sm transition-colors"
                  style={{ fontFamily: "'Outfit', sans-serif" }}
                  aria-label="Change your selection"
                >
                  Change
                </button>
                <button
                  onClick={() => onConfirm(pendingChoice.id)}
                  disabled={submitting}
                  className={`flex-1 flex items-center justify-center gap-2 bg-ink text-paper text-xs font-medium px-5 py-2.5 rounded-sm ${confirmHover} transition-colors`}
                  style={{ fontFamily: "'Outfit', sans-serif" }}
                  aria-label={`Confirm: ${pendingChoice.action}`}
                >
                  {submitting ? "Recording Decision…" : "Confirm Decision"}
                  <svg width="12" height="12" viewBox="0 0 14 14" fill="none" aria-hidden="true">
                    <path
                      d="M2.5 7h9M8 3.5l3.5 3.5L8 10.5"
                      stroke="currentColor"
                      strokeWidth="1.4"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </button>
              </div>
              {submissionError && (
                <p role="alert" className="text-xs text-coral">
                  {submissionError}
                </p>
              )}
            </div>
          )}
        </div>
        <aside
          className="border-t lg:border-t-0 lg:border-l border-ink/10 bg-paper-dark p-6 flex flex-col gap-6"
          aria-label="CyberRobo companion and scenario context"
        >
          <div className="flex items-start gap-4">
            <CyberRoboSVG size={80} className="flex-shrink-0" />
            <div className="flex-1">
              <p
                className="text-[9px] tracking-[0.2em] uppercase text-muted mb-2"
                style={{ fontFamily: "'Outfit', sans-serif" }}
              >
                CyberRobo
              </p>
              <div
                className="bg-paper border border-ink/15 rounded-sm px-3 py-2.5"
                role="status"
                aria-live="polite"
              >
                <p
                  className="text-xs text-ink/80 leading-5 italic"
                  style={{ fontFamily: "'Outfit', sans-serif" }}
                >
                  {pendingChoice ? content.selectedDialogue : content.idleDialogue}
                </p>
              </div>
            </div>
          </div>
          <div className="bg-paper border border-ink/10 rounded-sm px-4 py-4 space-y-3">
            <p
              className="text-[9px] tracking-[0.2em] uppercase text-muted"
              style={{ fontFamily: "'Outfit', sans-serif" }}
            >
              Scenario
            </p>
            <dl className="space-y-2">
              {[
                ...content.contextRows,
                {
                  label: "Evidence gathered",
                  value: `${markedEvidenceIds.length} of ${content.evidenceTotalLabel}`,
                },
              ].map(({ label, value }) => (
                <div key={label}>
                  <dt
                    className="text-[9px] uppercase tracking-wide text-muted"
                    style={{ fontFamily: "'Outfit', sans-serif" }}
                  >
                    {label}
                  </dt>
                  <dd
                    className="text-xs text-ink/80 leading-5 mt-0.5"
                    style={{ fontFamily: "'Outfit', sans-serif" }}
                  >
                    {value}
                  </dd>
                </div>
              ))}
            </dl>
          </div>
          <p
            className="text-[10px] text-muted/60 leading-4 border border-dashed border-ink/12 rounded-sm px-3 py-2.5"
            style={{ fontFamily: "'Outfit', sans-serif" }}
            role="note"
          >
            {content.note}
          </p>
        </aside>
      </div>
    </div>
  );
}
