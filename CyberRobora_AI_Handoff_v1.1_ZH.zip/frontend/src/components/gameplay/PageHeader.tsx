/**
 * @file PageHeader reusable presentation component used by routed gameplay experiences.
 */
import type { ReactNode } from "react";

interface Props {
  center: ReactNode;
  onBack?: () => void;
  backLabel?: string;
  backAriaLabel?: string;
}

/** Renders the PageHeader experience/component and coordinates its user-facing callbacks. */
export default function PageHeader({ center, onBack, backLabel, backAriaLabel }: Props) {
  return (
    <header className="flex flex-wrap items-center justify-between gap-2 px-3 sm:px-6 py-3 border-b border-ink/10 bg-paper-dark">
      {onBack ? (
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-xs text-muted hover:text-ink transition-colors"
          style={{ fontFamily: "'Outfit', sans-serif" }}
          aria-label={backAriaLabel}
        >
          <svg width="14" height="14" viewBox="0 0 16 16" fill="none" aria-hidden="true">
            <path
              d="M13 8H3M7 4l-4 4 4 4"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
          {backLabel}
        </button>
      ) : (
        <div />
      )}
      <div
        className="text-xs text-muted text-center"
        style={{ fontFamily: "'Outfit', sans-serif" }}
      >
        {center}
      </div>
      <div className="hidden sm:block w-24" aria-hidden="true" />
    </header>
  );
}
