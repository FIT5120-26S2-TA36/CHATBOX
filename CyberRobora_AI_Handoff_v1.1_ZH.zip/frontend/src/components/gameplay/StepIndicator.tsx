/**
 * @file StepIndicator reusable presentation component used by routed gameplay experiences.
 */
interface Props {
  step: 1 | 2 | 3;
  accent: "teal" | "indigo";
}

const steps = ["Region", "Investigate", "Decide"];

/** Shared semantic progress marker for the two visually matched investigation flows. */
export default function StepIndicator({ step, accent }: Props) {
  const activeTone =
    accent === "teal" ? "bg-teal text-paper border-teal" : "bg-indigo text-paper border-indigo";

  return (
    <ol className="flex items-center gap-1" aria-label="Investigation steps">
      {steps.map((label, i) => {
        const n = i + 1;
        const active = n === step;
        const done = n < step;
        return (
          <li key={label} className="flex items-center gap-1">
            <span
              className={`flex items-center justify-center w-5 h-5 rounded-full text-[9px] font-medium border ${
                active
                  ? activeTone
                  : done
                    ? "bg-ink/20 text-muted border-ink/20"
                    : "bg-transparent text-muted/50 border-ink/15"
              }`}
              aria-current={active ? "step" : undefined}
            >
              {done ? (
                <svg width="8" height="8" viewBox="0 0 8 8" fill="none" aria-hidden="true">
                  <path
                    d="M1.5 4l2 2 3-3"
                    stroke="currentColor"
                    strokeWidth="1.2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              ) : (
                n
              )}
            </span>
            <span
              className={`hidden sm:inline text-[10px] tracking-wide ${active ? "text-ink font-medium" : "text-muted"}`}
              style={{ fontFamily: "'Outfit', sans-serif" }}
            >
              {label}
            </span>
            {i < steps.length - 1 && (
              <span className="text-ink/15 mx-1 text-xs" aria-hidden="true">
                ·
              </span>
            )}
          </li>
        );
      })}
    </ol>
  );
}
