/**
 * @file RegionStatCard reusable presentation component used by routed gameplay experiences.
 */
import type { RegionStat } from "../../content/types";
export default function RegionStatCard({ label, value, color }: RegionStat) {
  return (
    <div className="bg-paper-dark border border-ink/10 rounded-sm px-4 py-3">
      <dt
        className="text-[9px] tracking-[0.2em] uppercase text-muted mb-0.5"
        style={{ fontFamily: "'Outfit', sans-serif" }}
      >
        {label}
      </dt>
      <dd className={`text-sm font-medium ${color}`} style={{ fontFamily: "'Outfit', sans-serif" }}>
        {value}
      </dd>
    </div>
  );
}
