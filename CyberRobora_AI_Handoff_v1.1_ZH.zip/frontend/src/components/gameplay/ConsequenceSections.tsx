/**
 * @file ConsequenceSections reusable presentation component used by routed gameplay experiences.
 */
import CyberRoboSVG from "../CyberRoboSVG";
import type { ResultContent } from "../../api/cyberroboraApi";

interface Props {
  content: ResultContent;
  accent: "teal" | "indigo";
  reflection: string;
}

/** Renders the ConsequenceSections experience/component and coordinates its user-facing callbacks. */
export default function ConsequenceSections({ content, accent, reflection }: Props) {
  const dotClass = accent === "teal" ? "bg-teal" : "bg-indigo";
  return (
    <>
      <section aria-labelledby="what-happened">
        <h2
          id="what-happened"
          className="text-[10px] tracking-[0.25em] uppercase text-muted mb-4"
          style={{ fontFamily: "'Outfit', sans-serif" }}
        >
          What happened
        </h2>
        <div className="space-y-3">
          {content.paragraphs.map((paragraph) => (
            <p
              key={paragraph}
              className="text-sm text-ink/80 leading-7"
              style={{ fontFamily: "'Outfit', sans-serif" }}
            >
              {paragraph}
            </p>
          ))}
        </div>
      </section>
      <section aria-labelledby="evidence-mattered">
        <h2
          id="evidence-mattered"
          className="text-[10px] tracking-[0.25em] uppercase text-muted mb-4"
          style={{ fontFamily: "'Outfit', sans-serif" }}
        >
          Evidence that mattered
        </h2>
        <ul className="space-y-2.5">
          {content.relevantEvidence.map((item) => (
            <li
              key={item.label}
              className="flex items-start gap-3 bg-paper-dark border border-ink/10 rounded-sm px-4 py-3"
            >
              <span
                className={`w-1.5 h-1.5 rounded-full ${dotClass} flex-shrink-0 mt-1.5`}
                aria-hidden="true"
              />
              <div>
                <span
                  className="text-xs font-medium text-ink block mb-0.5"
                  style={{ fontFamily: "'Outfit', sans-serif" }}
                >
                  {item.label}
                </span>
                <span
                  className="text-xs text-muted leading-5"
                  style={{ fontFamily: "'Outfit', sans-serif" }}
                >
                  {item.detail}
                </span>
              </div>
            </li>
          ))}
        </ul>
      </section>
      <section aria-labelledby="cyberrobo-reflection">
        <h2 id="cyberrobo-reflection" className="sr-only">
          CyberRobo reflection
        </h2>
        <div className="flex items-start gap-5 bg-paper-dark border border-ink/10 rounded-sm px-5 py-4">
          <CyberRoboSVG size={72} className="flex-shrink-0" />
          <div className="flex-1">
            <p
              className="text-[9px] tracking-[0.2em] uppercase text-muted mb-2"
              style={{ fontFamily: "'Outfit', sans-serif" }}
            >
              CyberRobo
            </p>
            <p
              className="text-sm text-ink/80 leading-6 italic"
              style={{ fontFamily: "'Outfit', sans-serif" }}
            >
              &quot;{reflection}&quot;
            </p>
          </div>
        </div>
      </section>
      <section aria-labelledby="safer-action">
        <h2
          id="safer-action"
          className="text-[10px] tracking-[0.25em] uppercase text-muted mb-3"
          style={{ fontFamily: "'Outfit', sans-serif" }}
        >
          In practice
        </h2>
        <div className="border-l-2 border-ochre/50 pl-4 py-1">
          <p
            className="text-sm text-ink/75 leading-7"
            style={{ fontFamily: "'Outfit', sans-serif" }}
          >
            {content.saferAction}
          </p>
        </div>
      </section>
      {content.sourceReference && (
        <section
          className="border border-ink/10 rounded-sm px-4 py-4 bg-paper-dark"
          aria-labelledby="guidance-source"
        >
          <p
            id="guidance-source"
            className="text-[9px] tracking-[0.2em] uppercase text-muted mb-2"
            style={{ fontFamily: "'Outfit', sans-serif" }}
          >
            {content.sourceReference.heading}
          </p>
          <p
            className="text-xs text-ink/70 leading-5 mb-2"
            style={{ fontFamily: "'Outfit', sans-serif" }}
          >
            {content.sourceReference.text}
          </p>
          <p className="text-[10px] text-muted" style={{ fontFamily: "'Outfit', sans-serif" }}>
            {content.sourceReference.source} ·{" "}
            <a
              className="inline-flex items-center underline underline-offset-2"
              href={`https://${content.sourceReference.url}`}
              target="_blank"
              rel="noreferrer"
              aria-label={`${content.sourceReference.source} reference: ${content.sourceReference.url} (opens in a new tab)`}
            >
              {content.sourceReference.url}
            </a>
          </p>
        </section>
      )}
    </>
  );
}
