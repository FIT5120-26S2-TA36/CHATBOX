/**
 * @file ExperienceHost reusable presentation component used by routed gameplay experiences.
 */
import type { ReactNode } from "react";

interface Props {
  active: boolean;
  children: ReactNode;
}

/** Renders the ExperienceHost experience/component and coordinates its user-facing callbacks. */
export default function ExperienceHost({ active, children }: Props) {
  return active ? children : null;
}
