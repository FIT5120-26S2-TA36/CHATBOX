import { useCallback, useEffect, useRef, useState } from "react";
import {
  getChatModels,
  sendChat,
  trimChatHistory,
  type ChatConfig,
  type ChatMessage,
  type ChatProvider,
} from "../api/chatApi";
import "./CyberRoboChat.css";

interface Props {
  open: boolean;
  onClose: () => void;
}

/** Kept mounted by App so closing the panel or changing game routes preserves the chat. */
export default function CyberRoboChat({ open, onClose }: Props) {
  const [provider, setProvider] = useState<ChatProvider>("qwen");
  const [config, setConfig] = useState<ChatConfig | null>(null);
  const [configError, setConfigError] = useState("");
  const [loadAttempt, setLoadAttempt] = useState(0);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [draft, setDraft] = useState("");
  const [pending, setPending] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const responseId = useRef<string | null>(null);
  const history = useRef<ChatMessage[]>([]);
  const version = useRef(0);
  const request = useRef<AbortController | null>(null);
  const panel = useRef<HTMLDivElement>(null);
  const input = useRef<HTMLTextAreaElement>(null);
  const log = useRef<HTMLDivElement>(null);

  const cancelRequest = useCallback(() => {
    version.current += 1;
    request.current?.abort();
    request.current = null;
    setBusy(false);
    setPending("");
  }, []);

  useEffect(() => {
    if (!open) cancelRequest();
    return () => {
      version.current += 1;
      request.current?.abort();
      request.current = null;
    };
  }, [open, cancelRequest]);

  useEffect(() => {
    if (!open || config) return;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 10000);
    let active = true;
    setConfigError("");
    void getChatModels(controller.signal)
      .then((result) => {
        if (active) setConfig(result);
      })
      .catch((failure) => {
        if (active)
          setConfigError(
            controller.signal.aborted
              ? "The chat service did not respond. Please try again."
              : failure instanceof Error
                ? failure.message
                : "Cannot load chat models.",
          );
      })
      .finally(() => clearTimeout(timer));
    return () => {
      active = false;
      controller.abort();
      clearTimeout(timer);
    };
  }, [open, config, loadAttempt]);

  useEffect(() => {
    if (!open) return;
    input.current?.focus({ preventScroll: true });
    function onKeyDown(event: KeyboardEvent) {
      if (event.isComposing) return;
      if (event.key === "Escape") {
        event.preventDefault();
        onClose();
        return;
      }
      if (event.key !== "Tab") return;
      const items = Array.from(
        panel.current?.querySelectorAll<HTMLElement>(
          'button:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex="0"]',
        ) ?? [],
      );
      const index = items.indexOf(document.activeElement as HTMLElement);
      if (!items.length) return;
      if (event.shiftKey && index <= 0) {
        event.preventDefault();
        items[items.length - 1].focus();
      } else if (!event.shiftKey && (index === -1 || index === items.length - 1)) {
        event.preventDefault();
        items[0].focus();
      }
    }
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, [open, onClose]);

  useEffect(() => {
    if (open && log.current) log.current.scrollTop = log.current.scrollHeight;
  }, [open, messages, pending, error]);

  function newChat(nextProvider = provider) {
    cancelRequest();
    responseId.current = null;
    history.current = [];
    setMessages([]);
    setDraft("");
    setError("");
    setProvider(nextProvider);
    input.current?.focus();
  }

  async function submit() {
    const question = draft.trim();
    if (!question || !config || request.current || question.length > 4000) return;
    if (!config.models.some((model) => model.provider === provider && model.configured)) return;
    const controller = new AbortController();
    request.current = controller;
    const currentVersion = version.current;
    const timer = setTimeout(() => controller.abort(), 70000);
    setBusy(true);
    setPending(question);
    setError("");
    try {
      const result = await sendChat(
        {
          provider,
          message: question,
          previous_response_id: provider === "qwen" ? responseId.current : null,
          history: provider === "groq" ? history.current : [],
        },
        controller.signal,
      );
      if (currentVersion !== version.current) return;
      const exchange: ChatMessage[] = [
        { role: "user", content: question },
        { role: "assistant", content: result.reply },
      ];
      responseId.current = result.response_id;
      if (provider === "groq")
        history.current = trimChatHistory([...history.current, ...exchange], config.history_limits);
      setMessages((current) => [...current, ...exchange]);
      setDraft("");
    } catch (failure) {
      if (currentVersion !== version.current) return;
      setError(
        controller.signal.aborted
          ? "The reply took too long. Please try again."
          : failure instanceof Error
            ? failure.message
            : "CyberRobo could not reply. Please try again.",
      );
    } finally {
      clearTimeout(timer);
      if (currentVersion === version.current) {
        request.current = null;
        setBusy(false);
        setPending("");
        input.current?.focus();
      }
    }
  }

  if (!open) return null;
  const modelName = config?.models.find((model) => model.provider === provider)?.label ?? "Qwen";
  return (
    <div className="cyberrobo-chat-overlay">
      <div className="cyberrobo-chat-backdrop" aria-hidden="true" onClick={onClose} />
      <div
        ref={panel}
        id="cyberrobo-chat"
        className="cyberrobo-chat"
        role="dialog"
        aria-modal="true"
        aria-labelledby="cyberrobo-chat-title"
      >
        <header className="cyberrobo-chat-header">
          <h2 id="cyberrobo-chat-title">Chat with CyberRobo</h2>
          <button type="button" onClick={onClose} aria-label="Close chat">
            ×
          </button>
        </header>
        <div className="cyberrobo-chat-controls">
          <label htmlFor="cyberrobo-model">Model</label>
          <select
            id="cyberrobo-model"
            value={provider}
            disabled={!config}
            onChange={(event) => newChat(event.target.value as ChatProvider)}
          >
            {(config?.models ?? [{ provider: "qwen", label: "Qwen", configured: true }]).map(
              (model) => (
                <option key={model.provider} value={model.provider} disabled={!model.configured}>
                  {model.label}
                  {model.configured ? "" : " — unavailable"}
                </option>
              ),
            )}
          </select>
          <button type="button" onClick={() => newChat()}>
            New chat
          </button>
        </div>
        <p className="cyberrobo-chat-note">
          Switching models starts a new chat. Messages go to your selected AI provider.
          {provider === "groq" && config &&
            ` Groq can use up to ${config.history_limits.messages / 2} recent exchanges. Long messages may reach the text limit sooner.`}
          {provider === "groq" && history.current.length < messages.length &&
            " Earlier messages are still visible here, but are no longer sent to the model."}
        </p>
        <div
          ref={log}
          className="cyberrobo-chat-log"
          role="log"
          aria-label="Conversation"
          aria-live="polite"
          aria-relevant="additions text"
          tabIndex={0}
        >
          {!messages.length && !pending && (
            <p className="cyberrobo-chat-welcome">
              Ask about CyberRobora, digital rights, or something else you want to know.
            </p>
          )}
          {messages.map((message, index) => (
            <div key={index} className={`cyberrobo-chat-message ${message.role}`}>
              <p className="cyberrobo-chat-speaker">
                {message.role === "user" ? "You" : modelName}
              </p>
              <p>{message.content}</p>
            </div>
          ))}
          {pending && (
            <div className="cyberrobo-chat-message user">
              <p className="cyberrobo-chat-speaker">You</p>
              <p>{pending}</p>
            </div>
          )}
        </div>
        {configError && (
          <div className="cyberrobo-chat-error" role="alert">
            <p>{configError}</p>
            <button type="button" onClick={() => setLoadAttempt((value) => value + 1)}>
              Try again
            </button>
          </div>
        )}
        {error && (
          <p className="cyberrobo-chat-error" role="alert">
            {error}
          </p>
        )}
        <p className="cyberrobo-chat-status" role="status">
          {busy ? `Waiting for ${modelName}…` : !config && !configError ? "Connecting…" : ""}
        </p>
        <form
          className="cyberrobo-chat-form"
          onSubmit={(event) => {
            event.preventDefault();
            void submit();
          }}
        >
          <label htmlFor="cyberrobo-message">Your message</label>
          <textarea
            ref={input}
            id="cyberrobo-message"
            rows={3}
            maxLength={4000}
            value={draft}
            readOnly={busy}
            onChange={(event) => setDraft(event.target.value)}
            onKeyDown={(event) => {
              if (
                event.key === "Enter" &&
                !event.shiftKey &&
                !event.nativeEvent.isComposing &&
                event.keyCode !== 229
              ) {
                event.preventDefault();
                void submit();
              }
            }}
            placeholder="Type a question…"
          />
          <div className="cyberrobo-chat-send-row">
            <span>Enter to send · Shift + Enter for a new line</span>
            <button type="submit" disabled={busy || !config || !draft.trim()}>
              Send
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
