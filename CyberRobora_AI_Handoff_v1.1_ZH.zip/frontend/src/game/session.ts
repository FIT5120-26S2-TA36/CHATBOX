/**
 * Canonical gameplay state and transitions. Reducer-produced state satisfies the domain
 * invariants; externally supplied state must pass through normalizeGameSession before use.
 */
import type {
  CorvaDecision,
  CorvaEvidenceId,
  DataDistrictDecision,
  DataDistrictEvidenceId,
  DataDistrictExposure,
  RegionId,
} from "./types";

/** Committed evidence, decisions, exposure, and completed regions for the current play session. */
export interface GameSession {
  dataDistrictInvestigationStarted: boolean;
  dataDistrictEvidence: DataDistrictEvidenceId[];
  dataDistrictDecision: DataDistrictDecision | null;
  dataDistrictExposure: DataDistrictExposure | null;
  corvaInvestigationStarted: boolean;
  corvaEvidence: CorvaEvidenceId[];
  corvaDecision: CorvaDecision | null;
  investigatedRegions: RegionId[];
}

/** Keyed but untrusted initialization values accepted only at the normalization boundary. */
export type GameSessionInput = Readonly<{
  [Field in keyof GameSession]?: unknown;
}>;

export const initialGameSession: GameSession = {
  dataDistrictInvestigationStarted: false,
  dataDistrictEvidence: [],
  dataDistrictDecision: null,
  dataDistrictExposure: null,
  corvaInvestigationStarted: false,
  corvaEvidence: [],
  corvaDecision: null,
  investigatedRegions: [],
};

/** Defines the shared GameAction contract. */
export type GameAction =
  | { type: "START_DATA_DISTRICT_INVESTIGATION" }
  | {
      type: "INSPECT_DATA_DISTRICT_EVIDENCE";
      evidenceId: DataDistrictEvidenceId;
    }
  | {
      type: "CONFIRM_DATA_DISTRICT_DECISION";
      decision: DataDistrictDecision;
    }
  | { type: "COMPLETE_DATA_DISTRICT" }
  | { type: "COMPLETE_DATA_DISTRICT_LIVE_MISSION" }
  | {
      type: "HYDRATE_FROM_SERVER";
      investigatedRegions: RegionId[];
      dataDistrictExposure: DataDistrictExposure | null;
    }
  | { type: "START_CORVA_INVESTIGATION" }
  | { type: "INSPECT_CORVA_EVIDENCE"; evidenceId: CorvaEvidenceId }
  | { type: "CONFIRM_CORVA_DECISION"; decision: CorvaDecision }
  | { type: "COMPLETE_CORVA" };

function appendUnique<T>(items: T[], item: T): T[] {
  return items.includes(item) ? items : [...items, item];
}

function exposureForDecision(decision: DataDistrictDecision): DataDistrictExposure {
  return decision === "allow-all" || decision === "allow-later" ? "broad" : "limited";
}

const dataDistrictEvidenceIds = [
  "location-always",
  "contacts-full",
  "photos-all",
  "notifications",
  "data-sharing",
] as const satisfies readonly DataDistrictEvidenceId[];

const corvaEvidenceIds = [
  "sender-address",
  "link-destination",
  "redelivery-fee",
  "time-pressure",
  "unexpected-parcel",
  "personal-context",
] as const satisfies readonly CorvaEvidenceId[];

const dataDistrictDecisions = [
  "allow-all",
  "allow-later",
  "customise",
  "use-website",
] as const satisfies readonly DataDistrictDecision[];

const corvaDecisions = [
  "pay-fee",
  "open-link",
  "open-app",
  "delete-report",
] as const satisfies readonly CorvaDecision[];

function isOneOf<Value extends string>(value: unknown, values: readonly Value[]): value is Value {
  return typeof value === "string" && values.some((candidate) => candidate === value);
}

function uniqueValidValues<Value extends string>(
  input: unknown,
  values: readonly Value[],
): Value[] {
  if (!Array.isArray(input)) return [];
  const valid = input.filter((value): value is Value => isOneOf(value, values));
  return [...new Set(valid)];
}

/**
 * Repairs external input without mutating it: evidence is scenario-filtered and deduplicated,
 * exposure is re-derived from the committed Data District decision, and completion claims lacking
 * prerequisite decisions are removed rather than inventing player choices. Consequently malformed
 * exposure alone cannot enable contextual Corva content.
 */
export function normalizeGameSession(input: GameSessionInput = {}): GameSession {
  const requestedRegions = uniqueValidValues(input.investigatedRegions, [
    "data-district",
    "identity-citadel",
  ] satisfies readonly RegionId[]);
  const dataDistrictDecision = isOneOf(input.dataDistrictDecision, dataDistrictDecisions)
    ? input.dataDistrictDecision
    : null;
  const dataDistrictCompleted =
    requestedRegions.includes("data-district") && dataDistrictDecision !== null;
  const dataDistrictInvestigationStarted =
    input.dataDistrictInvestigationStarted === true || dataDistrictDecision !== null;
  const dataDistrictEvidence = dataDistrictInvestigationStarted
    ? uniqueValidValues(input.dataDistrictEvidence, dataDistrictEvidenceIds)
    : [];
  const dataDistrictExposure = dataDistrictDecision
    ? exposureForDecision(dataDistrictDecision)
    : null;

  const suppliedCorvaDecision = isOneOf(input.corvaDecision, corvaDecisions)
    ? input.corvaDecision
    : null;
  const corvaDecision = dataDistrictCompleted ? suppliedCorvaDecision : null;
  const corvaInvestigationStarted =
    dataDistrictCompleted && (input.corvaInvestigationStarted === true || corvaDecision !== null);
  const corvaEvidence = corvaInvestigationStarted
    ? uniqueValidValues(input.corvaEvidence, corvaEvidenceIds)
    : [];
  const identityCitadelCompleted =
    requestedRegions.includes("identity-citadel") && corvaDecision !== null;
  const investigatedRegions: RegionId[] = [];
  if (dataDistrictCompleted) investigatedRegions.push("data-district");
  if (identityCitadelCompleted) investigatedRegions.push("identity-citadel");

  return {
    dataDistrictInvestigationStarted,
    dataDistrictEvidence,
    dataDistrictDecision,
    dataDistrictExposure,
    corvaInvestigationStarted,
    corvaEvidence,
    corvaDecision,
    investigatedRegions,
  };
}

function assertNever(action: never): never {
  throw new Error(`Unhandled game action: ${JSON.stringify(action)}`);
}

/** Contextual Corva details require both completed Data District progress and committed broad exposure. */
export function isCorvaContextualised(session: GameSession): boolean {
  return (
    session.investigatedRegions.includes("data-district") &&
    session.dataDistrictExposure === "broad"
  );
}

/** Applies typed gameplay transitions; the terminal `never` check keeps the action union exhaustive. */
export function gameSessionReducer(session: GameSession, action: GameAction): GameSession {
  switch (action.type) {
    case "START_DATA_DISTRICT_INVESTIGATION": {
      const isReplay = session.investigatedRegions.includes("data-district");
      const preserveCommittedState = isReplay || session.dataDistrictDecision !== null;
      return {
        ...session,
        dataDistrictInvestigationStarted: true,
        dataDistrictEvidence: preserveCommittedState ? session.dataDistrictEvidence : [],
        dataDistrictDecision: preserveCommittedState ? session.dataDistrictDecision : null,
        dataDistrictExposure: preserveCommittedState ? session.dataDistrictExposure : null,
      };
    }

    case "INSPECT_DATA_DISTRICT_EVIDENCE":
      if (!session.dataDistrictInvestigationStarted) return session;
      return {
        ...session,
        dataDistrictEvidence: appendUnique(session.dataDistrictEvidence, action.evidenceId),
      };

    case "CONFIRM_DATA_DISTRICT_DECISION": {
      if (!session.dataDistrictInvestigationStarted) return session;
      if (session.dataDistrictDecision !== null) return session;

      return {
        ...session,
        dataDistrictDecision: action.decision,
        dataDistrictExposure: exposureForDecision(action.decision),
      };
    }

    case "COMPLETE_DATA_DISTRICT":
      if (!session.dataDistrictDecision || !session.dataDistrictExposure) {
        return session;
      }
      return {
        ...session,
        investigatedRegions: appendUnique(session.investigatedRegions, "data-district"),
      };

    case "COMPLETE_DATA_DISTRICT_LIVE_MISSION":
      if (!session.dataDistrictInvestigationStarted) return session;
      return {
        ...session,
        investigatedRegions: appendUnique(session.investigatedRegions, "data-district"),
      };

    case "HYDRATE_FROM_SERVER": {
      const investigatedRegions = uniqueValidValues(action.investigatedRegions, [
        "data-district",
        "identity-citadel",
      ] satisfies readonly RegionId[]);
      const dataDistrictCompleted = investigatedRegions.includes("data-district");
      const dataDistrictExposure =
        dataDistrictCompleted &&
        (action.dataDistrictExposure === "broad" || action.dataDistrictExposure === "limited")
          ? action.dataDistrictExposure
          : null;
      return {
        ...session,
        dataDistrictInvestigationStarted:
          session.dataDistrictInvestigationStarted || dataDistrictCompleted,
        dataDistrictExposure,
        // Server progress is authoritative for completed regions after reload.
        investigatedRegions,
      };
    }

    case "START_CORVA_INVESTIGATION": {
      if (!session.investigatedRegions.includes("data-district")) return session;
      const isReplay = session.investigatedRegions.includes("identity-citadel");
      const preserveCommittedState = isReplay || session.corvaDecision !== null;
      return {
        ...session,
        corvaInvestigationStarted: true,
        corvaEvidence: preserveCommittedState ? session.corvaEvidence : [],
        corvaDecision: preserveCommittedState ? session.corvaDecision : null,
      };
    }

    case "INSPECT_CORVA_EVIDENCE":
      if (
        !session.corvaInvestigationStarted ||
        !session.investigatedRegions.includes("data-district")
      ) {
        return session;
      }
      return {
        ...session,
        corvaEvidence: appendUnique(session.corvaEvidence, action.evidenceId),
      };

    case "CONFIRM_CORVA_DECISION": {
      if (!session.corvaInvestigationStarted) return session;
      if (session.corvaDecision !== null) return session;

      return {
        ...session,
        corvaDecision: action.decision,
      };
    }

    case "COMPLETE_CORVA":
      if (!session.corvaDecision || !session.investigatedRegions.includes("data-district")) {
        return session;
      }
      return {
        ...session,
        investigatedRegions: appendUnique(session.investigatedRegions, "identity-citadel"),
      };
  }

  return assertNever(action);
}
