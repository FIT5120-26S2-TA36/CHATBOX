/**
 * Total lookup across the closed EvidenceId union. Scenario content owns the text and session
 * normalization owns validity/deduplication, so callers receive a stable explanation without a
 * fallback that could hide an unregistered ID.
 */
import { dataDistrictClues } from "../content/dataDistrict";
import { identityCitadelClues } from "../content/identityCitadel";
import type { EvidenceId } from "./types";

const evidenceText = Object.fromEntries(
  [...dataDistrictClues, ...identityCitadelClues].map((clue) => [clue.id, clue.explanation]),
) as Record<EvidenceId, string>;

/** Provides the public getEvidenceText behavior used across the application. */
export function getEvidenceText(id: EvidenceId): string {
  return evidenceText[id];
}
