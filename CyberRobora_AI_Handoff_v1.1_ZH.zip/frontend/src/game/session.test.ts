/**
 * @file Regression scope for session, including its externally observable contracts and edge cases.
 */
import { describe, expect, it } from "vitest";
import {
  gameSessionReducer,
  initialGameSession,
  isCorvaContextualised,
  normalizeGameSession,
  type GameAction,
  type GameSession,
} from "./session";

function reduce(actions: GameAction[], start = initialGameSession): GameSession {
  return actions.reduce(gameSessionReducer, start);
}

const completeBroadDataDistrict: GameAction[] = [
  { type: "START_DATA_DISTRICT_INVESTIGATION" },
  { type: "INSPECT_DATA_DISTRICT_EVIDENCE", evidenceId: "location-always" },
  { type: "CONFIRM_DATA_DISTRICT_DECISION", decision: "allow-all" },
  { type: "COMPLETE_DATA_DISTRICT" },
];

describe("gameSessionReducer", () => {
  it("completes a server-validated live mission without fabricating a legacy choice", () => {
    const started = gameSessionReducer(initialGameSession, {
      type: "START_DATA_DISTRICT_INVESTIGATION",
    });
    const completed = gameSessionReducer(started, {
      type: "COMPLETE_DATA_DISTRICT_LIVE_MISSION",
    });

    expect(completed.investigatedRegions).toContain("data-district");
    expect(completed.dataDistrictDecision).toBeNull();
    expect(completed.dataDistrictExposure).toBeNull();
  });

  it("hydrates investigated regions and exposure from authoritative server progress", () => {
    const hydrated = gameSessionReducer(initialGameSession, {
      type: "HYDRATE_FROM_SERVER",
      investigatedRegions: ["data-district"],
      dataDistrictExposure: "broad",
    });

    expect(hydrated.investigatedRegions).toEqual(["data-district"]);
    expect(hydrated.dataDistrictExposure).toBe("broad");
    expect(hydrated.dataDistrictInvestigationStarted).toBe(true);
    expect(isCorvaContextualised(hydrated)).toBe(true);
  });

  it("keeps route location out of gameplay session state", () => {
    expect(initialGameSession).not.toHaveProperty("currentPage");
    expect(initialGameSession).not.toHaveProperty("pathname");
  });

  it("starts Data District investigation without fabricating progress", () => {
    const session = gameSessionReducer(initialGameSession, {
      type: "START_DATA_DISTRICT_INVESTIGATION",
    });

    expect(session.dataDistrictInvestigationStarted).toBe(true);
    expect(session.dataDistrictEvidence).toEqual([]);
    expect(session.dataDistrictDecision).toBeNull();
    expect(session.investigatedRegions).toEqual([]);
  });

  it("preserves Data District evidence across router navigation", () => {
    const session = reduce([
      { type: "START_DATA_DISTRICT_INVESTIGATION" },
      { type: "INSPECT_DATA_DISTRICT_EVIDENCE", evidenceId: "contacts-full" },
    ]);

    expect(session.dataDistrictEvidence).toEqual(["contacts-full"]);
  });

  it("preserves Corva evidence across router navigation", () => {
    const session = reduce([
      ...completeBroadDataDistrict,
      { type: "START_CORVA_INVESTIGATION" },
      { type: "INSPECT_CORVA_EVIDENCE", evidenceId: "sender-address" },
    ]);

    expect(session.corvaEvidence).toEqual(["sender-address"]);
  });

  it("commits a decision and exposure atomically", () => {
    const session = reduce([
      { type: "START_DATA_DISTRICT_INVESTIGATION" },
      { type: "CONFIRM_DATA_DISTRICT_DECISION", decision: "customise" },
    ]);

    expect(session.dataDistrictDecision).toBe("customise");
    expect(session.dataDistrictExposure).toBe("limited");
    expect(isCorvaContextualised(session)).toBe(false);
  });

  it("persists broad exposure and contextualises Corva from committed state", () => {
    const session = reduce(completeBroadDataDistrict);

    expect(session.dataDistrictExposure).toBe("broad");
    expect(session.investigatedRegions).toContain("data-district");
    expect(isCorvaContextualised(session)).toBe(true);
  });

  it("does not let a completed Data District replay overwrite committed state", () => {
    const completed = reduce(completeBroadDataDistrict);
    const replayed = reduce(
      [
        { type: "START_DATA_DISTRICT_INVESTIGATION" },
        {
          type: "CONFIRM_DATA_DISTRICT_DECISION",
          decision: "use-website",
        },
      ],
      completed,
    );

    expect(replayed.dataDistrictEvidence).toEqual(completed.dataDistrictEvidence);
    expect(replayed.dataDistrictDecision).toBe("allow-all");
    expect(replayed.dataDistrictExposure).toBe("broad");
    expect(replayed.investigatedRegions).toEqual(["data-district"]);
  });

  it("keeps a confirmed decision stable across browser-history revisits", () => {
    const confirmed = reduce([
      { type: "START_DATA_DISTRICT_INVESTIGATION" },
      { type: "INSPECT_DATA_DISTRICT_EVIDENCE", evidenceId: "contacts-full" },
      { type: "CONFIRM_DATA_DISTRICT_DECISION", decision: "customise" },
    ]);
    const revisited = reduce(
      [
        { type: "START_DATA_DISTRICT_INVESTIGATION" },
        { type: "CONFIRM_DATA_DISTRICT_DECISION", decision: "allow-all" },
      ],
      confirmed,
    );

    expect(revisited.dataDistrictEvidence).toEqual(["contacts-full"]);
    expect(revisited.dataDistrictDecision).toBe("customise");
    expect(revisited.dataDistrictExposure).toBe("limited");
  });

  it("resets an uncompleted restart but preserves a completed replay", () => {
    const partial = reduce([
      { type: "START_DATA_DISTRICT_INVESTIGATION" },
      { type: "INSPECT_DATA_DISTRICT_EVIDENCE", evidenceId: "photos-all" },
      { type: "START_DATA_DISTRICT_INVESTIGATION" },
    ]);
    const completed = reduce(completeBroadDataDistrict);
    const replay = gameSessionReducer(completed, {
      type: "START_DATA_DISTRICT_INVESTIGATION",
    });

    expect(partial.dataDistrictEvidence).toEqual([]);
    expect(replay.dataDistrictEvidence).toEqual(["location-always"]);
    expect(replay.dataDistrictDecision).toBe("allow-all");
  });

  it("rejects evidence, decisions, and completion without prerequisites", () => {
    const invalidEvidence = gameSessionReducer(initialGameSession, {
      type: "INSPECT_DATA_DISTRICT_EVIDENCE",
      evidenceId: "contacts-full",
    });
    const invalidDecision = gameSessionReducer(initialGameSession, {
      type: "CONFIRM_DATA_DISTRICT_DECISION",
      decision: "customise",
    });
    const invalidCompletion = gameSessionReducer(initialGameSession, {
      type: "COMPLETE_DATA_DISTRICT",
    });

    expect(invalidEvidence).toBe(initialGameSession);
    expect(invalidDecision).toBe(initialGameSession);
    expect(invalidCompletion).toBe(initialGameSession);
  });
});

describe("normalizeGameSession", () => {
  it("preserves representative reducer-generated sessions", () => {
    const partialDataDistrict = reduce([
      { type: "START_DATA_DISTRICT_INVESTIGATION" },
      { type: "INSPECT_DATA_DISTRICT_EVIDENCE", evidenceId: "contacts-full" },
    ]);
    const committedDataDistrict = reduce([
      { type: "START_DATA_DISTRICT_INVESTIGATION" },
      { type: "CONFIRM_DATA_DISTRICT_DECISION", decision: "customise" },
    ]);
    const completedDataDistrict = reduce(completeBroadDataDistrict);
    const corvaInvestigation = reduce(
      [
        { type: "START_CORVA_INVESTIGATION" },
        { type: "INSPECT_CORVA_EVIDENCE", evidenceId: "sender-address" },
      ],
      completedDataDistrict,
    );
    const completedIteration = reduce(
      [
        { type: "START_CORVA_INVESTIGATION" },
        { type: "CONFIRM_CORVA_DECISION", decision: "delete-report" },
        { type: "COMPLETE_CORVA" },
      ],
      completedDataDistrict,
    );

    for (const session of [
      initialGameSession,
      partialDataDistrict,
      committedDataDistrict,
      completedDataDistrict,
      corvaInvestigation,
      completedIteration,
    ]) {
      expect(normalizeGameSession(session)).toEqual(session);
    }
  });

  it("deduplicates scenario-valid evidence and drops invalid or wrong-region IDs", () => {
    const normalized = normalizeGameSession({
      dataDistrictInvestigationStarted: true,
      dataDistrictEvidence: [
        "contacts-full",
        "sender-address",
        "contacts-full",
        "not-evidence",
        "location-always",
      ],
      dataDistrictDecision: "allow-all",
      investigatedRegions: ["data-district"],
      corvaInvestigationStarted: true,
      corvaEvidence: ["sender-address", "contacts-full", "sender-address", "not-evidence"],
    });

    expect(normalized.dataDistrictEvidence).toEqual(["contacts-full", "location-always"]);
    expect(normalized.corvaEvidence).toEqual(["sender-address"]);
  });

  it("derives exposure from the committed Data District decision", () => {
    const broad = normalizeGameSession({
      dataDistrictDecision: "allow-all",
      dataDistrictExposure: "limited",
      investigatedRegions: ["data-district"],
    });
    const limited = normalizeGameSession({
      dataDistrictDecision: "customise",
      dataDistrictExposure: "broad",
      investigatedRegions: ["data-district"],
    });

    expect(broad.dataDistrictExposure).toBe("broad");
    expect(isCorvaContextualised(broad)).toBe(true);
    expect(limited.dataDistrictExposure).toBe("limited");
    expect(isCorvaContextualised(limited)).toBe(false);
  });

  it("removes exposure and completion claims that lack required decisions", () => {
    const normalized = normalizeGameSession({
      dataDistrictEvidence: ["notifications"],
      dataDistrictDecision: "invalid-decision",
      dataDistrictExposure: "broad",
      corvaInvestigationStarted: true,
      corvaEvidence: ["sender-address"],
      corvaDecision: "pay-fee",
      investigatedRegions: [
        "identity-citadel",
        "data-district",
        "identity-citadel",
        "social-square",
        "invalid-region",
      ],
    });

    expect(normalized.dataDistrictExposure).toBeNull();
    expect(normalized.dataDistrictEvidence).toEqual([]);
    expect(normalized.investigatedRegions).toEqual([]);
    expect(normalized.corvaInvestigationStarted).toBe(false);
    expect(normalized.corvaEvidence).toEqual([]);
    expect(normalized.corvaDecision).toBeNull();
    expect(isCorvaContextualised(normalized)).toBe(false);
  });

  it("canonicalizes completed regions and removes Identity completion without a Corva decision", () => {
    const normalized = normalizeGameSession({
      dataDistrictDecision: "use-website",
      investigatedRegions: ["identity-citadel", "data-district", "data-district", "inbox-harbour"],
      corvaInvestigationStarted: true,
    });

    expect(normalized.investigatedRegions).toEqual(["data-district"]);
    expect(normalized.corvaInvestigationStarted).toBe(true);
    expect(normalized.corvaDecision).toBeNull();
  });

  it("does not mutate external input", () => {
    const input = {
      dataDistrictInvestigationStarted: true,
      dataDistrictEvidence: ["notifications", "notifications"],
      dataDistrictDecision: "customise",
      dataDistrictExposure: "broad",
      investigatedRegions: ["data-district", "data-district"],
    };
    const before = structuredClone(input);

    const normalized = normalizeGameSession(input);

    expect(input).toEqual(before);
    input.dataDistrictEvidence.push("location-always");
    input.investigatedRegions.push("identity-citadel");
    expect(normalized.dataDistrictEvidence).toEqual(["notifications"]);
    expect(normalized.investigatedRegions).toEqual(["data-district"]);
  });
});
