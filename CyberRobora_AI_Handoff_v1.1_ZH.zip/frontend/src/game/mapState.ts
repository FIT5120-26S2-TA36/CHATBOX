/**
 * Derives Iteration 1 map presentation from canonical completed-region state. Data District is the
 * entry point; its completion unlocks Identity Citadel. Completing the Citadel reveals Inbox
 * Harbour only as a future signal, while Social Square remains locked.
 */
import type { RegionId } from "./types";

/** Defines the shared MapDisplayStatus contract. */
export type MapDisplayStatus =
  | "available"
  | "locked"
  | "investigated"
  | "new-disturbance"
  | "faint-disturbance";

/** Defines the shared mapStatusLabels value. */
export const mapStatusLabels: Readonly<Record<MapDisplayStatus, string>> = {
  available: "Available for investigation",
  locked: "Locked — not yet accessible",
  investigated: "Investigated — original case available for review",
  "new-disturbance": "New disturbance detected — available for investigation",
  "faint-disturbance": "Future signal detected — locked",
};

/** `investigated` means the region's required decision was completed and its original case is replayable. */
export function getMapDisplayStatus(
  regionId: RegionId,
  investigatedRegions: readonly RegionId[],
): MapDisplayStatus {
  const dataDistrictDone = investigatedRegions.includes("data-district");
  const citadelDone = investigatedRegions.includes("identity-citadel");

  if (regionId === "data-district") {
    return dataDistrictDone ? "investigated" : "available";
  }

  if (regionId === "identity-citadel") {
    if (citadelDone) return "investigated";
    return dataDistrictDone ? "new-disturbance" : "locked";
  }

  if (regionId === "inbox-harbour" && citadelDone) {
    return "faint-disturbance";
  }

  return "locked";
}

/** Provides the public canEnterMapRegion behavior used across the application. */
export function canEnterMapRegion(
  regionId: RegionId,
  investigatedRegions: readonly RegionId[],
): boolean {
  const status = getMapDisplayStatus(regionId, investigatedRegions);
  return status === "available" || status === "new-disturbance" || status === "investigated";
}

/** Provides the public isMapConnectionRevealed behavior used across the application. */
export function isMapConnectionRevealed(investigatedRegions: readonly RegionId[]): boolean {
  // The connection is a post-Citadel revelation, not a hint shown during either investigation.
  return (
    investigatedRegions.includes("data-district") &&
    investigatedRegions.includes("identity-citadel")
  );
}
