/** Stable gameplay-region IDs shared by session progress, map state, and canonical routes. */
export type RegionId = "data-district" | "identity-citadel" | "social-square" | "inbox-harbour";

/** Scenario-owned evidence IDs persisted only in the Data District collection. */
export type DataDistrictEvidenceId =
  | "location-always"
  | "contacts-full"
  | "photos-all"
  | "notifications"
  | "data-sharing";

/** Scenario-owned evidence IDs persisted only in the Identity Citadel collection. */
export type CorvaEvidenceId =
  | "sender-address"
  | "link-destination"
  | "redelivery-fee"
  | "time-pressure"
  | "unexpected-parcel"
  | "personal-context";

/** Defines the shared EvidenceId contract. */
export type EvidenceId = DataDistrictEvidenceId | CorvaEvidenceId;

/** Choices become committed only after the decision screen's explicit confirmation step. */
export type DataDistrictDecision = "allow-all" | "allow-later" | "customise" | "use-website";

/** Identity Citadel choices use the same explicit-confirmation commitment contract. */
export type CorvaDecision = "pay-fee" | "open-link" | "open-app" | "delete-report";

/** Derived cross-region privacy breadth; external input must not set this independently. */
export type DataDistrictExposure = "broad" | "limited";
