/**
 * @file Regression scope for mapState, including its externally observable contracts and edge cases.
 */
import { describe, expect, it } from "vitest";
import {
  canEnterMapRegion,
  getMapDisplayStatus,
  isMapConnectionRevealed,
  mapStatusLabels,
} from "./mapState";
import { GAMEPLAY_MAP_LOCATIONS } from "../components/map/mapLocations";
import type { RegionId } from "./types";

const mapRegionOrder = GAMEPLAY_MAP_LOCATIONS.map(({ id }) => id);

function statuses(investigatedRegions: RegionId[]) {
  return Object.fromEntries(
    mapRegionOrder.map((regionId) => [
      regionId,
      getMapDisplayStatus(regionId, investigatedRegions),
    ]),
  );
}

describe("Cyberia map display state", () => {
  it("starts with only Data District available", () => {
    expect(statuses([])).toEqual({
      "data-district": "available",
      "identity-citadel": "locked",
      "social-square": "locked",
      "inbox-harbour": "locked",
    });
    expect(mapRegionOrder.filter((id) => canEnterMapRegion(id, []))).toEqual(["data-district"]);
  });

  it("opens only the Identity Citadel disturbance after Data District", () => {
    const investigated: RegionId[] = ["data-district"];

    expect(statuses(investigated)).toEqual({
      "data-district": "investigated",
      "identity-citadel": "new-disturbance",
      "social-square": "locked",
      "inbox-harbour": "locked",
    });
    expect(mapRegionOrder.filter((id) => canEnterMapRegion(id, investigated))).toEqual([
      "data-district",
      "identity-citadel",
    ]);
    expect(isMapConnectionRevealed(investigated)).toBe(false);
  });

  it("reveals the connection and locked Harbour signal only after both investigations", () => {
    const investigated: RegionId[] = ["data-district", "identity-citadel"];

    expect(statuses(investigated)).toEqual({
      "data-district": "investigated",
      "identity-citadel": "investigated",
      "social-square": "locked",
      "inbox-harbour": "faint-disturbance",
    });
    expect(isMapConnectionRevealed(investigated)).toBe(true);
    expect(canEnterMapRegion("inbox-harbour", investigated)).toBe(false);
  });

  it("never makes Social Square or Inbox Harbour enterable in I1", () => {
    for (const investigated of [
      [],
      ["data-district"],
      ["data-district", "identity-citadel"],
    ] as RegionId[][]) {
      expect(canEnterMapRegion("social-square", investigated)).toBe(false);
      expect(canEnterMapRegion("inbox-harbour", investigated)).toBe(false);
    }
  });

  it("provides explicit accessible text for every visual status", () => {
    expect(Object.values(mapStatusLabels)).toEqual([
      "Available for investigation",
      "Locked — not yet accessible",
      "Investigated — original case available for review",
      "New disturbance detected — available for investigation",
      "Future signal detected — locked",
    ]);
  });
});
