/**
 * @file CorvaInvestigation routed experience, responsible for composing its content, state callbacks, and accessible UI.
 */
import CyberRoboSVG from "../components/CyberRoboSVG";
import Button from "../components/Button";
import StepIndicator from "../components/gameplay/StepIndicator";
import { getIdentityCitadelClues, identityCitadelScenario } from "../content/identityCitadel";
import type { CorvaEvidenceId } from "../game/types";
import useEvidenceInspection from "../hooks/useEvidenceInspection";

interface Props {
  evidence: CorvaEvidenceId[];
  onAddEvidence: (evidenceId: CorvaEvidenceId) => void;
  onBack: () => void;
  onDecide: () => void;
  isContextualised: boolean;
}

interface InspectableItem {
  id: CorvaEvidenceId;
  label: string;
  evidence: string;
  contextualised?: boolean;
}

const corvaOrange = "#D4622A";

const allItems: InspectableItem[] = identityCitadelScenario.clues.map((clue) => ({
  id: clue.id,
  label: clue.label,
  evidence: clue.explanation,
  contextualised: clue.variant === "contextualised",
}));
const cyberRoboDialogues = identityCitadelScenario.investigationDialogue.lines;

function MagnifyIcon() {
  return (
    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" aria-hidden="true">
      <circle cx="5" cy="5" r="3.5" stroke="currentColor" strokeWidth="1.3" />
      <path d="M7.5 7.5l2.5 2.5" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
    </svg>
  );
}

function CheckSmallIcon() {
  return (
    <svg width="11" height="11" viewBox="0 0 11 11" fill="none" aria-hidden="true">
      <path
        d="M2 5.5l2.5 2.5L9 3"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function CorvaLogoIcon() {
  return (
    <svg width="36" height="36" viewBox="0 0 36 36" fill="none" aria-hidden="true">
      <rect width="36" height="36" rx="8" fill="#FDF0E9" />
      <rect x="4" y="14" width="20" height="14" rx="1.5" fill={corvaOrange} fillOpacity="0.85" />
      <path d="M24 18 L32 18 L32 28 L24 28" fill={corvaOrange} fillOpacity="0.9" />
      <path d="M24 18 L30 18 L30 24 L24 24" fill="none" stroke="#FDF0E9" strokeWidth="1" />
      <circle cx="10" cy="29" r="3" fill="#FDF0E9" stroke={corvaOrange} strokeWidth="1.5" />
      <circle cx="27" cy="29" r="3" fill="#FDF0E9" stroke={corvaOrange} strokeWidth="1.5" />
      <rect
        x="8"
        y="17"
        width="10"
        height="8"
        fill="#FDF0E9"
        fillOpacity="0.4"
        stroke="#FDF0E9"
        strokeWidth="0.8"
      />
      <line x1="8" y1="21" x2="18" y2="21" stroke="#FDF0E9" strokeWidth="0.7" strokeOpacity="0.7" />
      <line
        x1="13"
        y1="17"
        x2="13"
        y2="25"
        stroke="#FDF0E9"
        strokeWidth="0.7"
        strokeOpacity="0.7"
      />
    </svg>
  );
}

/** Renders the CorvaInvestigation experience/component and coordinates its user-facing callbacks. */
export default function CorvaInvestigation({
  evidence,
  onAddEvidence,
  onBack,
  onDecide,
  isContextualised,
}: Props) {
  const { inspectedIds, recentlyAdded, inspectEvidence } = useEvidenceInspection(
    evidence,
    onAddEvidence,
  );

  const visibleEvidenceIds = new Set(getIdentityCitadelClues(isContextualised).map(({ id }) => id));
  const visibleItems = allItems.filter((item) => visibleEvidenceIds.has(item.id));

  const evidenceCount = visibleItems.filter((item) => inspectedIds.has(item.id)).length;
  const dialogueIndex = Math.min(evidenceCount, cyberRoboDialogues.length - 1);

  return (
    <div className="min-h-dvh bg-paper flex flex-col">
      <h1 className="sr-only">Corva delivery message investigation</h1>
      <header className="flex items-center justify-between gap-2 px-3 sm:px-6 py-3 border-b border-ink/10 bg-paper-dark">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-xs text-muted hover:text-ink transition-colors"
          style={{ fontFamily: "'Outfit', sans-serif" }}
          aria-label="Return to Identity Citadel overview"
        >
          <svg width="14" height="14" viewBox="0 0 16 16" fill="none" aria-hidden="true">
            <path
              d="M13 8H3M7 4l-4 4 4 4"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
          Identity Citadel
        </button>
        <StepIndicator step={2} accent="indigo" />
        <div className="hidden sm:block w-28" aria-hidden="true" />
      </header>

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-[minmax(0,1fr)_320px] xl:grid-cols-[minmax(0,1fr)_360px] lg:overflow-hidden">
        <div className="p-3 sm:p-5 lg:p-7 flex items-start justify-center overflow-y-auto min-w-0">
          <div className="w-full max-w-lg">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <span
                  className="text-[9px] tracking-[0.25em] uppercase text-indigo"
                  style={{ fontFamily: "'Outfit', sans-serif" }}
                >
                  Verification Gate Terminal
                </span>
                <span
                  className="flex items-center gap-1 text-[9px] text-muted border border-ink/15 px-1.5 py-0.5 rounded-sm"
                  style={{ fontFamily: "'Outfit', sans-serif" }}
                >
                  <span
                    className="w-1.5 h-1.5 rounded-full bg-indigo inline-block"
                    aria-hidden="true"
                  />
                  Live
                </span>
              </div>
              <span
                className="text-[9px] text-muted"
                style={{ fontFamily: "'Outfit', sans-serif" }}
              >
                Tap items to inspect
              </span>
            </div>

            <div className="relative">
              <div
                className="absolute -top-0.5 -left-0.5 w-6 h-6 border-t-2 border-l-2 border-indigo z-10"
                aria-hidden="true"
              />
              <div
                className="absolute -top-0.5 -right-0.5 w-6 h-6 border-t-2 border-r-2 border-indigo z-10"
                aria-hidden="true"
              />
              <div
                className="absolute -bottom-0.5 -left-0.5 w-6 h-6 border-b-2 border-l-2 border-indigo z-10"
                aria-hidden="true"
              />
              <div
                className="absolute -bottom-0.5 -right-0.5 w-6 h-6 border-b-2 border-r-2 border-indigo z-10"
                aria-hidden="true"
              />
              <div className="absolute top-3 left-8 flex gap-1.5" aria-hidden="true">
                <div className="w-6 h-px bg-indigo/40" />
                <div className="w-3 h-px bg-indigo/25" />
              </div>
              <div className="absolute top-3 right-8 flex gap-1.5" aria-hidden="true">
                <div className="w-3 h-px bg-indigo/25" />
                <div className="w-6 h-px bg-indigo/40" />
              </div>

              <div className="border border-ink/25 bg-paper-darker rounded-sm p-3">
                <div className="bg-white rounded shadow-sm overflow-hidden border border-gray-100">
                  <div className="flex items-center gap-2 px-4 py-2 bg-gray-50 border-b border-gray-100">
                    <div className="flex gap-1.5" aria-hidden="true">
                      <div className="w-3 h-3 rounded-full bg-red-300" />
                      <div className="w-3 h-3 rounded-full bg-yellow-300" />
                      <div className="w-3 h-3 rounded-full bg-green-300" />
                    </div>
                    <div
                      className="flex-1 bg-white border border-gray-200 rounded px-3 py-1 text-[10px] text-gray-400 ml-2"
                      style={{ fontFamily: "system-ui, sans-serif" }}
                    >
                      Mail
                    </div>
                  </div>

                  <div className="px-5 pt-4 pb-3 border-b border-gray-100 space-y-1.5">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <span
                          className="text-[10px] text-gray-400 mr-2"
                          style={{ fontFamily: "system-ui, sans-serif" }}
                        >
                          From
                        </span>
                        <span
                          className="text-xs text-gray-700 font-medium"
                          style={{ fontFamily: "system-ui, sans-serif" }}
                        >
                          Corva Express{" "}
                        </span>
                        <span
                          className="text-xs text-gray-500"
                          style={{ fontFamily: "system-ui, sans-serif" }}
                        >
                          &lt;noreply@corvaexpress-delivery.net&gt;
                        </span>
                      </div>
                      <div className="flex-shrink-0 self-start pt-0.5">
                        {inspectedIds.has("sender-address") ? (
                          <span
                            className="inline-flex items-center gap-1 text-[9px] font-medium text-indigo px-2 py-0.5 rounded-sm border border-indigo/30 bg-indigo-soft/20"
                            aria-label="Sender address inspected"
                          >
                            <CheckSmallIcon /> Noted
                          </span>
                        ) : (
                          <button
                            onClick={() => inspectEvidence(allItems[0].id)}
                            className="inline-flex items-center gap-1 text-[9px] font-medium text-ink/70 hover:text-indigo px-2 py-0.5 rounded-sm border border-ink/20 hover:border-indigo/40 bg-paper hover:bg-indigo-soft/15 transition-colors"
                            aria-label="Inspect sender address"
                            style={{ fontFamily: "'Outfit', sans-serif" }}
                          >
                            <MagnifyIcon /> Inspect
                          </button>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span
                        className="text-[10px] text-gray-400"
                        style={{ fontFamily: "system-ui, sans-serif" }}
                      >
                        To
                      </span>
                      <span
                        className="text-xs text-gray-600"
                        style={{ fontFamily: "system-ui, sans-serif" }}
                      >
                        me
                      </span>
                    </div>
                    <div>
                      <span
                        className="text-sm font-semibold text-gray-900"
                        style={{ fontFamily: "system-ui, sans-serif" }}
                      >
                        Delivery attempt unsuccessful — action required
                      </span>
                    </div>
                  </div>

                  <div className="px-5 py-5" style={{ backgroundColor: "#FAFAFA" }}>
                    <div className="flex items-center gap-3 mb-5 pb-4 border-b border-gray-100">
                      <CorvaLogoIcon />
                      <div>
                        <p
                          className="text-base font-bold"
                          style={{ fontFamily: "system-ui, sans-serif", color: corvaOrange }}
                        >
                          CORVA EXPRESS
                        </p>
                        <p
                          className="text-[10px] text-gray-500"
                          style={{ fontFamily: "system-ui, sans-serif" }}
                        >
                          Australia Post · Delivery Services
                        </p>
                      </div>
                    </div>

                    <h2
                      className="text-base font-semibold text-gray-900 mb-3"
                      style={{ fontFamily: "system-ui, sans-serif" }}
                    >
                      We missed you
                    </h2>
                    <p
                      className="text-sm text-gray-600 leading-5 mb-4"
                      style={{ fontFamily: "system-ui, sans-serif" }}
                    >
                      A delivery attempt was made today but could not be completed.
                    </p>

                    {isContextualised && (
                      <div className="bg-orange-50 border border-orange-100 rounded-lg px-4 py-3 mb-4 relative">
                        <div className="flex items-start justify-between gap-3">
                          <div className="space-y-0.5">
                            <p
                              className="text-xs font-semibold text-gray-800"
                              style={{ fontFamily: "system-ui, sans-serif" }}
                            >
                              Order NB-40318
                            </p>
                            <p
                              className="text-xs text-gray-600"
                              style={{ fontFamily: "system-ui, sans-serif" }}
                            >
                              Delivery address: Grantham Street, Clayton
                            </p>
                            <p
                              className="text-xs text-gray-500"
                              style={{ fontFamily: "system-ui, sans-serif" }}
                            >
                              Recipient note: gift for Priya R.
                            </p>
                          </div>
                          <div className="flex-shrink-0">
                            {inspectedIds.has("personal-context") ? (
                              <span
                                className="inline-flex items-center gap-1 text-[9px] font-medium text-indigo px-2 py-0.5 rounded-sm border border-indigo/30 bg-indigo-soft/20"
                                aria-label="Personal details inspected"
                              >
                                <CheckSmallIcon /> Noted
                              </span>
                            ) : (
                              <button
                                onClick={() => inspectEvidence(allItems[5].id)}
                                className="inline-flex items-center gap-1 text-[9px] font-medium text-ink/70 hover:text-indigo px-2 py-0.5 rounded-sm border border-ink/20 hover:border-indigo/40 bg-paper hover:bg-indigo-soft/15 transition-colors"
                                aria-label="Inspect personal details in this message"
                                style={{ fontFamily: "'Outfit', sans-serif" }}
                              >
                                <MagnifyIcon /> Inspect
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    )}

                    {!isContextualised && (
                      <div className="bg-gray-100 border border-gray-200 rounded-lg px-4 py-3 mb-4">
                        <p
                          className="text-xs text-gray-500 italic"
                          style={{ fontFamily: "system-ui, sans-serif" }}
                        >
                          Parcel details unavailable — confirm address to retrieve
                        </p>
                      </div>
                    )}

                    <div className="space-y-2 mb-5">
                      <div className="flex items-center justify-between bg-white border border-gray-200 rounded-lg px-4 py-2.5">
                        <div>
                          <p
                            className="text-xs font-medium text-gray-800"
                            style={{ fontFamily: "system-ui, sans-serif" }}
                          >
                            Redelivery fee
                          </p>
                          <p
                            className="text-base font-bold text-gray-900"
                            style={{ fontFamily: "system-ui, sans-serif" }}
                          >
                            $3.95
                          </p>
                        </div>
                        {inspectedIds.has("redelivery-fee") ? (
                          <span
                            className={`inline-flex items-center gap-1 text-[9px] font-medium text-indigo px-2 py-0.5 rounded-sm border border-indigo/30 bg-indigo-soft/20 transition-all ${recentlyAdded === "redelivery-fee" ? "scale-110" : ""}`}
                            aria-label="Fee inspected"
                          >
                            <CheckSmallIcon /> Noted
                          </span>
                        ) : (
                          <button
                            onClick={() => inspectEvidence(allItems[2].id)}
                            className="inline-flex items-center gap-1 text-[9px] font-medium text-ink/70 hover:text-indigo px-2 py-0.5 rounded-sm border border-ink/20 hover:border-indigo/40 bg-paper hover:bg-indigo-soft/15 transition-colors"
                            aria-label="Inspect the redelivery fee"
                            style={{ fontFamily: "'Outfit', sans-serif" }}
                          >
                            <MagnifyIcon /> Inspect
                          </button>
                        )}
                      </div>
                      <div className="flex items-center justify-between bg-white border border-gray-200 rounded-lg px-4 py-2.5">
                        <div>
                          <p
                            className="text-xs font-medium text-gray-800"
                            style={{ fontFamily: "system-ui, sans-serif" }}
                          >
                            Claim window
                          </p>
                          <p
                            className="text-xs text-red-600 font-semibold"
                            style={{ fontFamily: "system-ui, sans-serif" }}
                          >
                            48 hours before parcel is returned
                          </p>
                        </div>
                        {inspectedIds.has("time-pressure") ? (
                          <span
                            className={`inline-flex items-center gap-1 text-[9px] font-medium text-indigo px-2 py-0.5 rounded-sm border border-indigo/30 bg-indigo-soft/20 transition-all ${recentlyAdded === "time-pressure" ? "scale-110" : ""}`}
                            aria-label="Deadline inspected"
                          >
                            <CheckSmallIcon /> Noted
                          </span>
                        ) : (
                          <button
                            onClick={() => inspectEvidence(allItems[3].id)}
                            className="inline-flex items-center gap-1 text-[9px] font-medium text-ink/70 hover:text-indigo px-2 py-0.5 rounded-sm border border-ink/20 hover:border-indigo/40 bg-paper hover:bg-indigo-soft/15 transition-colors"
                            aria-label="Inspect the 48-hour deadline"
                            style={{ fontFamily: "'Outfit', sans-serif" }}
                          >
                            <MagnifyIcon /> Inspect
                          </button>
                        )}
                      </div>
                      <div className="flex items-center justify-between bg-white border border-gray-200 rounded-lg px-4 py-2.5">
                        <p
                          className="text-xs text-gray-500 italic"
                          style={{ fontFamily: "system-ui, sans-serif" }}
                        >
                          No tracking number provided
                        </p>
                        {inspectedIds.has("unexpected-parcel") ? (
                          <span
                            className={`inline-flex items-center gap-1 text-[9px] font-medium text-indigo px-2 py-0.5 rounded-sm border border-indigo/30 bg-indigo-soft/20 transition-all ${recentlyAdded === "unexpected-parcel" ? "scale-110" : ""}`}
                            aria-label="Unexpected parcel noted"
                          >
                            <CheckSmallIcon /> Noted
                          </span>
                        ) : (
                          <button
                            onClick={() => inspectEvidence(allItems[4].id)}
                            className="inline-flex items-center gap-1 text-[9px] font-medium text-ink/70 hover:text-indigo px-2 py-0.5 rounded-sm border border-ink/20 hover:border-indigo/40 bg-paper hover:bg-indigo-soft/15 transition-colors"
                            aria-label="Inspect the missing tracking number"
                            style={{ fontFamily: "'Outfit', sans-serif" }}
                          >
                            <MagnifyIcon /> Inspect
                          </button>
                        )}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <button
                        disabled
                        className="w-full py-3 rounded-lg text-white text-sm font-semibold"
                        style={{
                          backgroundColor: corvaOrange,
                          fontFamily: "system-ui, sans-serif",
                        }}
                        aria-label="Confirm address and pay fee — for context only"
                        tabIndex={-1}
                      >
                        Confirm Address &amp; Pay $3.95
                      </button>
                      <div className="flex items-center justify-between gap-2 bg-gray-50 rounded px-3 py-1.5 min-w-0">
                        <span
                          className="text-[10px] text-blue-600 underline break-all min-w-0"
                          style={{ fontFamily: "system-ui, sans-serif" }}
                        >
                          corvaexpress-delivery.net/confirm/4821
                        </span>
                        {inspectedIds.has("link-destination") ? (
                          <span
                            className={`inline-flex items-center gap-1 text-[9px] font-medium text-indigo px-2 py-0.5 rounded-sm border border-indigo/30 bg-indigo-soft/20 transition-all ${recentlyAdded === "link-destination" ? "scale-110" : ""}`}
                            aria-label="Link destination inspected"
                          >
                            <CheckSmallIcon /> Noted
                          </span>
                        ) : (
                          <button
                            onClick={() => inspectEvidence(allItems[1].id)}
                            className="inline-flex items-center gap-1 text-[9px] font-medium text-ink/70 hover:text-indigo px-2 py-0.5 rounded-sm border border-ink/20 hover:border-indigo/40 bg-paper hover:bg-indigo-soft/15 transition-colors flex-shrink-0"
                            aria-label="Inspect the link destination"
                            style={{ fontFamily: "'Outfit', sans-serif" }}
                          >
                            <MagnifyIcon /> Inspect
                          </button>
                        )}
                      </div>
                      <p
                        className="text-[10px] text-gray-400 text-center"
                        style={{ fontFamily: "system-ui, sans-serif" }}
                      >
                        © 2025 Corva Express Pty Ltd · Unsubscribe
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <aside
          className="border-t lg:border-t-0 lg:border-l border-ink/10 bg-paper-dark flex flex-col"
          aria-label="Evidence panel and field companion"
        >
          <div className="flex-1 overflow-y-auto p-5">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p
                  className="text-[9px] tracking-[0.25em] uppercase text-muted"
                  style={{ fontFamily: "'Outfit', sans-serif" }}
                >
                  Evidence Collected
                </p>
                <p
                  className="text-xl font-medium text-ink mt-0.5"
                  style={{ fontFamily: "'Caveat', cursive", fontWeight: 700 }}
                >
                  {evidenceCount}{" "}
                  <span className="text-muted text-base font-normal">of {visibleItems.length}</span>
                </p>
              </div>
              <div
                className="w-20 bg-paper-darker rounded-full h-1.5 overflow-hidden"
                aria-hidden="true"
              >
                <div
                  className="bg-indigo h-full rounded-full transition-all duration-500"
                  style={{ width: `${(evidenceCount / visibleItems.length) * 100}%` }}
                />
              </div>
            </div>

            <ul
              className="space-y-2.5"
              aria-label="Collected evidence"
              aria-live="polite"
              aria-atomic="false"
            >
              {evidenceCount === 0 && (
                <li
                  className="text-xs text-muted/60 italic text-center py-6 border border-dashed border-ink/10 rounded-sm"
                  style={{ fontFamily: "'Outfit', sans-serif" }}
                >
                  Inspect items in the message to collect evidence
                </li>
              )}
              {visibleItems
                .filter((item) => inspectedIds.has(item.id))
                .map((item) => (
                  <li
                    key={item.id}
                    className={`flex items-start gap-2.5 bg-paper border border-ink/10 rounded-sm px-3 py-2.5 text-xs transition-all ${
                      recentlyAdded === item.id ? "border-indigo/40 bg-indigo-soft/10" : ""
                    }`}
                  >
                    <span
                      className="mt-0.5 w-1.5 h-1.5 rounded-full bg-indigo flex-shrink-0"
                      aria-hidden="true"
                    />
                    <div>
                      <span
                        className="text-[9px] tracking-wide uppercase text-muted block mb-0.5"
                        style={{ fontFamily: "'Outfit', sans-serif" }}
                      >
                        {item.label}
                      </span>
                      <span
                        className="text-xs text-ink/80 leading-4"
                        style={{ fontFamily: "'Outfit', sans-serif" }}
                      >
                        {item.evidence}
                      </span>
                    </div>
                  </li>
                ))}
            </ul>
          </div>

          <div className="border-t border-ink/10 p-5 space-y-4">
            <div className="flex items-start gap-3">
              <CyberRoboSVG size={56} className="flex-shrink-0" />
              <div>
                <p
                  className="text-[9px] tracking-[0.2em] uppercase text-muted mb-1.5"
                  style={{ fontFamily: "'Outfit', sans-serif" }}
                >
                  CyberRobo
                </p>
                <div
                  className="bg-paper border border-ink/15 rounded-sm px-3 py-2"
                  role="status"
                  aria-live="polite"
                >
                  <p
                    className="text-xs text-ink/80 leading-5 italic"
                    style={{ fontFamily: "'Outfit', sans-serif" }}
                  >
                    "{cyberRoboDialogues[dialogueIndex]}"
                  </p>
                </div>
              </div>
            </div>

            <Button
              onClick={onDecide}
              variant="primary"
              className="w-full justify-center"
              aria-label="Proceed to make your decision"
            >
              Make Decision
              <svg width="14" height="14" viewBox="0 0 16 16" fill="none" aria-hidden="true">
                <path
                  d="M3 8h10M9 4l4 4-4 4"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </Button>
            {evidenceCount === 0 && (
              <p
                className="text-[10px] text-muted/70 text-center"
                style={{ fontFamily: "'Outfit', sans-serif" }}
              >
                Inspect at least one item first — or proceed if you're ready
              </p>
            )}
          </div>
        </aside>
      </div>
    </div>
  );
}
