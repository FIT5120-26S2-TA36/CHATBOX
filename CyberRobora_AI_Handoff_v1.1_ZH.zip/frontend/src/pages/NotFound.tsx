/**
 * @file NotFound routed experience, responsible for composing its content, state callbacks, and accessible UI.
 */
import Button from "../components/Button";
import CyberRoboSVG from "../components/CyberRoboSVG";

interface Props {
  onReturnToCyberia: () => void;
  onReturnHome: () => void;
}

/** Renders the NotFound experience/component and coordinates its user-facing callbacks. */
export default function NotFound({ onReturnToCyberia, onReturnHome }: Props) {
  return (
    <div className="flex min-h-dvh items-center justify-center bg-paper px-5 text-ink">
      <section className="w-full max-w-xl border-y border-ink/15 py-10 text-center">
        <CyberRoboSVG size={68} className="mx-auto" />
        <p className="mt-5 text-[10px] font-semibold uppercase tracking-[0.24em] text-muted">
          Route not found
        </p>
        <h1
          className="mt-2 font-display text-5xl font-bold text-ink sm:text-6xl"
          style={{ fontFamily: "'Caveat', cursive" }}
        >
          Page not found
        </h1>
        <p className="mx-auto mt-4 max-w-md text-sm leading-6 text-muted">
          This path does not appear on the current Cyberia field map.
        </p>
        <div className="mt-7 flex flex-col justify-center gap-3 sm:flex-row">
          <Button onClick={onReturnToCyberia}>Return to Cyberia</Button>
          <Button variant="outline" onClick={onReturnHome}>
            Return home
          </Button>
        </div>
      </section>
    </div>
  );
}
