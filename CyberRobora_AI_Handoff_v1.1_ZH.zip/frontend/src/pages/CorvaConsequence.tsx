/**
 * @file CorvaConsequence routed experience, responsible for composing its content, state callbacks, and accessible UI.
 */
import ConsequenceSections from "../components/gameplay/ConsequenceSections";
import PageHeader from "../components/gameplay/PageHeader";
import type { CommittedJourneyResult } from "../api/cyberroboraApi";

interface Props {
  result: CommittedJourneyResult;
  onContinue: () => void;
}
/** Renders the CorvaConsequence experience/component and coordinates its user-facing callbacks. */
export default function CorvaConsequence({ result, onContinue }: Props) {
  const content = result.content;
  const revelation = result.revelation;
  if (!revelation) return null;
  const isContextualised = revelation.contextualised;
  return (
    <div className="min-h-dvh bg-paper flex flex-col">
      <PageHeader center="Identity Citadel · Revelation" />
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-2xl mx-auto px-6 lg:px-8 py-10 space-y-10">
          <div>
            <p
              className="text-[10px] tracking-[0.3em] uppercase text-muted mb-2"
              style={{ fontFamily: "'Outfit', sans-serif" }}
            >
              Identity Citadel — Verification Gate
            </p>
            <h1
              className="text-ink mb-1"
              style={{
                fontFamily: "'Caveat', cursive",
                fontWeight: 700,
                fontSize: "clamp(2rem, 5vw, 2.8rem)",
                lineHeight: 1.1,
              }}
            >
              {content.outcomeLabel}
            </h1>
            <p className="text-sm text-muted" style={{ fontFamily: "'Outfit', sans-serif" }}>
              Decision: {result.selectedAction.label}
            </p>
          </div>
          <section
            aria-labelledby="revelation-heading"
            className="border border-ink/15 rounded-sm overflow-hidden"
          >
            <div className="bg-paper-darker px-5 py-4 border-b border-ink/10">
              <p
                className="text-[9px] tracking-[0.25em] uppercase text-muted mb-1"
                style={{ fontFamily: "'Outfit', sans-serif" }}
              >
                The connection
              </p>
              <h2
                id="revelation-heading"
                className="text-ink"
                style={{
                  fontFamily: "'Caveat', cursive",
                  fontWeight: 700,
                  fontSize: "clamp(1.6rem, 4vw, 2.2rem)",
                  lineHeight: 1.15,
                }}
              >
                {revelation.heading}
              </h2>
            </div>
            <div className="px-5 py-5 space-y-3">
              <p
                className="text-sm text-ink/80 leading-7"
                style={{ fontFamily: "'Outfit', sans-serif" }}
              >
                {revelation.paragraphs[0]}
              </p>
              <p
                className="text-sm text-ink/80 leading-7"
                style={{ fontFamily: "'Outfit', sans-serif" }}
              >
                {revelation.paragraphs[1]}{" "}
                {isContextualised ? (
                  <>
                    In the Data District investigation, Nimbo was granted{" "}
                    <span className="font-medium text-ink">
                      {revelation.priorDecisionLabel
                        ? `"${revelation.priorDecisionLabel}"`
                        : "broad"}
                    </span>{" "}
                    — which included access to contacts, location, and terms permitting data sharing
                    with advertising and analytics partners.
                  </>
                ) : null}
              </p>
              {isContextualised ? (
                <p
                  className="text-sm text-ink/80 leading-7"
                  style={{ fontFamily: "'Outfit', sans-serif" }}
                >
                  {revelation.paragraphs[2]}
                </p>
              ) : (
                <p
                  className="text-sm text-ink/80 leading-7"
                  style={{ fontFamily: "'Outfit', sans-serif" }}
                >
                  In the Data District investigation, the decision was{" "}
                  <span className="font-medium text-ink">
                    {revelation.priorDecisionLabel
                      ? `"${revelation.priorDecisionLabel}"`
                      : "to limit access"}
                  </span>
                  . {revelation.limitedExposure}
                </p>
              )}
              <div className="mt-4 pt-4 border-t border-ink/10">
                <div className="flex items-center gap-3">
                  <div
                    className={`flex-1 border-t border-dashed ${isContextualised ? "border-ochre/50" : "border-ink/20"}`}
                    aria-hidden="true"
                  />
                  <div
                    className={`flex items-center gap-2 px-3 py-1.5 rounded-sm ${isContextualised ? "bg-ochre-soft border border-ochre/30" : "bg-paper-darker border border-ink/15"}`}
                  >
                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" aria-hidden="true">
                      <circle
                        cx="2"
                        cy="6"
                        r="1.5"
                        fill={isContextualised ? "#B8892B" : "#7A6B5D"}
                      />
                      <line
                        x1="3.5"
                        y1="6"
                        x2="8.5"
                        y2="6"
                        stroke={isContextualised ? "#B8892B" : "#7A6B5D"}
                        strokeWidth="0.9"
                        strokeDasharray="1.5,1.5"
                      />
                      <circle
                        cx="10"
                        cy="6"
                        r="1.5"
                        fill={isContextualised ? "#B8892B" : "#7A6B5D"}
                      />
                    </svg>
                    <span
                      className={`text-[9px] font-medium tracking-wide ${isContextualised ? "text-ochre" : "text-muted"}`}
                      style={{ fontFamily: "'Outfit', sans-serif" }}
                    >
                      Data District → Identity Citadel
                    </span>
                  </div>
                  <div
                    className={`flex-1 border-t border-dashed ${isContextualised ? "border-ochre/50" : "border-ink/20"}`}
                    aria-hidden="true"
                  />
                </div>
                <p
                  className="text-[10px] text-muted text-center mt-2"
                  style={{ fontFamily: "'Outfit', sans-serif" }}
                >
                  {revelation.connector}
                </p>
              </div>
            </div>
          </section>
          <div className="border-t border-ink/10" />
          <ConsequenceSections
            content={content}
            accent="indigo"
            reflection={revelation.reflection}
          />
          <div className="flex items-center gap-4 pb-4">
            <button
              onClick={onContinue}
              className="inline-flex items-center gap-2.5 bg-ink text-paper px-7 py-3.5 text-sm font-medium rounded-sm hover:bg-indigo transition-colors"
              style={{ fontFamily: "'Outfit', sans-serif" }}
              aria-label="Continue to the Cyberia map"
            >
              Continue to Cyberia
              <svg width="14" height="14" viewBox="0 0 16 16" fill="none" aria-hidden="true">
                <path
                  d="M3 8h10M9 4l4 4-4 4"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
