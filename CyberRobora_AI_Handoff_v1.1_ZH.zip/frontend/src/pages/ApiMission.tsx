/**
 * @file ApiMission routed experience, responsible for composing its content, state callbacks, and accessible UI.
 */
import { useCallback, useEffect, useState } from "react";
import {
  getNextScenario,
  submitScenarioChoice,
  type ChoiceOutcome,
  type MissionScenario,
  type SessionProgress,
} from "../api/cyberroboraApi";
import Button from "../components/Button";
import PageHeader from "../components/gameplay/PageHeader";

interface Props {
  onBack: () => void;
  onComplete: (progress: SessionProgress) => void;
}

/** Renders the ApiMission experience/component and coordinates its user-facing callbacks. */
export default function ApiMission({ onBack, onComplete }: Props) {
  const [mission, setMission] = useState<MissionScenario | null>(null);
  const [outcome, setOutcome] = useState<ChoiceOutcome | null>(null);
  const [loading, setLoading] = useState(true);
  const [submittingId, setSubmittingId] = useState<string | null>(null);
  const [error, setError] = useState(false);

  const loadMission = useCallback(async () => {
    setLoading(true);
    setError(false);
    setOutcome(null);
    try {
      setMission(await getNextScenario("data_district"));
    } catch {
      setMission(null);
      setError(true);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadMission();
  }, [loadMission]);

  async function choose(actionId: string) {
    if (!mission || submittingId) return;
    setSubmittingId(actionId);
    setError(false);
    try {
      setOutcome(await submitScenarioChoice(mission.scenario.id, actionId));
    } catch {
      setError(true);
    } finally {
      setSubmittingId(null);
    }
  }

  return (
    <div className="min-h-dvh bg-paper flex flex-col">
      <PageHeader
        center="Data District · Live Mission"
        onBack={onBack}
        backLabel="Region"
        backAriaLabel="Return to Data District"
      />
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-3xl mx-auto px-5 sm:px-8 py-8 sm:py-10">
          {loading && (
            <div
              role="status"
              className="border border-ink/10 bg-paper-dark rounded-sm p-8 text-center text-muted"
            >
              Loading mission data…
            </div>
          )}

          {!loading && !mission && error && (
            <section
              role="alert"
              className="border border-coral/30 bg-paper-dark rounded-sm p-7 text-center space-y-4"
            >
              <h1
                className="text-2xl text-ink"
                style={{ fontFamily: "'Caveat', cursive", fontWeight: 700 }}
              >
                Mission data is temporarily unavailable.
              </h1>
              <p className="text-sm text-muted">Please try again.</p>
              <Button onClick={() => void loadMission()}>Retry mission</Button>
            </section>
          )}

          {mission && !outcome && (
            <article className="space-y-7">
              <header>
                <p className="text-[10px] tracking-[0.3em] uppercase text-teal mb-2">
                  OAIC-informed field mission
                </p>
                <h1
                  className="text-ink"
                  style={{
                    fontFamily: "'Caveat', cursive",
                    fontWeight: 700,
                    fontSize: "clamp(2rem, 6vw, 3rem)",
                  }}
                >
                  {mission.scenario.title}
                </h1>
              </header>
              <section
                className="border border-ink/15 bg-white rounded-sm p-5 space-y-3"
                aria-label="Scenario message"
              >
                <div className="border-b border-ink/10 pb-3 text-sm">
                  <strong>{mission.scenario.senderDisplay}</strong>
                  <span className="block text-xs text-muted break-all">
                    {mission.scenario.senderAddress}
                  </span>
                </div>
                <p className="text-sm sm:text-base leading-7 text-ink/80">
                  {mission.scenario.text}
                </p>
                {mission.scenario.linkDisplay && (
                  <p className="text-sm text-teal break-all">
                    {mission.scenario.linkDisplay} — {mission.scenario.linkTarget}
                  </p>
                )}
              </section>
              <section aria-labelledby="mission-clues">
                <h2
                  id="mission-clues"
                  className="text-xl mb-3"
                  style={{ fontFamily: "'Caveat', cursive", fontWeight: 700 }}
                >
                  Evidence clues
                </h2>
                <div className="grid sm:grid-cols-2 gap-3">
                  {mission.clues.map((clue) => (
                    <div
                      key={clue.id}
                      className="border border-ink/10 bg-paper-dark rounded-sm p-4"
                    >
                      <p className="text-[9px] tracking-[0.2em] uppercase text-teal mb-1">
                        {clue.type}
                      </p>
                      <h3 className="text-sm font-semibold mb-1">{clue.label}</h3>
                      <p className="text-sm text-muted leading-5">{clue.text}</p>
                    </div>
                  ))}
                </div>
              </section>
              <section aria-labelledby="mission-actions">
                <h2
                  id="mission-actions"
                  className="text-xl mb-3"
                  style={{ fontFamily: "'Caveat', cursive", fontWeight: 700 }}
                >
                  Choose your action
                </h2>
                <div className="grid gap-3">
                  {mission.actions.map((action) => (
                    <button
                      key={action.id}
                      disabled={submittingId !== null}
                      onClick={() => void choose(action.id)}
                      className="w-full text-left border border-ink/20 bg-white hover:border-teal hover:bg-teal-soft/20 rounded-sm px-5 py-4 text-sm transition-colors disabled:opacity-50"
                    >
                      {submittingId === action.id ? "Submitting choice…" : action.label}
                    </button>
                  ))}
                </div>
              </section>
              {error && (
                <p role="alert" className="text-sm text-coral border border-coral/25 p-3">
                  Your choice could not be submitted. Please try again.
                </p>
              )}
            </article>
          )}

          {mission && outcome && (
            <article className="space-y-7">
              <header>
                <p className="text-[10px] tracking-[0.3em] uppercase text-teal mb-2">
                  Mission result
                </p>
                <h1
                  className="text-ink"
                  style={{
                    fontFamily: "'Caveat', cursive",
                    fontWeight: 700,
                    fontSize: "clamp(2rem, 6vw, 3rem)",
                  }}
                >
                  {outcome.safe ? "Safer choice" : "Risk identified"}
                </h1>
              </header>
              <section className="border border-ink/10 bg-paper-dark rounded-sm p-5">
                <h2 className="font-semibold mb-2">Outcome</h2>
                <p className="text-sm leading-6 text-ink/80">{outcome.outcome}</p>
              </section>
              <section className="border border-ink/10 rounded-sm p-5">
                <h2 className="font-semibold mb-2">Why the evidence matters</h2>
                <p className="text-sm leading-6 text-ink/80">{outcome.explanation}</p>
              </section>
              <section className="border-l-4 border-teal bg-teal-soft/20 p-5">
                <h2 className="font-semibold mb-2">Real-world tip</h2>
                <p className="text-sm leading-6 text-ink/80">{outcome.realWorldTip}</p>
              </section>
              <div className="flex flex-wrap gap-3">
                <Button onClick={() => onComplete(outcome.progress)}>Continue to Cyberia</Button>
                <Button variant="outline" onClick={() => void loadMission()}>
                  Try another mission
                </Button>
              </div>
            </article>
          )}
        </div>
      </div>
    </div>
  );
}
