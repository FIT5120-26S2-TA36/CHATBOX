/**
 * @file RegionOverview routed experience, responsible for composing its content, state callbacks, and accessible UI.
 */
import CyberRoboSVG from "../components/CyberRoboSVG";
import Button from "../components/Button";
import RegionStatCard from "../components/gameplay/RegionStatCard";
import StepIndicator from "../components/gameplay/StepIndicator";
import { dataDistrictScenario } from "../content/dataDistrict";

interface Props {
  onOpenChat?: () => void;
  onBack: () => void;
  onStart: () => void;
}

function CircuitArchivesSVG() {
  return (
    <svg
      viewBox="0 0 480 380"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-label="Illustrated scene of the Circuit Archives, central landmark of Data District"
      role="img"
      className="w-full h-auto"
    >
      {/* Sky */}
      <rect width="480" height="380" fill="#EBF4F4" fillOpacity="0.7" />
      {/* Sky wash variation */}
      <ellipse cx="240" cy="80" rx="280" ry="120" fill="#D8ECEC" fillOpacity="0.35" />

      {/* Distant background suggestion */}
      <rect x="0" y="240" width="480" height="4" fill="#3B7A7B" fillOpacity="0.05" />

      {/* Far background buildings (very light) */}
      <rect x="10" y="200" width="30" height="90" fill="#CDD3EC" fillOpacity="0.3" />
      <rect x="44" y="215" width="22" height="75" fill="#C8DFDF" fillOpacity="0.3" />
      <rect x="420" y="210" width="36" height="80" fill="#CDD3EC" fillOpacity="0.25" />
      <rect x="446" y="225" width="24" height="65" fill="#C8DFDF" fillOpacity="0.25" />

      {/* Left relay tower */}
      <rect
        x="52"
        y="162"
        width="56"
        height="118"
        fill="#CDD3EC"
        stroke="#2B2420"
        strokeWidth="1.3"
      />
      <rect
        x="60"
        y="150"
        width="40"
        height="16"
        fill="#CDD3EC"
        stroke="#2B2420"
        strokeWidth="1.2"
      />
      <line
        x1="72"
        y1="150"
        x2="68"
        y2="136"
        stroke="#2B2420"
        strokeWidth="1.1"
        strokeLinecap="round"
      />
      <line
        x1="80"
        y1="150"
        x2="80"
        y2="134"
        stroke="#2B2420"
        strokeWidth="1.1"
        strokeLinecap="round"
      />
      <circle cx="80" cy="132" r="2.5" fill="#C15738" stroke="#2B2420" strokeWidth="0.9" />
      {/* Windows left */}
      <rect
        x="62"
        y="172"
        width="12"
        height="10"
        fill="#4A5A8B"
        fillOpacity="0.3"
        stroke="#2B2420"
        strokeWidth="0.7"
      />
      <rect
        x="80"
        y="172"
        width="12"
        height="10"
        fill="#4A5A8B"
        fillOpacity="0.4"
        stroke="#2B2420"
        strokeWidth="0.7"
      />
      <rect
        x="62"
        y="192"
        width="12"
        height="10"
        fill="#4A5A8B"
        fillOpacity="0.2"
        stroke="#2B2420"
        strokeWidth="0.7"
      />
      <rect
        x="80"
        y="192"
        width="12"
        height="10"
        fill="#4A5A8B"
        fillOpacity="0.35"
        stroke="#2B2420"
        strokeWidth="0.7"
      />
      {/* Circuit trace from left relay */}
      <path
        d="M108,230 L150,230 L150,250 L192,250"
        fill="none"
        stroke="#3B7A7B"
        strokeWidth="1"
        strokeDasharray="3,3"
      />
      <circle cx="108" cy="230" r="2.5" fill="#3B7A7B" />
      <circle cx="150" cy="230" r="2" fill="#3B7A7B" />

      {/* Left low building */}
      <rect
        x="118"
        y="230"
        width="66"
        height="50"
        fill="#C8DFDF"
        fillOpacity="0.7"
        stroke="#2B2420"
        strokeWidth="1.2"
      />
      <rect
        x="128"
        y="240"
        width="14"
        height="16"
        fill="#3B7A7B"
        fillOpacity="0.25"
        stroke="#2B2420"
        strokeWidth="0.8"
      />
      <rect
        x="148"
        y="240"
        width="14"
        height="16"
        fill="#3B7A7B"
        fillOpacity="0.35"
        stroke="#2B2420"
        strokeWidth="0.8"
      />
      <rect
        x="168"
        y="240"
        width="10"
        height="16"
        fill="#3B7A7B"
        fillOpacity="0.2"
        stroke="#2B2420"
        strokeWidth="0.8"
      />

      {/* Main building — Circuit Archives */}
      {/* Foundation / base level */}
      <rect
        x="188"
        y="220"
        width="104"
        height="60"
        fill="#C8DFDF"
        stroke="#2B2420"
        strokeWidth="1.6"
      />
      {/* Main shaft */}
      <rect
        x="196"
        y="110"
        width="88"
        height="114"
        fill="#C8DFDF"
        stroke="#2B2420"
        strokeWidth="1.6"
      />
      {/* Upper section */}
      <rect
        x="204"
        y="62"
        width="72"
        height="52"
        fill="#C8DFDF"
        stroke="#2B2420"
        strokeWidth="1.5"
      />
      {/* Antenna platform */}
      <rect
        x="194"
        y="50"
        width="92"
        height="16"
        fill="#B8D8D9"
        stroke="#2B2420"
        strokeWidth="1.4"
      />

      {/* Antennae */}
      <line
        x1="214"
        y1="50"
        x2="208"
        y2="30"
        stroke="#2B2420"
        strokeWidth="1.2"
        strokeLinecap="round"
      />
      <line
        x1="240"
        y1="50"
        x2="240"
        y2="26"
        stroke="#2B2420"
        strokeWidth="1.3"
        strokeLinecap="round"
      />
      <line
        x1="266"
        y1="50"
        x2="272"
        y2="30"
        stroke="#2B2420"
        strokeWidth="1.2"
        strokeLinecap="round"
      />
      <circle cx="240" cy="24" r="4" fill="#C15738" stroke="#2B2420" strokeWidth="1" />

      {/* Signal arcs from main antenna */}
      <path
        d="M240,24 Q220,8 196,14"
        fill="none"
        stroke="#2B2420"
        strokeWidth="0.9"
        strokeDasharray="2,3"
        strokeOpacity="0.5"
      />
      <path
        d="M240,24 Q260,8 284,14"
        fill="none"
        stroke="#2B2420"
        strokeWidth="0.9"
        strokeDasharray="2,3"
        strokeOpacity="0.5"
      />
      <path
        d="M240,24 Q214,-4 186,4"
        fill="none"
        stroke="#3B7A7B"
        strokeWidth="0.8"
        strokeDasharray="2,4"
        strokeOpacity="0.4"
      />
      <path
        d="M240,24 Q266,-4 294,4"
        fill="none"
        stroke="#3B7A7B"
        strokeWidth="0.8"
        strokeDasharray="2,4"
        strokeOpacity="0.4"
      />

      {/* Building windows — upper section */}
      <rect
        x="212"
        y="70"
        width="16"
        height="12"
        fill="#3B7A7B"
        fillOpacity="0.35"
        stroke="#2B2420"
        strokeWidth="0.8"
      />
      <rect
        x="236"
        y="70"
        width="16"
        height="12"
        fill="#3B7A7B"
        fillOpacity="0.5"
        stroke="#2B2420"
        strokeWidth="0.8"
      />
      <rect
        x="260"
        y="70"
        width="16"
        height="12"
        fill="#3B7A7B"
        fillOpacity="0.3"
        stroke="#2B2420"
        strokeWidth="0.8"
      />
      <rect
        x="212"
        y="90"
        width="16"
        height="12"
        fill="#3B7A7B"
        fillOpacity="0.2"
        stroke="#2B2420"
        strokeWidth="0.8"
      />
      <rect
        x="236"
        y="90"
        width="16"
        height="12"
        fill="#3B7A7B"
        fillOpacity="0.45"
        stroke="#2B2420"
        strokeWidth="0.8"
      />
      <rect
        x="260"
        y="90"
        width="16"
        height="12"
        fill="#3B7A7B"
        fillOpacity="0.35"
        stroke="#2B2420"
        strokeWidth="0.8"
      />

      {/* Building windows — main shaft */}
      <rect
        x="204"
        y="122"
        width="16"
        height="12"
        fill="#3B7A7B"
        fillOpacity="0.3"
        stroke="#2B2420"
        strokeWidth="0.8"
      />
      <rect
        x="228"
        y="122"
        width="20"
        height="12"
        fill="#3B7A7B"
        fillOpacity="0.5"
        stroke="#2B2420"
        strokeWidth="0.8"
      />
      <rect
        x="256"
        y="122"
        width="16"
        height="12"
        fill="#3B7A7B"
        fillOpacity="0.25"
        stroke="#2B2420"
        strokeWidth="0.8"
      />
      <rect
        x="204"
        y="146"
        width="16"
        height="12"
        fill="#3B7A7B"
        fillOpacity="0.45"
        stroke="#2B2420"
        strokeWidth="0.8"
      />
      <rect
        x="228"
        y="146"
        width="20"
        height="12"
        fill="#3B7A7B"
        fillOpacity="0.2"
        stroke="#2B2420"
        strokeWidth="0.8"
      />
      <rect
        x="256"
        y="146"
        width="16"
        height="12"
        fill="#3B7A7B"
        fillOpacity="0.4"
        stroke="#2B2420"
        strokeWidth="0.8"
      />
      <rect
        x="204"
        y="170"
        width="16"
        height="12"
        fill="#3B7A7B"
        fillOpacity="0.3"
        stroke="#2B2420"
        strokeWidth="0.8"
      />
      <rect
        x="228"
        y="170"
        width="20"
        height="12"
        fill="#3B7A7B"
        fillOpacity="0.35"
        stroke="#2B2420"
        strokeWidth="0.8"
      />
      <rect
        x="256"
        y="170"
        width="16"
        height="12"
        fill="#3B7A7B"
        fillOpacity="0.5"
        stroke="#2B2420"
        strokeWidth="0.8"
      />

      {/* Circuit detail on main shaft */}
      <path
        d="M188,180 L172,180 L172,196 L188,196"
        fill="none"
        stroke="#3B7A7B"
        strokeWidth="0.9"
      />
      <circle cx="172" cy="188" r="2" fill="#3B7A7B" />
      <path
        d="M292,165 L308,165 L308,182 L292,182"
        fill="none"
        stroke="#3B7A7B"
        strokeWidth="0.9"
      />
      <circle cx="308" cy="173" r="2" fill="#3B7A7B" />

      {/* Entrance arch on base */}
      <path
        d="M224,280 L224,244 Q240,232 256,244 L256,280"
        fill="#B8D8D9"
        stroke="#2B2420"
        strokeWidth="1.2"
      />

      {/* Entrance sign */}
      <rect
        x="202"
        y="234"
        width="76"
        height="16"
        rx="1"
        fill="#2B2420"
        fillOpacity="0.08"
        stroke="#2B2420"
        strokeWidth="0.8"
        strokeOpacity="0.5"
      />
      <text
        x="240"
        y="246"
        textAnchor="middle"
        fontFamily="'Caveat', cursive"
        fontSize="9"
        fill="#2B2420"
        fillOpacity="0.6"
      >
        Circuit Archives
      </text>

      {/* Right relay building */}
      <rect
        x="322"
        y="188"
        width="62"
        height="92"
        fill="#CDD3EC"
        stroke="#2B2420"
        strokeWidth="1.3"
      />
      <rect
        x="330"
        y="178"
        width="46"
        height="14"
        fill="#CDD3EC"
        stroke="#2B2420"
        strokeWidth="1.2"
      />
      <line
        x1="353"
        y1="178"
        x2="353"
        y2="164"
        stroke="#2B2420"
        strokeWidth="1.1"
        strokeLinecap="round"
      />
      {/* Windows right */}
      <rect
        x="332"
        y="200"
        width="14"
        height="11"
        fill="#4A5A8B"
        fillOpacity="0.3"
        stroke="#2B2420"
        strokeWidth="0.7"
      />
      <rect
        x="352"
        y="200"
        width="14"
        height="11"
        fill="#4A5A8B"
        fillOpacity="0.45"
        stroke="#2B2420"
        strokeWidth="0.7"
      />
      <rect
        x="332"
        y="222"
        width="14"
        height="11"
        fill="#4A5A8B"
        fillOpacity="0.2"
        stroke="#2B2420"
        strokeWidth="0.7"
      />
      <rect
        x="352"
        y="222"
        width="14"
        height="11"
        fill="#4A5A8B"
        fillOpacity="0.35"
        stroke="#2B2420"
        strokeWidth="0.7"
      />
      {/* Circuit trace to right building */}
      <path
        d="M292,250 L310,250 L310,232 L322,232"
        fill="none"
        stroke="#3B7A7B"
        strokeWidth="1"
        strokeDasharray="3,3"
      />
      <circle cx="310" cy="250" r="2" fill="#3B7A7B" />

      {/* Right small terminal */}
      <rect
        x="394"
        y="240"
        width="52"
        height="40"
        fill="#ECDEC4"
        stroke="#2B2420"
        strokeWidth="1.2"
      />
      <rect
        x="402"
        y="248"
        width="10"
        height="10"
        fill="#B8892B"
        fillOpacity="0.4"
        stroke="#2B2420"
        strokeWidth="0.7"
      />
      <rect
        x="418"
        y="248"
        width="10"
        height="10"
        fill="#B8892B"
        fillOpacity="0.25"
        stroke="#2B2420"
        strokeWidth="0.7"
      />

      {/* Ground terrain */}
      <path
        d="M0,295 Q80,285 160,292 Q240,300 320,288 Q400,278 480,290 L480,380 L0,380 Z"
        fill="#E5D4B0"
        stroke="#2B2420"
        strokeWidth="1.4"
      />

      {/* Ground circuit traces */}
      <path
        d="M100,320 L140,310 L200,310 L240,300"
        fill="none"
        stroke="#3B7A7B"
        strokeWidth="0.9"
        strokeDasharray="3,4"
        strokeOpacity="0.5"
      />
      <path
        d="M480,318 L400,308 L340,315 L290,305"
        fill="none"
        stroke="#3B7A7B"
        strokeWidth="0.9"
        strokeDasharray="3,4"
        strokeOpacity="0.5"
      />

      {/* Ground data nodes */}
      <circle cx="140" cy="310" r="3" fill="#3B7A7B" fillOpacity="0.6" />
      <circle cx="200" cy="310" r="3" fill="#3B7A7B" fillOpacity="0.5" />
      <circle cx="340" cy="315" r="3" fill="#3B7A7B" fillOpacity="0.6" />
      <circle cx="400" cy="308" r="3" fill="#3B7A7B" fillOpacity="0.5" />

      {/* Foreground path markings */}
      <path
        d="M150,355 L200,340 L280,336 L330,348"
        fill="none"
        stroke="#2B2420"
        strokeWidth="1.2"
        strokeOpacity="0.2"
      />
      <path
        d="M155,362 L205,347 L285,342 L335,355"
        fill="none"
        stroke="#2B2420"
        strokeWidth="1.2"
        strokeOpacity="0.15"
      />

      {/* Floating data packets in sky */}
      <circle cx="88" cy="95" r="3" fill="#3B7A7B" fillOpacity="0.4" />
      <circle cx="98" cy="82" r="2" fill="#4A5A8B" fillOpacity="0.4" />
      <circle cx="380" cy="88" r="3" fill="#3B7A7B" fillOpacity="0.35" />
      <circle cx="392" cy="100" r="2" fill="#B8892B" fillOpacity="0.4" />
      <rect
        x="160"
        y="72"
        width="5"
        height="5"
        rx="1"
        fill="#3B7A7B"
        fillOpacity="0.3"
        transform="rotate(15 162 74)"
      />
      <rect
        x="332"
        y="64"
        width="5"
        height="5"
        rx="1"
        fill="#4A5A8B"
        fillOpacity="0.3"
        transform="rotate(-10 334 66)"
      />
    </svg>
  );
}

/** Renders the RegionOverview experience/component and coordinates its user-facing callbacks. */
export default function RegionOverview({ onBack, onStart, onOpenChat }: Props) {
  const content = dataDistrictScenario.overview;
  return (
    <div className="min-h-dvh bg-paper">
      {/* Header */}
      <header className="flex items-center justify-between gap-2 px-3 sm:px-6 py-3 border-b border-ink/10 bg-paper-dark">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-xs text-muted hover:text-ink transition-colors"
          style={{ fontFamily: "'Outfit', sans-serif" }}
          aria-label="Return to Cyberia map"
        >
          <svg width="14" height="14" viewBox="0 0 16 16" fill="none" aria-hidden="true">
            <path
              d="M13 8H3M7 4l-4 4 4 4"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
          Map
        </button>
        <StepIndicator step={1} accent="teal" />
        <div className="hidden sm:block w-16" aria-hidden="true" />
      </header>

      {/* Content */}
      <div className="max-w-6xl mx-auto px-6 lg:px-12 py-10">
        <div className="grid grid-cols-1 lg:grid-cols-[1.1fr_1fr] gap-10 lg:gap-16 items-center">
          {/* Illustration */}
          <div className="order-2 lg:order-1">
            <div className="relative border border-ink/20 rounded-sm overflow-hidden shadow-sm">
              <CircuitArchivesSVG />
              {/* Illustrated caption */}
              <div
                className="absolute bottom-3 left-3 bg-paper/90 border border-ink/15 px-2 py-1 rounded-sm"
                aria-label={content.artworkLabel}
              >
                <span className="text-sm text-muted" style={{ fontFamily: "'Caveat', cursive" }}>
                  {content.caption}
                </span>
              </div>
            </div>
          </div>

          {/* Region info */}
          <div className="order-1 lg:order-2 flex flex-col gap-6">
            {/* Region label */}
            <div>
              <p
                className="text-[10px] tracking-[0.3em] uppercase text-teal mb-1"
                style={{ fontFamily: "'Outfit', sans-serif" }}
              >
                {content.regionLabel}
              </p>
              <h1
                className="font-display leading-tight text-ink"
                style={{
                  fontFamily: "'Caveat', cursive",
                  fontWeight: 700,
                  fontSize: "clamp(2.4rem, 5vw, 3.6rem)",
                }}
              >
                {content.title}
              </h1>
            </div>

            {/* Narrative */}
            <p
              className="text-base text-ink/75 leading-7"
              style={{ fontFamily: "'Outfit', sans-serif" }}
            >
              {content.body}
            </p>

            {/* Region stats */}
            <dl className="grid grid-cols-2 gap-3">
              {content.stats.map((stat) => (
                <RegionStatCard key={stat.label} {...stat} />
              ))}
            </dl>

            {/* CyberRobo companion */}
            <div className="flex items-start gap-4 bg-paper-dark border border-ink/10 rounded-sm px-4 py-4">
              <button
                type="button"
                className="cyberrobo-chat-trigger"
                onClick={onOpenChat}
                disabled={!onOpenChat}
                aria-label="Open CyberRobo chat"
                aria-haspopup="dialog"
              >
                <CyberRoboSVG size={72} className="flex-shrink-0" />
                <span>Chat</span>
              </button>
              <div className="flex-1">
                <p
                  className="text-[9px] tracking-[0.2em] uppercase text-muted mb-2"
                  style={{ fontFamily: "'Outfit', sans-serif" }}
                >
                  CyberRobo
                </p>
                <p
                  className="text-sm text-ink/80 leading-6 italic"
                  style={{ fontFamily: "'Outfit', sans-serif" }}
                >
                  {content.cyberRoboDialogue}
                </p>
              </div>
            </div>

            {/* CTA */}
            <div className="flex items-center gap-4 pt-1">
              <Button onClick={onStart} size="lg" aria-label={content.startLabel}>
                Start Mission
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
                  <path
                    d="M3 8h10M9 4l4 4-4 4"
                    stroke="currentColor"
                    strokeWidth="1.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </Button>
              <span className="text-xs text-muted" style={{ fontFamily: "'Outfit', sans-serif" }}>
                {content.startHint}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
