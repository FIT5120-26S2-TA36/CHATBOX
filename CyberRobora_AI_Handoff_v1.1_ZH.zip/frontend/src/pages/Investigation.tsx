/**
 * @file Investigation routed experience, responsible for composing its content, state callbacks, and accessible UI.
 */
import CyberRoboSVG from "../components/CyberRoboSVG";
import Button from "../components/Button";
import StepIndicator from "../components/gameplay/StepIndicator";
import { dataDistrictScenario } from "../content/dataDistrict";
import type { DataDistrictEvidenceId } from "../game/types";
import useEvidenceInspection from "../hooks/useEvidenceInspection";

interface Props {
  evidence: DataDistrictEvidenceId[];
  onAddEvidence: (evidenceId: DataDistrictEvidenceId) => void;
  onBack: () => void;
  onDecide: () => void;
}

interface InspectableItem {
  id: DataDistrictEvidenceId;
  permission: string;
  level: string;
  appDescription: string;
  evidence: string;
  icon: React.ReactNode;
}

const nimboBlue = "#3A82C4";

function LocationIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <circle cx="10" cy="8" r="3.5" stroke={nimboBlue} strokeWidth="1.5" />
      <path d="M10 2a6 6 0 010 12c-2 0-6-3-6-6a6 6 0 016-6z" stroke={nimboBlue} strokeWidth="1.5" />
      <path d="M10 14v4" stroke={nimboBlue} strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  );
}

function ContactsIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <circle cx="8" cy="7" r="3" stroke={nimboBlue} strokeWidth="1.5" />
      <path d="M2 17c0-3.3 2.7-6 6-6" stroke={nimboBlue} strokeWidth="1.5" strokeLinecap="round" />
      <circle cx="14" cy="8" r="2.5" stroke={nimboBlue} strokeWidth="1.3" />
      <path d="M14 13c2.2 0 4 1.8 4 4" stroke={nimboBlue} strokeWidth="1.3" strokeLinecap="round" />
    </svg>
  );
}

function PhotosIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <rect x="2" y="4" width="16" height="12" rx="2" stroke={nimboBlue} strokeWidth="1.5" />
      <circle cx="7.5" cy="8.5" r="1.5" stroke={nimboBlue} strokeWidth="1.2" />
      <path
        d="M2 13l4-4 3 3 2-2 5 5"
        stroke={nimboBlue}
        strokeWidth="1.3"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function BellIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <path
        d="M10 2a5 5 0 00-5 5v3l-1.5 2.5h13L15 10V7a5 5 0 00-5-5z"
        stroke={nimboBlue}
        strokeWidth="1.5"
        strokeLinejoin="round"
      />
      <path d="M8 15.5a2 2 0 004 0" stroke={nimboBlue} strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  );
}

function ShareIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <circle cx="15" cy="4" r="2" stroke={nimboBlue} strokeWidth="1.4" />
      <circle cx="15" cy="16" r="2" stroke={nimboBlue} strokeWidth="1.4" />
      <circle cx="5" cy="10" r="2" stroke={nimboBlue} strokeWidth="1.4" />
      <path d="M7 9l6-3.5M7 11l6 3.5" stroke={nimboBlue} strokeWidth="1.3" strokeLinecap="round" />
    </svg>
  );
}

function NimboCloudIcon({ size = 48 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none" aria-hidden="true">
      <rect width="48" height="48" rx="12" fill="#EEF5FC" />
      <path
        d="M34 28a6 6 0 00-6-6 1 1 0 01-.8-.4A8 8 0 0010 28H9a5 5 0 000 10h25a5 5 0 000-10h-1z"
        fill="#3A82C4"
        fillOpacity="0.9"
      />
      <circle cx="20" cy="22" r="2" fill="white" fillOpacity="0.6" />
      <circle cx="26" cy="20" r="1.5" fill="white" fillOpacity="0.5" />
      <circle cx="32" cy="23" r="1" fill="white" fillOpacity="0.4" />
    </svg>
  );
}

const permissionIcons: Record<DataDistrictEvidenceId, React.ReactNode> = {
  "location-always": <LocationIcon />,
  "contacts-full": <ContactsIcon />,
  "photos-all": <PhotosIcon />,
  notifications: <BellIcon />,
  "data-sharing": <ShareIcon />,
};
const inspectableItems: InspectableItem[] = dataDistrictScenario.clues.map((clue) => ({
  id: clue.id,
  permission: clue.label,
  level: clue.level ?? "",
  appDescription: clue.presentationDescription ?? "",
  evidence: clue.explanation,
  icon: permissionIcons[clue.id],
}));
const cyberRoboDialogues = dataDistrictScenario.investigationDialogue.lines;

function MagnifyIcon() {
  return (
    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" aria-hidden="true">
      <circle cx="5" cy="5" r="3.5" stroke="currentColor" strokeWidth="1.3" />
      <path d="M7.5 7.5l2.5 2.5" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
    </svg>
  );
}

function CheckSmallIcon() {
  return (
    <svg width="11" height="11" viewBox="0 0 11 11" fill="none" aria-hidden="true">
      <path
        d="M2 5.5l2.5 2.5L9 3"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

/** Renders the Investigation experience/component and coordinates its user-facing callbacks. */
export default function Investigation({ evidence, onAddEvidence, onBack, onDecide }: Props) {
  const { inspectedIds, recentlyAdded, inspectEvidence } = useEvidenceInspection(
    evidence,
    onAddEvidence,
  );

  const evidenceCount = inspectedIds.size;
  const dialogueIndex = Math.min(evidenceCount, cyberRoboDialogues.length - 1);
  const canDecide = true;

  return (
    <div className="min-h-dvh bg-paper flex flex-col">
      <h1 className="sr-only">Nimbo permission investigation</h1>
      <header className="flex items-center justify-between gap-2 px-3 sm:px-6 py-3 border-b border-ink/10 bg-paper-dark">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-xs text-muted hover:text-ink transition-colors"
          style={{ fontFamily: "'Outfit', sans-serif" }}
          aria-label="Return to Data District overview"
        >
          <svg width="14" height="14" viewBox="0 0 16 16" fill="none" aria-hidden="true">
            <path
              d="M13 8H3M7 4l-4 4 4 4"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
          Data District
        </button>
        <StepIndicator step={2} accent="teal" />
        <div className="hidden sm:block w-24" aria-hidden="true" />
      </header>

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-[minmax(0,1fr)_320px] xl:grid-cols-[minmax(0,1fr)_360px] lg:overflow-hidden">
        <div className="p-3 sm:p-5 lg:p-7 flex items-start justify-center overflow-y-auto min-w-0">
          <div className="w-full max-w-lg">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <span
                  className="text-[9px] tracking-[0.25em] uppercase text-teal"
                  style={{ fontFamily: "'Outfit', sans-serif" }}
                >
                  Circuit Archives Terminal
                </span>
                <span
                  className="flex items-center gap-1 text-[9px] text-muted border border-ink/15 px-1.5 py-0.5 rounded-sm"
                  style={{ fontFamily: "'Outfit', sans-serif" }}
                >
                  <span
                    className="w-1.5 h-1.5 rounded-full bg-teal inline-block"
                    aria-hidden="true"
                  />
                  Live
                </span>
              </div>
              <span
                className="text-[9px] text-muted"
                style={{ fontFamily: "'Outfit', sans-serif" }}
              >
                Evidence viewer — tap items to inspect
              </span>
            </div>

            <div className="relative">
              <div
                className="absolute -top-0.5 -left-0.5 w-6 h-6 border-t-2 border-l-2 border-teal z-10"
                aria-hidden="true"
              />
              <div
                className="absolute -top-0.5 -right-0.5 w-6 h-6 border-t-2 border-r-2 border-teal z-10"
                aria-hidden="true"
              />
              <div
                className="absolute -bottom-0.5 -left-0.5 w-6 h-6 border-b-2 border-l-2 border-teal z-10"
                aria-hidden="true"
              />
              <div
                className="absolute -bottom-0.5 -right-0.5 w-6 h-6 border-b-2 border-r-2 border-teal z-10"
                aria-hidden="true"
              />

              <div className="absolute top-3 left-8 flex gap-1.5" aria-hidden="true">
                <div className="w-6 h-px bg-teal/40" />
                <div className="w-3 h-px bg-teal/25" />
              </div>
              <div className="absolute top-3 right-8 flex gap-1.5" aria-hidden="true">
                <div className="w-3 h-px bg-teal/25" />
                <div className="w-6 h-px bg-teal/40" />
              </div>

              <div className="border border-ink/25 bg-paper-darker rounded-sm p-3">
                <div className="bg-white rounded shadow-sm overflow-hidden border border-gray-100">
                  <div className="flex items-center justify-between px-4 py-1.5 bg-white">
                    <span className="text-[10px] font-medium text-gray-700">9:41</span>
                    <div className="flex items-center gap-1.5" aria-hidden="true">
                      <svg width="14" height="10" viewBox="0 0 14 10" fill="none">
                        <rect x="0" y="3" width="2" height="7" rx="0.5" fill="#374151" />
                        <rect x="3" y="2" width="2" height="8" rx="0.5" fill="#374151" />
                        <rect x="6" y="1" width="2" height="9" rx="0.5" fill="#374151" />
                        <rect x="9" y="0" width="2" height="10" rx="0.5" fill="#374151" />
                        <rect
                          x="12"
                          y="0.5"
                          width="1.5"
                          height="7"
                          rx="0.5"
                          fill="none"
                          stroke="#374151"
                          strokeWidth="0.5"
                        />
                        <rect x="12.25" y="1.5" width="1" height="5" rx="0.25" fill="#374151" />
                      </svg>
                      <svg
                        width="14"
                        height="10"
                        viewBox="0 0 14 10"
                        fill="none"
                        aria-hidden="true"
                      >
                        <path
                          d="M7 2.5C9.5 2.5 11.7 3.6 13.2 5.3L12 6.5C10.8 5.1 9 4.2 7 4.2s-3.8.9-5 2.3L.8 5.3C2.3 3.6 4.5 2.5 7 2.5z"
                          fill="#374151"
                        />
                        <path
                          d="M7 5.5c1.5 0 2.9.6 3.9 1.6L9.7 8.3C9 7.5 8.1 7 7 7S5 7.5 4.3 8.3L3.1 7.1C4.1 6.1 5.5 5.5 7 5.5z"
                          fill="#374151"
                        />
                        <circle cx="7" cy="10" r="1" fill="#374151" />
                      </svg>
                      <span className="text-[10px] font-medium text-gray-700">87%</span>
                    </div>
                  </div>

                  <div className="px-5 py-5 bg-gray-50">
                    <div className="flex flex-col items-center mb-5 text-center">
                      <NimboCloudIcon size={52} />
                      <h2
                        className="text-xl font-bold text-gray-900 mt-3"
                        style={{ fontFamily: "system-ui, sans-serif" }}
                      >
                        Welcome to Nimbo
                      </h2>
                      <p
                        className="text-sm text-gray-500 mt-1"
                        style={{ fontFamily: "system-ui, sans-serif" }}
                      >
                        Your intelligent weather companion
                      </p>
                    </div>

                    <div className="bg-white rounded-xl border border-gray-100 divide-y divide-gray-50 mb-4">
                      <p
                        className="px-4 pt-3 pb-2 text-[11px] font-semibold text-gray-400 uppercase tracking-widest"
                        style={{ fontFamily: "system-ui, sans-serif" }}
                      >
                        Nimbo needs access to
                      </p>

                      {inspectableItems.map((item) => {
                        const isInspected = inspectedIds.has(item.id);
                        const isRecent = recentlyAdded === item.id;
                        return (
                          <div
                            key={item.id}
                            className={`relative flex items-start gap-3 px-4 py-3 transition-colors ${
                              isInspected ? "bg-teal-soft/20" : "hover:bg-gray-50"
                            }`}
                          >
                            <div className="flex-shrink-0 mt-0.5">{item.icon}</div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-baseline gap-2">
                                <span
                                  className="text-sm font-semibold text-gray-800"
                                  style={{ fontFamily: "system-ui, sans-serif" }}
                                >
                                  {item.permission}
                                </span>
                                <span
                                  className="text-xs font-medium text-blue-600"
                                  style={{ fontFamily: "system-ui, sans-serif", color: nimboBlue }}
                                >
                                  — {item.level}
                                </span>
                              </div>
                              <p
                                className="text-xs text-gray-500 leading-4 mt-0.5"
                                style={{ fontFamily: "system-ui, sans-serif" }}
                              >
                                {item.appDescription}
                              </p>
                            </div>

                            <div className="flex-shrink-0 self-center">
                              {isInspected ? (
                                <span
                                  className={`inline-flex items-center gap-1 text-[9px] font-medium text-teal px-2 py-1 rounded-sm border border-teal/30 bg-teal-soft/30 transition-all ${
                                    isRecent ? "scale-110" : ""
                                  }`}
                                  aria-label={`${item.permission} inspected`}
                                >
                                  <CheckSmallIcon />
                                  Noted
                                </span>
                              ) : (
                                <button
                                  onClick={() => inspectEvidence(item.id)}
                                  className="inline-flex items-center gap-1 text-[9px] font-medium text-ink/70 hover:text-teal px-2 py-1 rounded-sm border border-ink/20 hover:border-teal/50 bg-paper hover:bg-teal-soft/20 transition-colors"
                                  aria-label={`Inspect ${item.permission} permission — ${item.level}`}
                                  style={{ fontFamily: "'Outfit', sans-serif" }}
                                >
                                  <MagnifyIcon />
                                  Inspect
                                </button>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    <button
                      disabled
                      className="w-full py-3 rounded-xl text-white text-sm font-semibold"
                      style={{ backgroundColor: nimboBlue, fontFamily: "system-ui, sans-serif" }}
                      aria-label="Nimbo get started button (for context only)"
                      tabIndex={-1}
                    >
                      Get Started
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <aside
          className="border-t lg:border-t-0 lg:border-l border-ink/10 bg-paper-dark flex flex-col"
          aria-label="Evidence panel and field companion"
        >
          <div className="flex-1 overflow-y-auto p-5">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p
                  className="text-[9px] tracking-[0.25em] uppercase text-muted"
                  style={{ fontFamily: "'Outfit', sans-serif" }}
                >
                  Evidence Collected
                </p>
                <p
                  className="text-xl font-medium text-ink mt-0.5"
                  style={{ fontFamily: "'Caveat', cursive", fontWeight: 700 }}
                >
                  {evidenceCount}{" "}
                  <span className="text-muted text-base font-normal">
                    of {inspectableItems.length}
                  </span>
                </p>
              </div>
              <div
                className="w-20 bg-paper-darker rounded-full h-1.5 overflow-hidden"
                aria-hidden="true"
              >
                <div
                  className="bg-teal h-full rounded-full transition-all duration-500"
                  style={{ width: `${(evidenceCount / inspectableItems.length) * 100}%` }}
                />
              </div>
            </div>

            <ul
              className="space-y-2.5"
              aria-label="Collected evidence"
              aria-live="polite"
              aria-atomic="false"
            >
              {evidenceCount === 0 && (
                <li
                  className="text-xs text-muted/60 italic text-center py-6 border border-dashed border-ink/10 rounded-sm"
                  style={{ fontFamily: "'Outfit', sans-serif" }}
                >
                  Inspect items in the Nimbo app to collect evidence
                </li>
              )}
              {inspectableItems
                .filter((item) => inspectedIds.has(item.id))
                .map((item) => (
                  <li
                    key={item.id}
                    className={`flex items-start gap-2.5 bg-paper border border-ink/10 rounded-sm px-3 py-2.5 text-xs transition-all ${
                      recentlyAdded === item.id ? "border-teal/40 bg-teal-soft/10" : ""
                    }`}
                  >
                    <span
                      className="mt-0.5 w-1.5 h-1.5 rounded-full bg-teal flex-shrink-0"
                      aria-hidden="true"
                    />
                    <div>
                      <span
                        className="text-[9px] tracking-wide uppercase text-muted block mb-0.5"
                        style={{ fontFamily: "'Outfit', sans-serif" }}
                      >
                        {item.permission}
                      </span>
                      <span
                        className="text-xs text-ink/80 leading-4"
                        style={{ fontFamily: "'Outfit', sans-serif" }}
                      >
                        {item.evidence}
                      </span>
                    </div>
                  </li>
                ))}
            </ul>
          </div>

          <div className="border-t border-ink/10 p-5 space-y-4">
            <div className="flex items-start gap-3">
              <CyberRoboSVG size={56} className="flex-shrink-0" />
              <div>
                <p
                  className="text-[9px] tracking-[0.2em] uppercase text-muted mb-1.5"
                  style={{ fontFamily: "'Outfit', sans-serif" }}
                >
                  CyberRobo
                </p>
                <div
                  className="bg-paper border border-ink/15 rounded-sm px-3 py-2"
                  role="status"
                  aria-live="polite"
                >
                  <p
                    className="text-xs text-ink/80 leading-5 italic"
                    style={{ fontFamily: "'Outfit', sans-serif" }}
                  >
                    "{cyberRoboDialogues[dialogueIndex]}"
                  </p>
                </div>
              </div>
            </div>

            <Button
              onClick={onDecide}
              variant={canDecide ? "primary" : "outline"}
              className="w-full justify-center"
              aria-label="Proceed to make your decision"
            >
              Make Decision
              <svg width="14" height="14" viewBox="0 0 16 16" fill="none" aria-hidden="true">
                <path
                  d="M3 8h10M9 4l4 4-4 4"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </Button>
            {evidenceCount === 0 && (
              <p
                className="text-[10px] text-muted/70 text-center"
                style={{ fontFamily: "'Outfit', sans-serif" }}
              >
                Inspect at least one item first — or proceed if you're ready
              </p>
            )}
          </div>
        </aside>
      </div>
    </div>
  );
}
