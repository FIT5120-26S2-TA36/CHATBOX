/** @vitest-environment jsdom */

import { act, fireEvent, render, screen, within } from "@testing-library/react";
import { useState } from "react";
import { describe, expect, it, vi } from "vitest";
import { dataDistrictClues } from "../content/dataDistrict";
import type { DataDistrictEvidenceId } from "../game/types";
import Investigation from "./Investigation";
import "../test/dom";

function renderInvestigation(evidence: Parameters<typeof Investigation>[0]["evidence"] = []) {
  const onAddEvidence = vi.fn();
  const onBack = vi.fn();
  const onDecide = vi.fn();

  function ControlledInvestigation() {
    const [controlledEvidence, setControlledEvidence] = useState(evidence);
    function addEvidence(evidenceId: DataDistrictEvidenceId) {
      onAddEvidence(evidenceId);
      setControlledEvidence((current) =>
        current.includes(evidenceId) ? current : [...current, evidenceId],
      );
    }
    return (
      <Investigation
        evidence={controlledEvidence}
        onAddEvidence={addEvidence}
        onBack={onBack}
        onDecide={onDecide}
      />
    );
  }

  const view = render(<ControlledInvestigation />);
  return { ...view, onAddEvidence, onBack, onDecide };
}

function collectedEvidence() {
  return screen.getByRole("list", { name: "Collected evidence" });
}

describe("Nimbo investigation interactions", () => {
  it("allows progression with zero evidence, matching current behaviour", () => {
    const { onDecide } = renderInvestigation();

    fireEvent.click(screen.getByRole("button", { name: "Proceed to make your decision" }));

    expect(onDecide).toHaveBeenCalledOnce();
    expect(within(collectedEvidence()).getAllByRole("listitem")).toHaveLength(1);
  });

  it("marks only the inspected item as partial evidence", () => {
    const { onAddEvidence } = renderInvestigation();

    fireEvent.click(screen.getByRole("button", { name: "Inspect Location permission — Always" }));

    expect(onAddEvidence).toHaveBeenCalledWith("location-always");
    expect(screen.getByLabelText("Location inspected")).toBeInstanceOf(HTMLElement);
    expect(screen.queryByLabelText("Contacts inspected")).toBeNull();
    expect(within(collectedEvidence()).getAllByRole("listitem")).toHaveLength(1);
  });

  it("collects all five evidence items exactly once", () => {
    const { onAddEvidence } = renderInvestigation();
    const inspectButtons = screen.getAllByRole("button", { name: /^Inspect .+ permission —/ });

    inspectButtons.forEach((button) => fireEvent.click(button));

    expect(onAddEvidence).toHaveBeenCalledTimes(5);
    expect(new Set(onAddEvidence.mock.calls.map(([id]) => id)).size).toBe(5);
    expect(within(collectedEvidence()).getAllByRole("listitem")).toHaveLength(5);
  });

  it("does not duplicate an item when its inspect control receives repeated clicks", () => {
    const { onAddEvidence } = renderInvestigation();
    const inspect = screen.getByRole("button", {
      name: "Inspect Location permission — Always",
    });

    fireEvent.click(inspect);
    fireEvent.click(inspect);

    expect(onAddEvidence).toHaveBeenCalledTimes(1);
    expect(within(collectedEvidence()).getAllByRole("listitem")).toHaveLength(1);
  });

  it("reflects authoritative evidence changes supplied after the initial render", () => {
    const props = { onAddEvidence: vi.fn(), onBack: vi.fn(), onDecide: vi.fn() };
    const { rerender } = render(<Investigation evidence={["location-always"]} {...props} />);
    expect(screen.getByLabelText("Location inspected")).toBeInstanceOf(HTMLElement);

    rerender(<Investigation evidence={["contacts-full"]} {...props} />);

    expect(screen.queryByLabelText("Location inspected")).toBeNull();
    expect(screen.getByLabelText("Contacts inspected")).toBeInstanceOf(HTMLElement);
  });

  it("shows inspect feedback immediately and clears it after 1.5 seconds", () => {
    vi.useFakeTimers();
    renderInvestigation();
    fireEvent.click(screen.getByRole("button", { name: "Inspect Location permission — Always" }));
    const evidenceItem = screen.getByText(dataDistrictClues[0].explanation).closest("li");

    expect(evidenceItem?.className).toContain("border-teal/40");
    act(() => vi.advanceTimersByTime(1_499));
    expect(evidenceItem?.className).toContain("border-teal/40");
    act(() => vi.advanceTimersByTime(1));
    expect(evidenceItem?.className).not.toContain("border-teal/40");
  });

  it("keeps the latest feedback visible for its own full 1.5-second interval", () => {
    vi.useFakeTimers();
    renderInvestigation();
    fireEvent.click(screen.getByRole("button", { name: "Inspect Location permission — Always" }));
    act(() => vi.advanceTimersByTime(500));
    fireEvent.click(
      screen.getByRole("button", { name: "Inspect Contacts permission — Full access" }),
    );
    const latestItem = screen.getByText(dataDistrictClues[1].explanation).closest("li");

    act(() => vi.advanceTimersByTime(1_000));

    expect(latestItem?.className).toContain("border-teal/40");
  });

  it("cancels pending feedback work when the investigation unmounts", () => {
    vi.useFakeTimers();
    const { unmount } = render(
      <Investigation evidence={[]} onAddEvidence={vi.fn()} onBack={vi.fn()} onDecide={vi.fn()} />,
    );
    fireEvent.click(screen.getByRole("button", { name: "Inspect Location permission — Always" }));

    unmount();

    expect(vi.getTimerCount()).toBe(0);
  });
});
