/**
 * @file Regression scope for Landing, including its externally observable contracts and edge cases.
 */
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import Landing from "./Landing";
import InformationPage from "./InformationPage";

describe("Landing content contracts", () => {
  const markup = renderToStaticMarkup(
    <Landing onStart={() => {}} onHowItWorks={() => {}} onAboutCyberRobora={() => {}} />,
  );

  it("uses canonical branding and real navigation labels", () => {
    expect(markup).toContain("CYBERROBORA");
    expect(markup).toContain("The Quest of");
    expect(markup).toContain("Cyberia");
    expect(markup).toContain("How It Works");
    expect(markup).toContain("About CyberRobora");
    expect(markup).not.toContain("About CyberRobo<");
  });

  it("removes training-status and dense footer metadata", () => {
    expect(markup).not.toContain("Field Investigation Team");
    expect(markup).not.toContain("Field Status");
    expect(markup).not.toContain("Investigation Pending");
    expect(markup).not.toContain("Introductory");
    expect(markup).not.toContain("FIT5120");
    expect(markup).not.toContain("Product:");
    expect(markup).not.toContain("Companion:");
  });

  it("keeps Start Adventure as the single hero entry action", () => {
    expect(markup.match(/Start Adventure/g)).toHaveLength(1);
    expect(markup).not.toContain("Start Investigation");
  });
});

describe("informational skeleton pages", () => {
  it("renders How It Works with a Back-to-Landing control", () => {
    const markup = renderToStaticMarkup(<InformationPage kind="how-it-works" onBack={() => {}} />);

    expect(markup).toContain("<h1");
    expect(markup).toContain("How It Works");
    expect(markup).toContain("Back to Landing");
  });

  it("clarifies the canonical CyberRobora naming", () => {
    const markup = renderToStaticMarkup(
      <InformationPage kind="about-cyberrobora" onBack={() => {}} />,
    );

    expect(markup).toContain("About CyberRobora");
    expect(markup).toContain("CyberRobora is the team");
    expect(markup).toContain("The Quest of Cyberia");
    expect(markup).toContain("CyberRobo accompanies players");
  });
});
