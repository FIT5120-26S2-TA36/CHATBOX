/**
 * @file Regression scope for Map, including its externally observable contracts and edge cases.
 */
import { readFileSync } from "node:fs";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import Map from "./Map";

describe("fullscreen Cyberia map screen", () => {
  const markup = renderToStaticMarkup(<Map investigatedRegions={[]} />);
  const mapCss = readFileSync(new URL("../index.css", import.meta.url), "utf8");
  const appSource = readFileSync(new URL("../App.tsx", import.meta.url), "utf8");

  it("renders the map as the screen with accessible camera controls", () => {
    expect(markup).toContain('data-map-reveal="initial"');
    expect(markup).toContain("Interactive illustrated map of Cyberia");
    expect(markup).toContain('aria-label="Zoom in on Cyberia"');
    expect(markup).toContain('aria-label="Zoom out from Cyberia"');
    expect(markup).toContain('aria-label="Reset Cyberia view"');
    expect(markup).toContain('data-map-camera-controls="right"');
    expect(markup).toContain('data-map-safe-area="right-upper-middle"');
    expect(markup).toContain("top-24 sm:top-28");
    expect(markup).toContain("absolute right-3 z-30");
    expect(markup).not.toContain("absolute left-3 top-1/2");
  });

  it("uses a deterministic short chrome stagger with a static reduced-motion resolution", () => {
    expect(markup).toContain("map-reveal-title");
    expect(markup).toContain("map-reveal-labels");
    expect(markup.match(/map-reveal-tools/g)).toHaveLength(2);
    expect(markup).toContain("map-reveal-guide");
    expect(mapCss).toMatch(/\.map-reveal-labels\s*\{[^}]*75ms/s);
    expect(mapCss).toMatch(/\.map-reveal-tools\s*\{[^}]*150ms/s);
    expect(mapCss).toMatch(/\.map-reveal-guide\s*\{[^}]*225ms/s);
    expect(mapCss).toMatch(/\[data-map-reveal='ready'\][^{]*\{[^}]*opacity:\s*1;/s);
    expect(mapCss).toMatch(
      /@media \(prefers-reduced-motion: reduce\)[\s\S]*map-reveal-title[\s\S]*opacity:\s*1 !important;[\s\S]*transition:\s*none !important;/,
    );
  });

  it("uses floating map tools without a conventional header or Back control", () => {
    expect(markup).toContain("Atlas");
    expect(markup).toContain("Journal");
    expect(markup).not.toContain(">Back<");
    expect(markup).not.toContain("Return to landing page");
    expect(markup).not.toContain("<header");
    expect(markup).not.toContain("Cyberia region index");
    expect(markup).not.toContain("<aside");
  });

  it("keeps the decorative scroll fixed outside the transformed map stage", () => {
    expect(markup).toContain(
      'class="cyberia-map-scroll intro-descent__scroll-frame" aria-hidden="true"',
    );
    expect(markup.indexOf("cyberia-map-scroll")).toBeLessThan(markup.indexOf("cyberia-map-stage"));
  });

  it("mounts one shared surface with inactive live chrome beneath the cinematic", () => {
    const introMarkup = renderToStaticMarkup(
      <Map introActive onIntroComplete={() => {}} investigatedRegions={[]} />,
    );

    expect(introMarkup).toContain('data-map-experience="persistent"');
    expect(introMarkup).toContain('data-intro-active="true"');
    expect(introMarkup).toContain('data-cinematic-overlay="active"');
    expect(introMarkup.match(/data-map-image=/g)).toHaveLength(1);
    expect(introMarkup.match(/class="cyberia-map-viewport/g)).toHaveLength(1);
    expect(
      introMarkup.match(/class="cyberia-map-scroll intro-descent__scroll-frame"/g),
    ).toHaveLength(1);
    expect(introMarkup).toContain('data-map-interactive="false"');
    expect(introMarkup).toContain('data-map-camera="persistent"');
    expect(introMarkup).toContain('data-map-measurement="persistent"');
    expect(introMarkup).toContain('data-map-label-layer="screen-space" aria-hidden="true"');
    expect(introMarkup).not.toContain("data-first-signal-overlay");
  });

  it("keeps one MapExperience inside the persistent host across intro completion", () => {
    expect(appSource.match(/<MapExperience\b/g)).toHaveLength(1);
    expect(appSource).toContain("<ExperienceHost active={showMapExperience}>");
    expect(appSource).toContain('setExperiencePresentation("handoff")');
    expect(appSource).toContain("introActive={cinematicActive}");
    expect(appSource).toContain("navigate(ROUTES.map)");
    expect(appSource).not.toContain("<IntroTransition");
  });

  it("renders the same shared surface directly in live /map mode without an overlay", () => {
    expect(markup).toContain('data-map-experience="persistent"');
    expect(markup).toContain('data-intro-active="false"');
    expect(markup).toContain('data-map-interactive="true"');
    expect(markup.match(/data-map-image=/g)).toHaveLength(1);
    expect(markup).not.toContain("data-cinematic-overlay");
    expect(markup).not.toContain("data-first-signal-overlay");
  });

  it("places one real title at top left and compact CyberRobo guidance at bottom right", () => {
    expect(markup.match(/<h1/g)).toHaveLength(1);
    expect(markup.match(/Field Operations Map/gi)).toHaveLength(1);
    expect(markup).toContain("map-title-scroll");
    expect(markup).toContain("cyberrobo-map-guide");
    expect(markup).toContain('data-cyberrobo-placement="bottom-right-stacked"');
    expect(markup).toContain("flex flex-col items-end");
    expect(markup).toContain("max-w-[8rem]");
  });

  it("keeps speech pointer-transparent while giving the robot a chat button", () => {
    expect(markup).toMatch(/class="[^"]*cyberrobo-map-guide[^"]*pointer-events-none[^"]*"/);
    expect(markup).toContain("CyberRobo says: Something strange is happening across Cyberia");
    expect(markup).toContain('aria-label="CyberRobo, your field companion"');
    expect(markup).toContain('aria-label="Open CyberRobo chat"');
    expect(markup).toContain('class="cyberrobo-chat-trigger"');
    expect(mapCss).toMatch(
      /\.cyberrobo-map-guide__speech::after\s*\{[^}]*pointer-events:\s*none;/s,
    );
  });

  it("renders every named location as a semantic screen-space button", () => {
    expect(markup.match(/data-map-location=/g)).toHaveLength(9);
    expect(markup.match(/data-location-type="gameplay"/g)).toHaveLength(4);
    expect(markup.match(/data-location-type="world"/g)).toHaveLength(5);
    expect(markup).toContain('data-map-label-layer="screen-space"');
    expect(markup).toContain('aria-label="The Laglands — Beyond reach — world location"');
    expect(markup).not.toMatch(/data-map-location=[^>]+scale\(/);
    expect(markup).toContain('data-map-location="market-quarter"');
    expect(markup).toContain('data-map-location="social-square"');
    expect(markup).toContain('data-map-location="cloud-heights"');
  });

  it("retains initial gameplay eligibility and spoiler-light map wording", () => {
    expect(markup).toContain("Begin in the Data District");
    expect(markup).toContain("Data District — Available for investigation");
    expect(markup).toContain("Identity Citadel — Locked");
    expect(markup).not.toContain("connection revealed");
    expect(markup).not.toMatch(/phishing|credential theft|impersonation|misinformation/i);
  });

  it("opens useful world-location Inspector content without an Enter action", () => {
    const worldMarkup = renderToStaticMarkup(
      <Map investigatedRegions={[]} initialSelectedLocationId="laglands" />,
    );

    expect(worldMarkup).toContain("Location Inspector");
    expect(worldMarkup).toContain("Distant mountain region");
    expect(worldMarkup).toContain("Beyond reach — world location");
    expect(worldMarkup).toContain("This place lies beyond the current investigation route.");
    expect(worldMarkup).not.toContain(">Enter Region<");
  });

  it("keeps locked gameplay Inspector copy atmospheric and non-enterable", () => {
    const lockedMarkup = renderToStaticMarkup(
      <Map investigatedRegions={[]} initialSelectedLocationId="identity-citadel" />,
    );

    expect(lockedMarkup).toContain("Location locked");
    expect(lockedMarkup).toContain("A faint disturbance is visible at the Verification Gate");
    expect(lockedMarkup).not.toContain(">Enter Region<");
    expect(lockedMarkup).not.toMatch(/phishing|credential theft|impersonation|misinformation/i);
  });

  it("keeps the Inspector action sticky and shifts controls into its upper safe area", () => {
    const availableMarkup = renderToStaticMarkup(
      <Map investigatedRegions={[]} initialSelectedLocationId="data-district" />,
    );

    expect(availableMarkup).toContain("sticky bottom-0");
    expect(availableMarkup).toContain(">Enter Region<");
    expect(availableMarkup).toContain('data-map-safe-area="right-upper"');
    expect(availableMarkup).toContain("top-16 sm:top-20");
    expect(availableMarkup).not.toContain('data-cyberrobo-placement="bottom-right-stacked"');
    expect(availableMarkup).toContain("CyberRobo says:");
  });
});
