/**
 * @file Consequence routed experience, responsible for composing its content, state callbacks, and accessible UI.
 */
import ConsequenceSections from "../components/gameplay/ConsequenceSections";
import PageHeader from "../components/gameplay/PageHeader";
import type { CommittedJourneyResult } from "../api/cyberroboraApi";

interface Props {
  result: CommittedJourneyResult;
  onContinue: () => void;
}
/** Renders the Consequence experience/component and coordinates its user-facing callbacks. */
export default function Consequence({ result, onContinue }: Props) {
  const content = result.content;
  return (
    <div className="min-h-dvh bg-paper flex flex-col">
      <PageHeader center="Data District · Result" />
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-2xl mx-auto px-6 lg:px-8 py-10 space-y-10">
          <div>
            <p
              className="text-[10px] tracking-[0.3em] uppercase text-muted mb-2"
              style={{ fontFamily: "'Outfit', sans-serif" }}
            >
              Data District — Circuit Archives
            </p>
            <h1
              className="text-ink mb-1"
              style={{
                fontFamily: "'Caveat', cursive",
                fontWeight: 700,
                fontSize: "clamp(2rem, 5vw, 2.8rem)",
                lineHeight: 1.1,
              }}
            >
              {content.outcomeLabel}
            </h1>
            <p className="text-sm text-muted" style={{ fontFamily: "'Outfit', sans-serif" }}>
              Decision: {result.selectedAction.label}
            </p>
          </div>
          <div className="border-t border-ink/10" />
          <ConsequenceSections
            content={content}
            accent="teal"
            reflection={content.cyberRoboReflection ?? ""}
          />
          <div className="flex items-center gap-4 pb-4">
            <button
              onClick={onContinue}
              className="inline-flex items-center gap-2.5 bg-ink text-paper px-7 py-3.5 text-sm font-medium rounded-sm hover:bg-teal transition-colors"
              style={{ fontFamily: "'Outfit', sans-serif" }}
              aria-label="Continue to the Cyberia map"
            >
              Continue to Cyberia
              <svg width="14" height="14" viewBox="0 0 16 16" fill="none" aria-hidden="true">
                <path
                  d="M3 8h10M9 4l4 4-4 4"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
