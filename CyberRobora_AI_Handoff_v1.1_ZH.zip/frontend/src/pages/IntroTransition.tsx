/**
 * Renders the presentation-only cinematic. Each phase owns one cleanup-safe timeout, Skip reaches
 * completion immediately, and the completion ref guarantees the parent callback fires once.
 */
import { useEffect, useReducer, useRef } from "react";
import CyberRoboSVG from "../components/CyberRoboSVG";
import usePrefersReducedMotion from "../hooks/usePrefersReducedMotion";
import {
  createIntroTransitionState,
  getIntroPhaseDuration,
  getTimedIntroAction,
  introTransitionReducer,
  shouldReportIntroCompletion,
  type IntroPhase,
} from "../intro/transition";

interface Props {
  onComplete: () => void;
  onPhaseChange?: (phase: IntroPhase) => void;
  onSkip?: () => void;
  reducedMotion?: boolean;
}

/** Renders the IntroTransition experience/component and coordinates its user-facing callbacks. */
export default function IntroTransition({
  onComplete,
  onPhaseChange,
  onSkip,
  reducedMotion: reducedMotionOverride,
}: Props) {
  const detectedReducedMotion = usePrefersReducedMotion(reducedMotionOverride === undefined);
  const reducedMotion = reducedMotionOverride ?? detectedReducedMotion;
  const [state, dispatch] = useReducer(
    introTransitionReducer,
    reducedMotion,
    createIntroTransitionState,
  );
  const completionReported = useRef(false);
  const { phase } = state;

  useEffect(() => {
    onPhaseChange?.(phase);

    if (phase === "complete") {
      if (shouldReportIntroCompletion(phase, completionReported.current)) {
        completionReported.current = true;
        onComplete();
      }
      return;
    }

    const duration = getIntroPhaseDuration(phase, reducedMotion);
    if (duration === null) return;

    const timer = window.setTimeout(() => {
      dispatch(getTimedIntroAction(reducedMotion));
    }, duration);

    return () => window.clearTimeout(timer);
  }, [onComplete, onPhaseChange, phase, reducedMotion]);

  const narrativeVisible = phase === "narrative";
  const cyberRoboVisible = phase === "cyberrobo";
  const signalVisible = phase === "first-signal";

  return (
    <div
      className="intro-cinematic-overlay absolute inset-0 z-50 isolate overflow-hidden text-ink"
      data-cinematic-overlay="active"
      data-phase={phase}
      data-reduced-motion={reducedMotion ? "true" : "false"}
    >
      <div className="intro-descent__wash" aria-hidden="true" />
      <div className="intro-fog-field" aria-hidden="true">
        <div
          className="intro-fog-layer intro-fog-layer--far"
          data-fog-layer="far"
          aria-hidden="true"
        />
        <div
          className="intro-fog-layer intro-fog-layer--middle"
          data-fog-layer="middle"
          aria-hidden="true"
        />
        <div
          className="intro-fog-layer intro-fog-layer--near"
          data-fog-layer="near"
          aria-hidden="true"
        />
        <div
          className="intro-fog-layer intro-fog-layer--veil"
          data-fog-layer="veil"
          aria-hidden="true"
        />
      </div>

      {phase !== "complete" && (
        <button
          type="button"
          onClick={() => {
            onSkip?.();
            dispatch({ type: "SKIP" });
          }}
          className="absolute right-3 top-3 z-40 inline-flex min-h-11 items-center rounded-sm border border-ink/18 bg-paper/75 px-3 text-[10px] font-semibold uppercase tracking-[0.1em] text-muted transition-colors hover:border-teal hover:text-teal sm:right-6 sm:top-6 sm:border-ink/25 sm:bg-paper/90 sm:px-4 sm:text-xs sm:tracking-[0.12em]"
          aria-label="Skip intro and open the Cyberia map"
        >
          Skip Intro
        </button>
      )}

      <section
        className="relative z-30 mx-auto h-full w-full max-w-4xl px-4 pb-5 pt-16 sm:px-8 sm:pb-8 sm:pt-20"
        aria-label="Journey into Cyberia"
      >
        {reducedMotion ? (
          <div className="intro-copy is-visible">
            <div className="intro-copy__mist max-w-2xl text-center">
              <p className="mb-2 text-[9px] font-semibold uppercase tracking-[0.28em] text-muted sm:text-[10px]">
                An illustrated cybersecurity adventure
              </p>
              <h1
                className="font-display text-[clamp(2.7rem,8vw,5.2rem)] font-bold leading-none text-ink"
                style={{ fontFamily: "'Caveat', cursive" }}
              >
                A Disturbance in Cyberia
              </h1>
              <p className="mx-auto mt-4 max-w-xl text-xs leading-5 text-ink/80 sm:text-sm sm:leading-6">
                Small anomalies are appearing across Cyberia, and CyberRobo needs your help to
                investigate them.
              </p>
              <p className="mx-auto mt-3 max-w-xl text-sm font-semibold text-teal sm:text-base">
                The first clear signal is coming from Data District.
              </p>
            </div>
          </div>
        ) : (
          <>
            <div
              className={`intro-copy ${narrativeVisible ? "is-visible" : ""}`}
              aria-hidden={!narrativeVisible}
            >
              <div className="intro-copy__mist max-w-2xl text-center">
                <p className="mb-2 text-[9px] font-semibold uppercase tracking-[0.28em] text-muted sm:text-[10px]">
                  An illustrated cybersecurity adventure
                </p>
                <h1
                  className="font-display text-[clamp(2.7rem,8vw,5.2rem)] font-bold leading-none text-ink"
                  style={{ fontFamily: "'Caveat', cursive" }}
                >
                  A Disturbance in Cyberia
                </h1>
                <div className="mx-auto mt-4 max-w-xl space-y-2 text-xs leading-5 text-ink/80 sm:mt-5 sm:text-sm sm:leading-6">
                  <p>
                    Cyberia is woven through everyday digital life — messages, identities, shared
                    data, and the places where people connect.
                  </p>
                  <p>
                    Recently, something has shifted. Small anomalies. Disruptions that seem
                    unrelated — until you look closely.
                  </p>
                </div>
              </div>
            </div>

            <div
              className={`intro-copy ${cyberRoboVisible ? "is-visible" : ""}`}
              aria-hidden={!cyberRoboVisible}
            >
              <div className="intro-copy__mist intro-copy__cyberrobo flex max-w-2xl items-center gap-3 px-2 text-left sm:gap-5 sm:px-0">
                <CyberRoboSVG size={78} className="h-auto w-14 flex-shrink-0 sm:w-20" />
                <div className="border-y border-ink/20 bg-paper/75 px-3 py-3 text-[11px] italic leading-[1.55] text-ink/85 sm:px-5 sm:py-4 sm:text-sm sm:leading-6">
                  <p>
                    “Something strange is happening across Cyberia. Nothing looks completely wrong
                    on its own… but the disturbances seem connected.”
                  </p>
                  <p className="mt-2">
                    “I can help you examine what we find. But the decisions are yours.”
                  </p>
                </div>
              </div>
            </div>

            <div
              className={`intro-copy intro-copy--signal ${signalVisible ? "is-visible" : ""}`}
              aria-hidden={!signalVisible}
            >
              <div className="intro-copy__mist max-w-xl border-y border-ink/20 px-5 py-5 text-center sm:px-8 sm:py-7">
                <p className="text-[10px] font-semibold uppercase tracking-[0.25em] text-teal">
                  First Signal
                </p>
                <p
                  className="mt-2 font-display text-3xl font-bold leading-tight text-ink sm:text-5xl"
                  style={{ fontFamily: "'Caveat', cursive" }}
                >
                  The first clear signal is coming from Data District.
                </p>
              </div>
            </div>
          </>
        )}
      </section>
    </div>
  );
}
