/**
 * @file CitadelOverview routed experience, responsible for composing its content, state callbacks, and accessible UI.
 */
import CyberRoboSVG from "../components/CyberRoboSVG";
import Button from "../components/Button";
import RegionStatCard from "../components/gameplay/RegionStatCard";
import StepIndicator from "../components/gameplay/StepIndicator";
import { identityCitadelScenario } from "../content/identityCitadel";

interface Props {
  onOpenChat?: () => void;
  onBack: () => void;
  onStart: () => void;
}

function VerificationGateSVG() {
  return (
    <svg
      viewBox="0 0 480 380"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-label="Illustrated scene of the Verification Gate, central landmark of Identity Citadel"
      role="img"
      className="w-full h-auto"
    >
      {/* Sky — indigo wash */}
      <rect width="480" height="380" fill="#EAEDF6" fillOpacity="0.9" />
      <ellipse cx="240" cy="80" rx="300" ry="110" fill="#CDD3EC" fillOpacity="0.28" />
      <ellipse cx="140" cy="40" rx="120" ry="50" fill="#CDD3EC" fillOpacity="0.15" />

      {/* Distant silhouette towers */}
      <rect x="0" y="218" width="34" height="82" fill="#CDD3EC" fillOpacity="0.18" />
      <rect x="6" y="206" width="14" height="16" fill="#CDD3EC" fillOpacity="0.14" />
      <rect x="22" y="210" width="14" height="12" fill="#CDD3EC" fillOpacity="0.14" />
      <rect x="440" y="222" width="40" height="78" fill="#CDD3EC" fillOpacity="0.15" />
      <rect x="440" y="210" width="14" height="16" fill="#CDD3EC" fillOpacity="0.12" />

      {/* ── LEFT MAIN TOWER ── */}
      {/* Battlements */}
      <rect x="44" y="88" width="14" height="16" fill="#CDD3EC" stroke="#2B2420" strokeWidth="1" />
      <rect x="62" y="88" width="14" height="16" fill="#CDD3EC" stroke="#2B2420" strokeWidth="1" />
      <rect x="80" y="88" width="14" height="16" fill="#CDD3EC" stroke="#2B2420" strokeWidth="1" />
      <rect x="98" y="88" width="14" height="16" fill="#CDD3EC" stroke="#2B2420" strokeWidth="1" />
      {/* Upper cap */}
      <rect
        x="40"
        y="102"
        width="76"
        height="42"
        fill="#CDD3EC"
        stroke="#2B2420"
        strokeWidth="1.3"
      />
      {/* Main shaft */}
      <rect
        x="44"
        y="142"
        width="68"
        height="138"
        fill="#CDD3EC"
        stroke="#2B2420"
        strokeWidth="1.4"
      />
      {/* Windows */}
      <rect
        x="54"
        y="156"
        width="16"
        height="12"
        fill="#4A5A8B"
        fillOpacity="0.35"
        stroke="#2B2420"
        strokeWidth="0.8"
      />
      <rect
        x="78"
        y="156"
        width="16"
        height="12"
        fill="#4A5A8B"
        fillOpacity="0.5"
        stroke="#2B2420"
        strokeWidth="0.8"
      />
      <rect
        x="54"
        y="178"
        width="16"
        height="12"
        fill="#4A5A8B"
        fillOpacity="0.25"
        stroke="#2B2420"
        strokeWidth="0.8"
      />
      <rect
        x="78"
        y="178"
        width="16"
        height="12"
        fill="#4A5A8B"
        fillOpacity="0.4"
        stroke="#2B2420"
        strokeWidth="0.8"
      />
      <rect
        x="54"
        y="200"
        width="16"
        height="12"
        fill="#4A5A8B"
        fillOpacity="0.45"
        stroke="#2B2420"
        strokeWidth="0.8"
      />
      <rect
        x="78"
        y="200"
        width="16"
        height="12"
        fill="#4A5A8B"
        fillOpacity="0.3"
        stroke="#2B2420"
        strokeWidth="0.8"
      />
      {/* Arrow slit */}
      <rect
        x="69"
        y="225"
        width="8"
        height="20"
        fill="#2B2420"
        fillOpacity="0.18"
        stroke="#2B2420"
        strokeWidth="0.7"
      />

      {/* ── RIGHT MAIN TOWER (mirror) ── */}
      <rect x="366" y="88" width="14" height="16" fill="#CDD3EC" stroke="#2B2420" strokeWidth="1" />
      <rect x="384" y="88" width="14" height="16" fill="#CDD3EC" stroke="#2B2420" strokeWidth="1" />
      <rect x="402" y="88" width="14" height="16" fill="#CDD3EC" stroke="#2B2420" strokeWidth="1" />
      <rect x="420" y="88" width="14" height="16" fill="#CDD3EC" stroke="#2B2420" strokeWidth="1" />
      <rect
        x="364"
        y="102"
        width="76"
        height="42"
        fill="#CDD3EC"
        stroke="#2B2420"
        strokeWidth="1.3"
      />
      <rect
        x="368"
        y="142"
        width="68"
        height="138"
        fill="#CDD3EC"
        stroke="#2B2420"
        strokeWidth="1.4"
      />
      <rect
        x="374"
        y="156"
        width="16"
        height="12"
        fill="#4A5A8B"
        fillOpacity="0.4"
        stroke="#2B2420"
        strokeWidth="0.8"
      />
      <rect
        x="398"
        y="156"
        width="16"
        height="12"
        fill="#4A5A8B"
        fillOpacity="0.3"
        stroke="#2B2420"
        strokeWidth="0.8"
      />
      <rect
        x="374"
        y="178"
        width="16"
        height="12"
        fill="#4A5A8B"
        fillOpacity="0.5"
        stroke="#2B2420"
        strokeWidth="0.8"
      />
      <rect
        x="398"
        y="178"
        width="16"
        height="12"
        fill="#4A5A8B"
        fillOpacity="0.25"
        stroke="#2B2420"
        strokeWidth="0.8"
      />
      <rect
        x="374"
        y="200"
        width="16"
        height="12"
        fill="#4A5A8B"
        fillOpacity="0.35"
        stroke="#2B2420"
        strokeWidth="0.8"
      />
      <rect
        x="398"
        y="200"
        width="16"
        height="12"
        fill="#4A5A8B"
        fillOpacity="0.45"
        stroke="#2B2420"
        strokeWidth="0.8"
      />
      <rect
        x="403"
        y="225"
        width="8"
        height="20"
        fill="#2B2420"
        fillOpacity="0.18"
        stroke="#2B2420"
        strokeWidth="0.7"
      />

      {/* ── CURTAIN WALL — left segment (towers to gate) ── */}
      {/* Left wall battlements */}
      <rect
        x="112"
        y="168"
        width="14"
        height="16"
        fill="#CDD3EC"
        stroke="#2B2420"
        strokeWidth="0.9"
      />
      <rect
        x="130"
        y="168"
        width="14"
        height="16"
        fill="#CDD3EC"
        stroke="#2B2420"
        strokeWidth="0.9"
      />
      <rect
        x="148"
        y="168"
        width="14"
        height="16"
        fill="#CDD3EC"
        stroke="#2B2420"
        strokeWidth="0.9"
      />
      {/* Left wall body */}
      <rect
        x="112"
        y="182"
        width="62"
        height="98"
        fill="#CDD3EC"
        stroke="#2B2420"
        strokeWidth="1.3"
      />
      {/* Right wall battlements */}
      <rect
        x="310"
        y="168"
        width="14"
        height="16"
        fill="#CDD3EC"
        stroke="#2B2420"
        strokeWidth="0.9"
      />
      <rect
        x="328"
        y="168"
        width="14"
        height="16"
        fill="#CDD3EC"
        stroke="#2B2420"
        strokeWidth="0.9"
      />
      <rect
        x="346"
        y="168"
        width="14"
        height="16"
        fill="#CDD3EC"
        stroke="#2B2420"
        strokeWidth="0.9"
      />
      {/* Right wall body */}
      <rect
        x="306"
        y="182"
        width="62"
        height="98"
        fill="#CDD3EC"
        stroke="#2B2420"
        strokeWidth="1.3"
      />

      {/* ── MAIN GATE ARCH ── */}
      {/* Shadow/depth behind arch */}
      <path
        d="M178,280 L178,248 Q178,202 240,198 Q302,202 302,248 L302,280 Z"
        fill="#9BA8C8"
        fillOpacity="0.65"
      />
      {/* Arch stone outer outline */}
      <path
        d="M174,280 L174,246 Q174,194 240,192 Q306,194 306,246 L306,280"
        fill="none"
        stroke="#2B2420"
        strokeWidth="1.6"
      />
      {/* Arch keystone accent */}
      <path
        d="M228,196 Q240,184 252,196"
        fill="none"
        stroke="#2B2420"
        strokeWidth="1.1"
        strokeOpacity="0.55"
      />
      {/* Portcullis vertical bars */}
      <line
        x1="192"
        y1="198"
        x2="192"
        y2="280"
        stroke="#2B2420"
        strokeWidth="0.9"
        strokeOpacity="0.22"
      />
      <line
        x1="210"
        y1="198"
        x2="210"
        y2="280"
        stroke="#2B2420"
        strokeWidth="0.9"
        strokeOpacity="0.22"
      />
      <line
        x1="228"
        y1="200"
        x2="228"
        y2="280"
        stroke="#2B2420"
        strokeWidth="0.9"
        strokeOpacity="0.22"
      />
      <line
        x1="252"
        y1="200"
        x2="252"
        y2="280"
        stroke="#2B2420"
        strokeWidth="0.9"
        strokeOpacity="0.22"
      />
      <line
        x1="270"
        y1="198"
        x2="270"
        y2="280"
        stroke="#2B2420"
        strokeWidth="0.9"
        strokeOpacity="0.22"
      />
      <line
        x1="288"
        y1="198"
        x2="288"
        y2="280"
        stroke="#2B2420"
        strokeWidth="0.9"
        strokeOpacity="0.22"
      />
      {/* Portcullis horizontal bars */}
      <line
        x1="176"
        y1="228"
        x2="304"
        y2="228"
        stroke="#2B2420"
        strokeWidth="0.8"
        strokeOpacity="0.18"
      />
      <line
        x1="176"
        y1="254"
        x2="304"
        y2="254"
        stroke="#2B2420"
        strokeWidth="0.8"
        strokeOpacity="0.18"
      />

      {/* ── CREST ABOVE GATE ── */}
      <circle
        cx="240"
        cy="176"
        r="24"
        fill="#F5EFE3"
        fillOpacity="0.92"
        stroke="#2B2420"
        strokeWidth="1.2"
      />
      <circle
        cx="240"
        cy="176"
        r="17"
        fill="none"
        stroke="#4A5A8B"
        strokeWidth="0.8"
        strokeOpacity="0.45"
        strokeDasharray="2.5,2.5"
      />
      {/* ID card symbol inside crest */}
      <rect
        x="228"
        y="168"
        width="24"
        height="16"
        rx="2"
        fill="none"
        stroke="#4A5A8B"
        strokeWidth="1.1"
      />
      <circle cx="234" cy="174" r="3" fill="#4A5A8B" fillOpacity="0.45" />
      <line
        x1="240"
        y1="172"
        x2="250"
        y2="172"
        stroke="#4A5A8B"
        strokeWidth="0.9"
        strokeOpacity="0.6"
      />
      <line
        x1="240"
        y1="176"
        x2="248"
        y2="176"
        stroke="#4A5A8B"
        strokeWidth="0.9"
        strokeOpacity="0.4"
      />

      {/* ── VERIFICATION SCANNER PANELS ── */}
      {/* Left scanner */}
      <rect
        x="138"
        y="228"
        width="28"
        height="42"
        rx="2"
        fill="#EAEDF6"
        stroke="#4A5A8B"
        strokeWidth="1.1"
      />
      <rect x="141" y="234" width="22" height="16" rx="1" fill="#CDD3EC" fillOpacity="0.45" />
      <line
        x1="141"
        y1="238"
        x2="163"
        y2="238"
        stroke="#4A5A8B"
        strokeWidth="0.8"
        strokeOpacity="0.6"
      />
      <line
        x1="141"
        y1="242"
        x2="163"
        y2="242"
        stroke="#4A5A8B"
        strokeWidth="0.8"
        strokeOpacity="0.4"
      />
      <line
        x1="141"
        y1="246"
        x2="163"
        y2="246"
        stroke="#4A5A8B"
        strokeWidth="0.8"
        strokeOpacity="0.6"
      />
      <circle cx="152" cy="260" r="4" fill="#3B7A7B" fillOpacity="0.65" />
      <circle
        cx="152"
        cy="260"
        r="6.5"
        fill="none"
        stroke="#3B7A7B"
        strokeWidth="0.9"
        strokeOpacity="0.35"
      />
      {/* Right scanner */}
      <rect
        x="314"
        y="228"
        width="28"
        height="42"
        rx="2"
        fill="#EAEDF6"
        stroke="#4A5A8B"
        strokeWidth="1.1"
      />
      <rect x="317" y="234" width="22" height="16" rx="1" fill="#CDD3EC" fillOpacity="0.45" />
      <line
        x1="317"
        y1="238"
        x2="339"
        y2="238"
        stroke="#4A5A8B"
        strokeWidth="0.8"
        strokeOpacity="0.6"
      />
      <line
        x1="317"
        y1="242"
        x2="339"
        y2="242"
        stroke="#4A5A8B"
        strokeWidth="0.8"
        strokeOpacity="0.4"
      />
      <line
        x1="317"
        y1="246"
        x2="339"
        y2="246"
        stroke="#4A5A8B"
        strokeWidth="0.8"
        strokeOpacity="0.6"
      />
      <circle cx="328" cy="260" r="4" fill="#3B7A7B" fillOpacity="0.65" />
      <circle
        cx="328"
        cy="260"
        r="6.5"
        fill="none"
        stroke="#3B7A7B"
        strokeWidth="0.9"
        strokeOpacity="0.35"
      />

      {/* ── FLOATING CREDENTIAL CARDS ── */}
      {/* Card 1 — top left, slightly rotated */}
      <g transform="rotate(-7 56 84)">
        <rect
          x="24"
          y="60"
          width="60"
          height="40"
          rx="3"
          fill="#F5EFE3"
          fillOpacity="0.93"
          stroke="#4A5A8B"
          strokeWidth="1"
          strokeOpacity="0.65"
        />
        <circle cx="37" cy="73" r="5.5" fill="#CDD3EC" />
        <line
          x1="46"
          y1="71"
          x2="76"
          y2="71"
          stroke="#4A5A8B"
          strokeWidth="0.9"
          strokeOpacity="0.6"
        />
        <line
          x1="46"
          y1="75"
          x2="70"
          y2="75"
          stroke="#4A5A8B"
          strokeWidth="0.9"
          strokeOpacity="0.4"
        />
        <line
          x1="30"
          y1="84"
          x2="76"
          y2="84"
          stroke="#4A5A8B"
          strokeWidth="0.7"
          strokeOpacity="0.28"
        />
        <line
          x1="30"
          y1="88"
          x2="62"
          y2="88"
          stroke="#4A5A8B"
          strokeWidth="0.7"
          strokeOpacity="0.22"
        />
      </g>
      {/* Card 2 — top right, opposite tilt */}
      <g transform="rotate(6 414 66)">
        <rect
          x="388"
          y="46"
          width="60"
          height="40"
          rx="3"
          fill="#F5EFE3"
          fillOpacity="0.93"
          stroke="#4A5A8B"
          strokeWidth="1"
          strokeOpacity="0.65"
        />
        <circle cx="401" cy="59" r="5.5" fill="#CDD3EC" />
        <line
          x1="410"
          y1="57"
          x2="440"
          y2="57"
          stroke="#4A5A8B"
          strokeWidth="0.9"
          strokeOpacity="0.6"
        />
        <line
          x1="410"
          y1="61"
          x2="434"
          y2="61"
          stroke="#4A5A8B"
          strokeWidth="0.9"
          strokeOpacity="0.4"
        />
        <line
          x1="394"
          y1="70"
          x2="440"
          y2="70"
          stroke="#4A5A8B"
          strokeWidth="0.7"
          strokeOpacity="0.28"
        />
        <line
          x1="394"
          y1="74"
          x2="426"
          y2="74"
          stroke="#4A5A8B"
          strokeWidth="0.7"
          strokeOpacity="0.22"
        />
      </g>
      {/* Card 3 — smaller, higher up */}
      <g transform="rotate(-3 112 32)">
        <rect
          x="88"
          y="18"
          width="46"
          height="30"
          rx="2"
          fill="#F5EFE3"
          fillOpacity="0.82"
          stroke="#4A5A8B"
          strokeWidth="0.9"
          strokeOpacity="0.5"
        />
        <circle cx="98" cy="28" r="4" fill="#CDD3EC" fillOpacity="0.85" />
        <line
          x1="106"
          y1="27"
          x2="128"
          y2="27"
          stroke="#4A5A8B"
          strokeWidth="0.7"
          strokeOpacity="0.55"
        />
        <line
          x1="106"
          y1="30"
          x2="122"
          y2="30"
          stroke="#4A5A8B"
          strokeWidth="0.7"
          strokeOpacity="0.35"
        />
        <line
          x1="93"
          y1="38"
          x2="128"
          y2="38"
          stroke="#4A5A8B"
          strokeWidth="0.6"
          strokeOpacity="0.22"
        />
      </g>
      {/* Card 4 — right side, mid-height */}
      <g transform="rotate(5 436 154)">
        <rect
          x="414"
          y="140"
          width="44"
          height="28"
          rx="2"
          fill="#F5EFE3"
          fillOpacity="0.78"
          stroke="#4A5A8B"
          strokeWidth="0.8"
          strokeOpacity="0.45"
        />
        <circle cx="423" cy="151" r="3.5" fill="#CDD3EC" fillOpacity="0.8" />
        <line
          x1="430"
          y1="150"
          x2="452"
          y2="150"
          stroke="#4A5A8B"
          strokeWidth="0.7"
          strokeOpacity="0.5"
        />
        <line
          x1="430"
          y1="153"
          x2="448"
          y2="153"
          stroke="#4A5A8B"
          strokeWidth="0.7"
          strokeOpacity="0.35"
        />
        <line
          x1="418"
          y1="160"
          x2="452"
          y2="160"
          stroke="#4A5A8B"
          strokeWidth="0.6"
          strokeOpacity="0.22"
        />
      </g>

      {/* Gate nameplate */}
      <rect
        x="193"
        y="281"
        width="94"
        height="14"
        rx="1"
        fill="#2B2420"
        fillOpacity="0.06"
        stroke="#2B2420"
        strokeWidth="0.7"
        strokeOpacity="0.4"
      />
      <text
        x="240"
        y="292"
        textAnchor="middle"
        fontFamily="'Caveat', cursive"
        fontSize="8"
        fill="#2B2420"
        fillOpacity="0.55"
      >
        Verification Gate
      </text>

      {/* Ground terrain */}
      <path
        d="M0,286 Q80,276 160,283 Q240,291 320,279 Q400,269 480,279 L480,380 L0,380 Z"
        fill="#E5D4B0"
        stroke="#2B2420"
        strokeWidth="1.4"
      />
      {/* Cobblestone path to gate */}
      <line
        x1="226"
        y1="295"
        x2="208"
        y2="380"
        stroke="#2B2420"
        strokeWidth="1.4"
        strokeOpacity="0.16"
      />
      <line
        x1="254"
        y1="295"
        x2="272"
        y2="380"
        stroke="#2B2420"
        strokeWidth="1.4"
        strokeOpacity="0.16"
      />
      <line
        x1="200"
        y1="330"
        x2="280"
        y2="330"
        stroke="#2B2420"
        strokeWidth="0.9"
        strokeOpacity="0.1"
      />
      <line
        x1="196"
        y1="350"
        x2="284"
        y2="350"
        stroke="#2B2420"
        strokeWidth="0.9"
        strokeOpacity="0.1"
      />
      {/* Tower ground shadows */}
      <ellipse cx="78" cy="283" rx="42" ry="5" fill="#2B2420" fillOpacity="0.05" />
      <ellipse cx="402" cy="283" rx="42" ry="5" fill="#2B2420" fillOpacity="0.05" />
    </svg>
  );
}

/** Renders the CitadelOverview experience/component and coordinates its user-facing callbacks. */
export default function CitadelOverview({ onBack, onStart, onOpenChat }: Props) {
  const content = identityCitadelScenario.overview;
  return (
    <div className="min-h-dvh bg-paper">
      {/* Header */}
      <header className="flex items-center justify-between gap-2 px-3 sm:px-6 py-3 border-b border-ink/10 bg-paper-dark">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-xs text-muted hover:text-ink transition-colors"
          style={{ fontFamily: "'Outfit', sans-serif" }}
          aria-label="Return to Cyberia map"
        >
          <svg width="14" height="14" viewBox="0 0 16 16" fill="none" aria-hidden="true">
            <path
              d="M13 8H3M7 4l-4 4 4 4"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
          Map
        </button>
        <StepIndicator step={1} accent="indigo" />
        <div className="hidden sm:block w-16" aria-hidden="true" />
      </header>

      {/* Content */}
      <div className="max-w-6xl mx-auto px-6 lg:px-12 py-10">
        <div className="grid grid-cols-1 lg:grid-cols-[1.1fr_1fr] gap-10 lg:gap-16 items-center">
          {/* Illustration */}
          <div className="order-2 lg:order-1">
            <div className="relative border border-ink/20 rounded-sm overflow-hidden shadow-sm">
              <VerificationGateSVG />
              <div
                className="absolute bottom-3 left-3 bg-paper/90 border border-ink/15 px-2 py-1 rounded-sm"
                aria-label={content.artworkLabel}
              >
                <span className="text-sm text-muted" style={{ fontFamily: "'Caveat', cursive" }}>
                  {content.caption}
                </span>
              </div>
            </div>
          </div>

          {/* Region info */}
          <div className="order-1 lg:order-2 flex flex-col gap-6">
            <div>
              <p
                className="text-[10px] tracking-[0.3em] uppercase text-indigo mb-1"
                style={{ fontFamily: "'Outfit', sans-serif" }}
              >
                {content.regionLabel}
              </p>
              <h1
                className="font-display leading-tight text-ink"
                style={{
                  fontFamily: "'Caveat', cursive",
                  fontWeight: 700,
                  fontSize: "clamp(2.4rem, 5vw, 3.6rem)",
                }}
              >
                {content.title}
              </h1>
            </div>

            <p
              className="text-base text-ink/75 leading-7"
              style={{ fontFamily: "'Outfit', sans-serif" }}
            >
              {content.body}
            </p>

            <p
              className="text-sm text-ink/60 leading-6 italic border-l-2 border-indigo/30 pl-4"
              style={{ fontFamily: "'Outfit', sans-serif" }}
            >
              {content.prompt}
            </p>

            <dl className="grid grid-cols-2 gap-3">
              {content.stats.map((stat) => (
                <RegionStatCard key={stat.label} {...stat} />
              ))}
            </dl>

            <div className="flex items-start gap-4 bg-paper-dark border border-ink/10 rounded-sm px-4 py-4">
              <button
                type="button"
                className="cyberrobo-chat-trigger"
                onClick={onOpenChat}
                disabled={!onOpenChat}
                aria-label="Open CyberRobo chat"
                aria-haspopup="dialog"
              >
                <CyberRoboSVG size={72} className="flex-shrink-0" />
                <span>Chat</span>
              </button>
              <div className="flex-1">
                <p
                  className="text-[9px] tracking-[0.2em] uppercase text-muted mb-2"
                  style={{ fontFamily: "'Outfit', sans-serif" }}
                >
                  CyberRobo
                </p>
                <p
                  className="text-sm text-ink/80 leading-6 italic"
                  style={{ fontFamily: "'Outfit', sans-serif" }}
                >
                  {content.cyberRoboDialogue}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-4 pt-1">
              <Button onClick={onStart} size="lg" aria-label={content.startLabel}>
                Start Investigation
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
                  <path
                    d="M3 8h10M9 4l4 4-4 4"
                    stroke="currentColor"
                    strokeWidth="1.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </Button>
              <span className="text-xs text-muted" style={{ fontFamily: "'Outfit', sans-serif" }}>
                {content.startHint}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
