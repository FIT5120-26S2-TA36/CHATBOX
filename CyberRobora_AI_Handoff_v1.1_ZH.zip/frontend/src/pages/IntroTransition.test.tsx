/**
 * @file Regression scope for IntroTransition, including its externally observable contracts and edge cases.
 */
import { readFileSync } from "node:fs";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { GAME_REGION_MAP_LOCATIONS } from "../components/map/mapLocations";
import { INITIAL_MAP_CAMERA } from "../components/map/viewport";
import FirstSignalOverlay from "../components/map/FirstSignalOverlay";
import IntroTransition from "./IntroTransition";
import MapExperience, { getFirstSignalOverlayState } from "./Map";

describe("IntroTransition content contract", () => {
  const markup = renderToStaticMarkup(<IntroTransition onComplete={() => {}} />);
  const experienceMarkup = renderToStaticMarkup(
    <MapExperience introActive onIntroComplete={() => {}} />,
  );
  const signalMarkup = renderToStaticMarkup(
    <FirstSignalOverlay
      state="active"
      stageStyle={{
        width: 1536,
        height: 1024,
        transform: "translate(-50%, -50%) translate3d(0px, 0px, 0) scale(1)",
      }}
    />,
  );
  const transitionCss = readFileSync(new URL("../index.css", import.meta.url), "utf8");

  it("contains the reused narrative and Data District first lead", () => {
    expect(markup).toContain("A Disturbance in Cyberia");
    expect(markup).toContain("Something strange is happening across Cyberia");
    expect(markup).toContain("The first clear signal is coming from Data District.");
  });

  it("keeps the transition semantic and the fog decorative", () => {
    expect(markup.match(/<h1/g)).toHaveLength(1);
    expect(markup.match(/data-fog-layer=/g)).toHaveLength(4);
    expect(markup).toContain('aria-label="Journey into Cyberia"');
    expect(markup).toContain('data-phase="entering"');
  });

  it("positions the first-signal marker from the Data District coordinates", () => {
    const dataDistrict = GAME_REGION_MAP_LOCATIONS["data-district"];

    expect(signalMarkup).toContain(`left:${dataDistrict.x}%`);
    expect(signalMarkup).toContain(`top:${dataDistrict.y}%`);
    expect(signalMarkup).toContain("intro-signal-marker__pin");
  });

  it("uses the persistent live camera as the cinematic transform source", () => {
    expect(experienceMarkup).toContain('data-map-experience="persistent"');
    expect(experienceMarkup).toContain('data-map-image="persistent"');
    expect(experienceMarkup).toContain(
      `scale(${INITIAL_MAP_CAMERA.scale}) translateY(var(--intro-map-y, 0%))`,
    );
    expect(experienceMarkup.match(/data-map-image=/g)).toHaveLength(1);
    expect(markup).not.toContain("cyberia-map.png");
  });

  it("provides Skip Intro as the only cinematic control", () => {
    expect(markup.match(/<button/g)).toHaveLength(1);
    expect(markup).toContain("Skip Intro");
    expect(markup).toContain('aria-label="Skip intro and open the Cyberia map"');
    expect(markup).not.toContain("Open Cyberia Map");
    expect(markup).toContain("min-h-11");
    expect(markup).toContain("bg-paper/75");
    expect(markup).toContain("text-[10px]");
    expect(markup).toContain("sm:bg-paper/90");
    expect(markup).toContain("sm:text-xs");
  });

  it("begins the frame inside the final signal and eases only the initial crop expansion", () => {
    expect(transitionCss).toMatch(
      /data-phase='first-signal'[^\{]*intro-descent__scroll-frame\s*\{[^}]*opacity:\s*0\.28;[^}]*transition-delay:\s*900ms;/s,
    );
    expect(transitionCss).toMatch(
      /data-phase='map-reveal'[^\{]*intro-descent__scroll-frame[\s\S]*?\{[^}]*opacity:\s*1;[^}]*transition-delay:\s*0ms;/,
    );
    expect(transitionCss).toMatch(
      /data-phase='narrative'[^\{]*cyberia-map-stage[^\{]*\{[^}]*cubic-bezier\(0\.32, 0, 0\.18, 1\)/s,
    );
  });

  it("contains overlays only and does not duplicate the map image or frame", () => {
    expect(markup).toContain('data-cinematic-overlay="active"');
    expect(markup).not.toContain("cyberia-map-scroll");
    expect(markup).not.toContain("data-map-image");
    expect(transitionCss).toMatch(
      /data-phase='map-reveal'[^\{]*intro-cinematic-overlay[\s\S]*?\{[^}]*opacity:\s*0;/,
    );
  });

  it("shows First Signal only for its cinematic and live-handoff lifecycle", () => {
    expect(getFirstSignalOverlayState(true, "entering", false, false)).toBeNull();
    expect(getFirstSignalOverlayState(true, "narrative", false, false)).toBeNull();
    expect(getFirstSignalOverlayState(true, "cyberrobo", false, false)).toBeNull();
    expect(getFirstSignalOverlayState(true, "first-signal", false, false)).toBe("active");
    expect(getFirstSignalOverlayState(true, "map-reveal", false, false)).toBe("active");
    expect(getFirstSignalOverlayState(false, "complete", true, false)).toBe("handoff");
    expect(getFirstSignalOverlayState(false, "complete", false, false)).toBeNull();
  });

  it("suppresses the signal for Skip and keeps reduced motion informative", () => {
    expect(getFirstSignalOverlayState(true, "first-signal", true, true)).toBeNull();
    expect(getFirstSignalOverlayState(true, "narrative", false, false, true)).toBe("active");
  });

  it("renders a decorative signal without another map image", () => {
    expect(signalMarkup).toContain('data-first-signal-overlay="active"');
    expect(signalMarkup).toContain('aria-hidden="true"');
    expect(signalMarkup).toContain("First Signal");
    expect(signalMarkup).not.toContain("cyberia-map.png");
    expect(signalMarkup).not.toContain("<img");
    expect(transitionCss).toMatch(
      /data-phase='map-reveal'[^\{]*intro-signal-marker[\s\S]*?\{[^}]*opacity:\s*1;/,
    );
    expect(transitionCss).toMatch(/data-first-signal-overlay='handoff'[^\{]*\{[^}]*opacity:\s*0;/);
  });

  it("does not reintroduce limited-scope promises or later connections", () => {
    expect(markup).not.toContain("4 territories");
    expect(markup).not.toContain("four territories");
    expect(markup).not.toContain("Identity Citadel");
    expect(markup).not.toContain("Social Square");
    expect(markup).not.toContain("Inbox Harbour");
  });
});
