/**
 * Orchestrates the persistent map experience. Completed regions from GameSession derive map,
 * journal, and connection state; selection, panels, intro overlays, and First Signal handoff remain
 * presentation-only. Atlas and Journal provide non-spatial alternatives to map interaction.
 */
import { useCallback, useEffect, useReducer, useRef, useState } from "react";
import { restoreFocusToTrigger } from "../a11y/dialog";
import Button from "../components/Button";
import CyberRoboSVG from "../components/CyberRoboSVG";
import CyberiaMapViewport from "../components/map/CyberiaMapViewport";
import FieldAtlasPanel from "../components/map/FieldAtlasPanel";
import type { FirstSignalOverlayState } from "../components/map/FirstSignalOverlay";
import JournalPanel from "../components/map/JournalPanel";
import MapStatusGlyph, { type LocationDisplayStatus } from "../components/map/MapStatusGlyph";
import usePrefersReducedMotion from "../hooks/usePrefersReducedMotion";
import {
  GAMEPLAY_MAP_LOCATIONS,
  getMapLocation,
  isGameplayMapLocation,
  type GameplayMapLocation,
  type MapLocationId,
} from "../components/map/mapLocations";
import { initialMapUiState, mapUiReducer, type MapPanel } from "../components/map/mapUi";
import { getMapJournalEntries } from "../components/map/mapJournal";
import {
  canEnterMapRegion,
  getMapDisplayStatus,
  isMapConnectionRevealed,
  mapStatusLabels,
  type MapDisplayStatus,
} from "../game/mapState";
import type { RegionId } from "../game/types";
import type { SessionProgress } from "../api/cyberroboraApi";
import { createIntroTransitionState, type IntroPhase } from "../intro/transition";
import IntroTransition from "./IntroTransition";

interface Props {
  onOpenChat?: () => void;
  introActive?: boolean;
  onIntroComplete?: () => void;
  onEnterRegion?: (regionId: RegionId) => void;
  investigatedRegions?: RegionId[];
  initialSelectedLocationId?: MapLocationId | null;
  journalEntries?: SessionProgress["journalEntries"];
}

const regions = GAMEPLAY_MAP_LOCATIONS;
const NOOP = () => {};
const FIRST_SIGNAL_HANDOFF_MS = 400;

/** Provides the public getFirstSignalOverlayState behavior used across the application. */
export function getFirstSignalOverlayState(
  introActive: boolean,
  introPhase: IntroPhase,
  handoffActive: boolean,
  suppressed: boolean,
  reducedMotion = false,
): FirstSignalOverlayState | null {
  if (suppressed) return null;
  if (handoffActive) return introActive ? "active" : "handoff";
  if (introActive && reducedMotion && introPhase === "narrative") return "active";
  if (introActive && (introPhase === "first-signal" || introPhase === "map-reveal"))
    return "active";
  return null;
}

const locationStatusLabels: Record<LocationDisplayStatus, string> = {
  ...mapStatusLabels,
  "beyond-reach": "Beyond reach — world location",
};

function getRegionDialogue(region: GameplayMapLocation, status: MapDisplayStatus): string {
  if (status === "investigated" && region.investigatedDialogue) return region.investigatedDialogue;
  if (status === "new-disturbance" && region.disturbanceDialogue) return region.disturbanceDialogue;
  return region.dialogue;
}

function statusTone(status: LocationDisplayStatus): string {
  if (status === "available") return "bg-teal-soft border-teal text-teal";
  if (status === "investigated") return "bg-paper-darker border-ink/20 text-muted";
  if (status === "new-disturbance") return "bg-ochre-soft border-ochre/50 text-ochre";
  return "bg-locked-soft border-locked text-locked";
}

function lockedExplanation(regionId: RegionId, status: MapDisplayStatus): string {
  if (regionId === "identity-citadel")
    return "A faint disturbance is visible at the Verification Gate, but no route is open yet.";
  if (status === "faint-disturbance")
    return "A faint signal is visible, but this location cannot be entered yet.";
  return "This location is not currently accessible.";
}

/** Renders the MapExperience experience/component and coordinates its user-facing callbacks. */
export default function MapExperience({
  onOpenChat,
  introActive = false,
  onIntroComplete,
  onEnterRegion,
  investigatedRegions = [],
  initialSelectedLocationId = null,
  journalEntries = {},
}: Props) {
  const reducedMotion = usePrefersReducedMotion();
  const [introPhase, setIntroPhase] = useState<IntroPhase>(() =>
    introActive ? createIntroTransitionState(reducedMotion).phase : "complete",
  );
  const [signalHandoffActive, setSignalHandoffActive] = useState(false);
  const [signalSuppressed, setSignalSuppressed] = useState(false);
  const introSkippedRef = useRef(false);
  const [ui, dispatchUi] = useReducer(mapUiReducer, {
    ...initialMapUiState,
    selectedId: initialSelectedLocationId,
  });
  const [hoveredId, setHoveredId] = useState<MapLocationId | null>(null);
  const [chromeReady, setChromeReady] = useState(false);
  const atlasButtonRef = useRef<HTMLButtonElement>(null);
  const journalButtonRef = useRef<HTMLButtonElement>(null);
  const inspectorReturnFocusRef = useRef<HTMLElement | null>(null);

  useEffect(() => {
    if (introActive) {
      setChromeReady(false);
      return;
    }

    setIntroPhase("complete");
    const frame = requestAnimationFrame(() => setChromeReady(true));
    return () => cancelAnimationFrame(frame);
  }, [introActive]);

  useEffect(() => {
    if (introActive && introPhase === "map-reveal") setChromeReady(true);
  }, [introActive, introPhase]);

  useEffect(() => {
    if (introActive || !signalHandoffActive) return;
    const timer = window.setTimeout(() => setSignalHandoffActive(false), FIRST_SIGNAL_HANDOFF_MS);
    return () => window.clearTimeout(timer);
  }, [introActive, signalHandoffActive]);

  const handleIntroSkip = useCallback(() => {
    introSkippedRef.current = true;
    setSignalSuppressed(true);
    setSignalHandoffActive(false);
  }, []);

  const handleIntroComplete = useCallback(() => {
    if (!introSkippedRef.current) setSignalHandoffActive(true);
    const complete = onIntroComplete ?? NOOP;
    complete();
  }, [onIntroComplete]);

  const dataDistrictDone = investigatedRegions.includes("data-district");
  const citadelDone = investigatedRegions.includes("identity-citadel");
  const connectionRevealed = isMapConnectionRevealed(investigatedRegions);
  const displayStatuses = Object.fromEntries(
    regions.map((region) => [region.id, getMapDisplayStatus(region.id, investigatedRegions)]),
  ) as Record<RegionId, MapDisplayStatus>;

  const journalItems = getMapJournalEntries(investigatedRegions, journalEntries);

  const defaultDialogue = connectionRevealed
    ? "Those two disturbances were connected. A future signal is reaching Inbox Harbour."
    : dataDistrictDone
      ? "A new signal is registering at the Identity Citadel."
      : "Something strange is happening across Cyberia. Begin in the Data District.";

  const selectedLocation = getMapLocation(ui.selectedId);
  const selectedGameplayLocation =
    selectedLocation && isGameplayMapLocation(selectedLocation) ? selectedLocation : null;
  const selectedStatus: LocationDisplayStatus | null = selectedLocation
    ? selectedGameplayLocation
      ? displayStatuses[selectedGameplayLocation.id]
      : "beyond-reach"
    : null;
  const selectedDialogue = selectedLocation
    ? selectedGameplayLocation
      ? getRegionDialogue(selectedGameplayLocation, displayStatuses[selectedGameplayLocation.id])
      : selectedLocation.dialogue
    : null;
  const firstSignalState = getFirstSignalOverlayState(
    introActive,
    introPhase,
    signalHandoffActive,
    signalSuppressed,
    reducedMotion,
  );

  function panelTrigger(panel: Exclude<MapPanel, null>) {
    return panel === "atlas" ? atlasButtonRef.current : journalButtonRef.current;
  }

  function closePanel() {
    const trigger = ui.openPanel ? panelTrigger(ui.openPanel) : null;
    dispatchUi({ type: "CLOSE_PANEL" });
    // Wait for the modal to unmount before restoring focus to the map control that opened it.
    requestAnimationFrame(() => restoreFocusToTrigger(trigger));
  }

  function selectAtlasRegion(regionId: RegionId) {
    inspectorReturnFocusRef.current = atlasButtonRef.current;
    dispatchUi({ type: "SELECT_ATLAS_REGION", regionId });
    requestAnimationFrame(() => restoreFocusToTrigger(atlasButtonRef.current));
  }

  function selectMapLocation(locationId: MapLocationId, trigger: HTMLButtonElement) {
    inspectorReturnFocusRef.current = ui.selectedId === locationId ? null : trigger;
    dispatchUi({ type: "TOGGLE_MAP_LOCATION", locationId });
  }

  function closeLocationInspector() {
    const trigger = inspectorReturnFocusRef.current;
    inspectorReturnFocusRef.current = null;
    dispatchUi({ type: "CLEAR_SELECTION" });
    requestAnimationFrame(() => restoreFocusToTrigger(trigger));
  }

  return (
    <div
      className="map-experience intro-descent relative isolate h-dvh min-h-[30rem] overflow-hidden bg-paper text-ink"
      data-map-experience="persistent"
      data-map-reveal={chromeReady ? "ready" : "initial"}
      data-intro-active={introActive ? "true" : "false"}
      data-phase={introPhase}
      data-reduced-motion={reducedMotion ? "true" : "false"}
    >
      <CyberiaMapViewport
        interactive={!introActive}
        firstSignalState={firstSignalState}
        reducedMotion={reducedMotion}
        selectedId={ui.selectedId}
        hoveredId={hoveredId}
        onLocationSelect={selectMapLocation}
        onLocationHover={setHoveredId}
        displayStatuses={displayStatuses}
        connectionRevealed={connectionRevealed}
      />

      <div
        className="map-title-scroll map-reveal-title map-screen__chrome absolute left-3 top-3 z-40 px-4 py-2 text-center sm:left-5 sm:top-5 sm:px-5"
        aria-hidden={introActive}
      >
        <h1
          className="font-display text-lg font-bold leading-none text-ink sm:text-xl"
          style={{ fontFamily: "'Caveat', cursive" }}
        >
          Cyberia
        </h1>
        <p className="mt-0.5 text-[7px] uppercase tracking-[0.2em] text-muted sm:text-[8px]">
          Field Operations Map
        </p>
      </div>

      <div
        className="map-reveal-tools map-screen__chrome absolute right-3 top-3 z-40 flex items-center gap-1.5 sm:right-5 sm:top-5"
        aria-hidden={introActive}
      >
        <button
          ref={atlasButtonRef}
          type="button"
          disabled={introActive}
          tabIndex={introActive ? -1 : undefined}
          onClick={() => dispatchUi({ type: "OPEN_PANEL", panel: "atlas" })}
          className="map-tool-tab inline-flex min-h-11 items-center rounded-sm px-2 text-[11px] font-medium text-muted hover:bg-paper-dark hover:text-ink sm:px-3 sm:text-xs"
          aria-haspopup="dialog"
          aria-expanded={ui.openPanel === "atlas"}
          aria-label="Open Field Atlas"
        >
          Atlas
        </button>
        <button
          ref={journalButtonRef}
          type="button"
          disabled={introActive}
          tabIndex={introActive ? -1 : undefined}
          onClick={() => dispatchUi({ type: "OPEN_PANEL", panel: "journal" })}
          className="map-tool-tab relative inline-flex min-h-11 items-center rounded-sm px-2 text-[11px] font-medium text-muted hover:bg-paper-dark hover:text-ink sm:px-3 sm:text-xs"
          aria-haspopup="dialog"
          aria-expanded={ui.openPanel === "journal"}
          aria-label="Open investigation journal"
        >
          Journal
          {(dataDistrictDone || citadelDone) && (
            <span
              className="ml-1.5 h-1.5 w-1.5 rounded-full bg-ochre"
              aria-label="New journal entries"
            />
          )}
        </button>
      </div>

      {selectedLocation && selectedStatus && selectedDialogue ? (
        <section
          className="map-screen__chrome absolute bottom-3 left-3 right-3 z-40 flex max-h-[52dvh] flex-col overflow-y-auto rounded-sm border border-ink/20 bg-paper/94 p-3 shadow-xl backdrop-blur-[3px] sm:bottom-4 sm:left-auto sm:right-4 sm:w-[23rem] sm:p-4"
          aria-labelledby="selected-location-heading"
        >
          <p className="sr-only" aria-live="polite">
            Selected {selectedLocation.name}. {locationStatusLabels[selectedStatus]}
          </p>
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <p className="text-[9px] uppercase tracking-[0.2em] text-muted">Location Inspector</p>
              <h2
                id="selected-location-heading"
                className="font-display text-2xl font-bold leading-tight text-ink"
                style={{ fontFamily: "'Caveat', cursive" }}
              >
                {selectedLocation.name}
              </h2>
              <p className="text-xs text-muted">{selectedLocation.subtitle}</p>
            </div>
            <button
              type="button"
              onClick={closeLocationInspector}
              className="flex h-11 w-11 flex-shrink-0 items-center justify-center rounded-sm text-muted hover:bg-paper-dark hover:text-ink"
              aria-label="Close location inspector"
            >
              <span aria-hidden="true">×</span>
            </button>
          </div>

          <div
            className={`mt-3 inline-flex items-center gap-2 rounded-sm border px-2.5 py-1.5 text-[11px] font-medium ${statusTone(selectedStatus)}`}
          >
            <MapStatusGlyph status={selectedStatus} />
            {locationStatusLabels[selectedStatus]}
          </div>

          {selectedGameplayLocation && (
            <p className="mt-3 text-[10px] font-semibold uppercase tracking-[0.15em] text-coral">
              {selectedGameplayLocation.category}
            </p>
          )}
          <p className="mt-1 text-xs leading-5 text-ink/75">{selectedLocation.description}</p>

          <div className="mt-3 flex items-start gap-2 border-t border-ink/10 pt-3">
            <button
              type="button"
              className="cyberrobo-chat-trigger"
              onClick={onOpenChat}
              disabled={!onOpenChat || introActive || ui.openPanel !== null}
              aria-label="Open CyberRobo chat"
              aria-haspopup="dialog"
            >
              <CyberRoboSVG size={38} className="h-auto w-9 flex-shrink-0" />
              <span>Chat</span>
            </button>
            <p
              className="text-[11px] italic leading-4 text-ink/75"
              aria-label={`CyberRobo says: ${selectedDialogue}`}
            >
              “{selectedDialogue}”
            </p>
          </div>

          {selectedGameplayLocation ? (
            <div className="sticky bottom-0 mt-3 bg-paper/95 pt-2">
              {canEnterMapRegion(selectedGameplayLocation.id, investigatedRegions) ? (
                <Button
                  variant={selectedStatus === "investigated" ? "outline" : "primary"}
                  size="sm"
                  className="w-full justify-center"
                  aria-label={
                    selectedStatus === "investigated"
                      ? `Revisit ${selectedGameplayLocation.name}`
                      : `Enter ${selectedGameplayLocation.name} and begin investigation`
                  }
                  onClick={() => onEnterRegion?.(selectedGameplayLocation.id)}
                >
                  {selectedStatus === "investigated"
                    ? "Review Original Case"
                    : selectedStatus === "new-disturbance"
                      ? "Investigate Disturbance"
                      : "Enter Region"}
                </Button>
              ) : (
                <div className="rounded-sm border border-locked/25 bg-locked-soft/75 px-3 py-2 text-[10px] leading-4 text-locked">
                  <p className="flex items-center gap-2 font-semibold">
                    <MapStatusGlyph status="locked" /> Location locked
                  </p>
                  <p className="mt-1">
                    {lockedExplanation(
                      selectedGameplayLocation.id,
                      displayStatuses[selectedGameplayLocation.id],
                    )}
                  </p>
                </div>
              )}
            </div>
          ) : (
            <div className="mt-3 rounded-sm border border-ink/15 bg-paper-dark/70 px-3 py-2 text-[10px] leading-4 text-muted">
              This place lies beyond the current investigation route.
            </div>
          )}
        </section>
      ) : (
        <div
          className="cyberrobo-map-guide cyberrobo-map-guide--safe map-reveal-guide pointer-events-none map-screen__chrome absolute bottom-3 right-3 z-30 flex flex-col items-end sm:bottom-5 sm:right-5"
          data-cyberrobo-placement="bottom-right-stacked"
        >
          <div className="cyberrobo-map-guide__speech max-w-[8rem] px-3 py-2 sm:max-w-[11rem]">
            <p
              className="text-[10px] italic leading-4 text-ink/80 sm:text-[11px]"
              aria-label={`CyberRobo says: ${defaultDialogue}`}
            >
              “{defaultDialogue}”
            </p>
          </div>
          <button
            type="button"
            className="cyberrobo-chat-trigger"
            onClick={onOpenChat}
            disabled={!onOpenChat || introActive || ui.openPanel !== null}
            aria-label="Open CyberRobo chat"
            aria-haspopup="dialog"
          >
            <CyberRoboSVG size={58} className="h-auto w-12 flex-shrink-0 sm:w-14" />
            <span>Chat</span>
          </button>
        </div>
      )}

      {ui.openPanel === "atlas" && (
        <FieldAtlasPanel
          regions={regions}
          displayStatuses={displayStatuses}
          selectedId={ui.selectedId}
          dataDistrictDone={dataDistrictDone}
          connectionRevealed={connectionRevealed}
          onSelectRegion={selectAtlasRegion}
          onClose={closePanel}
        />
      )}

      {ui.openPanel === "journal" && <JournalPanel entries={journalItems} onClose={closePanel} />}

      {introActive && (
        <IntroTransition
          reducedMotion={reducedMotion}
          onPhaseChange={setIntroPhase}
          onSkip={handleIntroSkip}
          onComplete={handleIntroComplete}
        />
      )}
    </div>
  );
}
