/** @vitest-environment jsdom */

import { act, fireEvent, render, screen, within } from "@testing-library/react";
import { useState } from "react";
import { describe, expect, it, vi } from "vitest";
import { identityCitadelClues } from "../content/identityCitadel";
import type { CorvaEvidenceId } from "../game/types";
import CorvaDecision from "./CorvaDecision";
import CorvaInvestigation from "./CorvaInvestigation";
import "../test/dom";

function renderCorva(isContextualised: boolean, initialEvidence: CorvaEvidenceId[] = []) {
  const onAddEvidence = vi.fn();
  const onDecide = vi.fn();

  function ControlledCorvaInvestigation() {
    const [evidence, setEvidence] = useState<CorvaEvidenceId[]>(initialEvidence);
    function addEvidence(evidenceId: CorvaEvidenceId) {
      onAddEvidence(evidenceId);
      setEvidence((current) => (current.includes(evidenceId) ? current : [...current, evidenceId]));
    }
    return (
      <CorvaInvestigation
        evidence={evidence}
        onAddEvidence={addEvidence}
        onBack={vi.fn()}
        onDecide={onDecide}
        isContextualised={isContextualised}
      />
    );
  }

  const view = render(<ControlledCorvaInvestigation />);
  return { ...view, onAddEvidence, onDecide };
}

describe("Corva investigation interactions", () => {
  it("shows the generic message without personal-context evidence", () => {
    renderCorva(false);

    expect(screen.getByText(/Parcel details unavailable/)).toBeInstanceOf(HTMLElement);
    expect(
      screen.queryByRole("button", { name: "Inspect personal details in this message" }),
    ).toBeNull();
  });

  it("shows and marks the contextual personal-details evidence without duplication", () => {
    const { onAddEvidence } = renderCorva(true);
    const inspect = screen.getByRole("button", {
      name: "Inspect personal details in this message",
    });

    fireEvent.click(inspect);
    fireEvent.click(inspect);

    expect(onAddEvidence).toHaveBeenCalledTimes(1);
    expect(onAddEvidence).toHaveBeenCalledWith("personal-context");
    expect(screen.getByLabelText("Personal details inspected")).toBeInstanceOf(HTMLElement);
    expect(
      within(screen.getByRole("list", { name: "Collected evidence" })).getAllByRole("listitem"),
    ).toHaveLength(1);
  });

  it("allows current progression after marking Corva evidence", () => {
    const { onDecide } = renderCorva(false);
    fireEvent.click(screen.getByRole("button", { name: "Inspect sender address" }));

    fireEvent.click(screen.getByRole("button", { name: "Proceed to make your decision" }));

    expect(onDecide).toHaveBeenCalledOnce();
    expect(screen.getByLabelText("Sender address inspected")).toBeInstanceOf(HTMLElement);
  });

  it("keeps investigation and decision totals aligned with each Corva variant", () => {
    const genericEvidence = identityCitadelClues
      .filter(({ variant }) => variant !== "contextualised")
      .map(({ id }) => id);
    const contextualEvidence = identityCitadelClues.map(({ id }) => id);

    const genericInvestigation = renderCorva(false, genericEvidence);
    expect(screen.getByText("of 5")).toBeInstanceOf(HTMLElement);
    genericInvestigation.unmount();

    const genericDecision = render(
      <CorvaDecision
        evidence={contextualEvidence}
        onConfirm={vi.fn()}
        onBack={vi.fn()}
        isContextualised={false}
      />,
    );
    expect(screen.getByText("5 of 5 items")).toBeInstanceOf(HTMLElement);
    expect(screen.queryByText(/NB-40318/)).toBeNull();
    genericDecision.unmount();

    const contextualInvestigation = renderCorva(true, contextualEvidence);
    expect(screen.getByText("of 6")).toBeInstanceOf(HTMLElement);
    contextualInvestigation.unmount();

    render(
      <CorvaDecision
        evidence={contextualEvidence}
        onConfirm={vi.fn()}
        onBack={vi.fn()}
        isContextualised
      />,
    );
    expect(screen.getByText("6 of 6 items")).toBeInstanceOf(HTMLElement);
    expect(screen.queryByText(/up to 6/i)).toBeNull();
  });

  it("resets Corva feedback expiry and clears pending work on unmount", () => {
    vi.useFakeTimers();
    const { unmount } = renderCorva(false);
    fireEvent.click(screen.getByRole("button", { name: "Inspect sender address" }));
    act(() => vi.advanceTimersByTime(500));
    fireEvent.click(screen.getByRole("button", { name: "Inspect the redelivery fee" }));
    const latestItem = screen.getByText(identityCitadelClues[2].explanation).closest("li");

    act(() => vi.advanceTimersByTime(1_000));
    expect(latestItem?.className).toContain("border-indigo/40");
    act(() => vi.advanceTimersByTime(500));
    expect(latestItem?.className).not.toContain("border-indigo/40");

    fireEvent.click(screen.getByRole("button", { name: "Inspect the 48-hour deadline" }));
    expect(vi.getTimerCount()).toBe(1);
    unmount();
    expect(vi.getTimerCount()).toBe(0);
  });
});
