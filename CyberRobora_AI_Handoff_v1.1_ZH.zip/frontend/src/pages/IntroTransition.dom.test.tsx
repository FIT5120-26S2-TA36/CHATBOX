/** @vitest-environment jsdom */

import { act, fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { introPhaseDurations, reducedMotionIntroDuration } from "../intro/transition";
import IntroTransition from "./IntroTransition";
import "../test/dom";

describe("Intro transition DOM behaviour", () => {
  it("skips the intro and reports completion exactly once", () => {
    vi.useFakeTimers();
    const onComplete = vi.fn();
    const onSkip = vi.fn();
    render(<IntroTransition onComplete={onComplete} onSkip={onSkip} reducedMotion={false} />);

    fireEvent.click(screen.getByRole("button", { name: "Skip intro and open the Cyberia map" }));
    act(() => vi.runAllTimers());

    expect(onSkip).toHaveBeenCalledOnce();
    expect(onComplete).toHaveBeenCalledOnce();
  });

  it("completes the normal cinematic once after every phase", () => {
    vi.useFakeTimers();
    const onComplete = vi.fn();
    render(<IntroTransition onComplete={onComplete} reducedMotion={false} />);

    Object.values(introPhaseDurations).forEach((duration) => {
      act(() => vi.advanceTimersByTime(duration));
    });
    act(() => vi.advanceTimersByTime(10_000));

    expect(onComplete).toHaveBeenCalledOnce();
  });

  it("uses the reduced-motion completion duration", () => {
    vi.useFakeTimers();
    const onComplete = vi.fn();
    render(<IntroTransition onComplete={onComplete} reducedMotion />);

    act(() => vi.advanceTimersByTime(reducedMotionIntroDuration - 1));
    expect(onComplete).not.toHaveBeenCalled();
    act(() => vi.advanceTimersByTime(1));

    expect(onComplete).toHaveBeenCalledOnce();
  });

  it("does not report completion after unmounting before the active timer finishes", () => {
    vi.useFakeTimers();
    const onComplete = vi.fn();
    const { unmount } = render(<IntroTransition onComplete={onComplete} reducedMotion={false} />);

    unmount();
    act(() => vi.runAllTimers());

    expect(onComplete).not.toHaveBeenCalled();
  });

  it("switches a mounted cinematic to the reduced path and completes once", () => {
    vi.useFakeTimers();
    let listener: ((event: MediaQueryListEvent) => void) | null = null;
    const query = {
      matches: false,
      media: "(prefers-reduced-motion: reduce)",
      onchange: null,
      addEventListener: vi.fn((_type: string, nextListener: EventListener) => {
        listener = nextListener as (event: MediaQueryListEvent) => void;
      }),
      removeEventListener: vi.fn(),
      addListener: vi.fn(),
      removeListener: vi.fn(),
      dispatchEvent: vi.fn(),
    } as MediaQueryList;
    vi.stubGlobal(
      "matchMedia",
      vi.fn(() => query),
    );
    const onComplete = vi.fn();
    const { container } = render(<IntroTransition onComplete={onComplete} />);

    act(() => listener?.({ matches: true } as MediaQueryListEvent));
    expect(container.firstElementChild?.getAttribute("data-reduced-motion")).toBe("true");

    act(() => vi.advanceTimersByTime(reducedMotionIntroDuration));
    act(() => vi.runAllTimers());
    expect(onComplete).toHaveBeenCalledOnce();
  });
});
