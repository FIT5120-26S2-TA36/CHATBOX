/** @vitest-environment jsdom */

import { render, screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import MapExperience from "./Map";
import "../test/dom";

describe("Map Journal dialog", () => {
  it("owns one motion-preference subscription across the map and nested intro", () => {
    const addEventListener = vi.fn();
    const query = {
      matches: false,
      media: "(prefers-reduced-motion: reduce)",
      onchange: null,
      addEventListener,
      removeEventListener: vi.fn(),
      addListener: vi.fn(),
      removeListener: vi.fn(),
      dispatchEvent: vi.fn(),
    } as MediaQueryList;
    vi.stubGlobal(
      "matchMedia",
      vi.fn(() => query),
    );

    render(<MapExperience introActive />);

    expect(addEventListener).toHaveBeenCalledOnce();
  });

  it("traps keyboard focus, closes on Escape, and restores focus to its trigger", async () => {
    const user = userEvent.setup();
    render(<MapExperience />);
    const trigger = screen.getByRole("button", { name: "Open investigation journal" });

    await user.click(trigger);
    const dialog = screen.getByRole("dialog", { name: "Investigation Journal" });
    const close = screen.getByRole("button", { name: "Close panel" });
    expect(dialog).toBeInstanceOf(HTMLElement);
    expect(document.activeElement).toBe(close);

    await user.tab();
    expect(document.activeElement).toBe(close);
    await user.tab({ shift: true });
    expect(document.activeElement).toBe(close);

    await user.keyboard("{Escape}");
    await waitFor(() => expect(screen.queryByRole("dialog")).toBeNull());
    await waitFor(() => expect(document.activeElement).toBe(trigger));
  });

  it.each([
    ["Identity Citadel", /Identity Citadel.*Locked — not yet accessible/],
    ["Social Square", /Social Square.*Locked — not yet accessible/],
  ])(
    "restores Field Atlas focus after closing the locked %s Inspector",
    async (locationName, atlasEntryName) => {
      const user = userEvent.setup();
      render(<MapExperience />);
      const trigger = screen.getByRole("button", { name: "Open Field Atlas" });

      await user.click(trigger);
      const dialog = screen.getByRole("dialog", { name: "Cyberia locations" });
      await user.click(within(dialog).getByRole("button", { name: atlasEntryName }));

      expect(screen.getByRole("heading", { name: locationName })).toBeInstanceOf(HTMLElement);
      await user.click(screen.getByRole("button", { name: "Close location inspector" }));

      await waitFor(() => expect(document.activeElement).toBe(trigger));
    },
  );

  it("restores Field Atlas focus when the panel closes directly", async () => {
    const user = userEvent.setup();
    render(<MapExperience investigatedRegions={["data-district"]} />);
    const trigger = screen.getByRole("button", { name: "Open Field Atlas" });

    await user.click(trigger);
    const dialog = screen.getByRole("dialog", { name: "Cyberia locations" });
    expect(
      within(dialog).getByText("New signal: Identity Citadel is now available."),
    ).toBeInstanceOf(HTMLElement);
    await user.click(within(dialog).getByRole("button", { name: "Close panel" }));

    await waitFor(() => expect(screen.queryByRole("dialog")).toBeNull());
    await waitFor(() => expect(document.activeElement).toBe(trigger));
  });

  it("restores a direct map-label origin after closing its Inspector", async () => {
    const user = userEvent.setup();
    render(<MapExperience />);
    const trigger = screen.getByRole("button", {
      name: "The Laglands — Beyond reach — world location",
    });

    await user.click(trigger);
    expect(screen.getByRole("heading", { name: "The Laglands" })).toBeInstanceOf(HTMLElement);
    await user.click(screen.getByRole("button", { name: "Close location inspector" }));

    await waitFor(() => expect(document.activeElement).toBe(trigger));
  });

  it("renders a generic final Journal entry without claiming personal details appeared", async () => {
    const user = userEvent.setup();
    render(
      <MapExperience
        investigatedRegions={["data-district", "identity-citadel"]}
        journalEntries={{
          "data-district": "Data District complete.",
          "identity-citadel":
            "Verification used convincing branding, urgency, and independent checks.",
        }}
      />,
    );

    await user.click(screen.getByRole("button", { name: "Open investigation journal" }));
    const dialog = screen.getByRole("dialog", { name: "Investigation Journal" });
    expect(within(dialog).getByText(/convincing branding, urgency/i)).toBeInstanceOf(HTMLElement);
    expect(within(dialog).queryByText(/personal details/i)).toBeNull();
  });

  it("retains cautious contextual language in the contextual final Journal entry", async () => {
    const user = userEvent.setup();
    render(
      <MapExperience
        investigatedRegions={["data-district", "identity-citadel"]}
        journalEntries={{
          "data-district": "Data District complete.",
          "identity-citadel":
            "The message included personal details, but no direct provenance was established.",
        }}
      />,
    );

    await user.click(screen.getByRole("button", { name: "Open investigation journal" }));
    const dialog = screen.getByRole("dialog", { name: "Investigation Journal" });
    expect(within(dialog).getByText(/included personal details/i)).toBeInstanceOf(HTMLElement);
    expect(within(dialog).getByText(/no direct provenance/i)).toBeInstanceOf(HTMLElement);
  });
});
