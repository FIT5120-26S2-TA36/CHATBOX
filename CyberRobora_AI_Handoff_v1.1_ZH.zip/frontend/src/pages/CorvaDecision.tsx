/**
 * @file CorvaDecision routed experience, responsible for composing its content, state callbacks, and accessible UI.
 */
import DecisionScreen, {
  type PresentedDecisionOption,
} from "../components/gameplay/DecisionScreen";
import {
  getIdentityCitadelClues,
  getIdentityCitadelDecisionContent,
  identityCitadelDecisionContent,
} from "../content/identityCitadel";
import type { CorvaDecision as CorvaDecisionId, CorvaEvidenceId } from "../game/types";

interface Props {
  evidence: CorvaEvidenceId[];
  onConfirm: (choice: CorvaDecisionId) => void;
  onBack: () => void;
  isContextualised: boolean;
  submitting?: boolean;
  submissionError?: string | null;
}
function PayIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <rect x="2" y="5" width="16" height="11" rx="2" stroke="currentColor" strokeWidth="1.4" />
      <path d="M2 9h16" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
      <path d="M5 13h4" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
    </svg>
  );
}
function LinkIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <path
        d="M8 12l-2 2a3 3 0 000-4.25l2-2"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinecap="round"
      />
      <path
        d="M12 8l2-2a3 3 0 010 4.25L12 12"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinecap="round"
      />
      <path d="M8.5 11.5l3-3" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
    </svg>
  );
}
function AppIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <rect x="4" y="2" width="12" height="16" rx="2" stroke="currentColor" strokeWidth="1.4" />
      <path d="M7 6h6M7 9h6M7 12h4" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
      <circle cx="10" cy="15.5" r="1" fill="currentColor" />
    </svg>
  );
}
function DeleteIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <path
        d="M4 6h12M8 6V4h4v2M7 6v9a1 1 0 001 1h4a1 1 0 001-1V6"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path d="M9 10v4M11 10v4" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
    </svg>
  );
}
const icons: Record<CorvaDecisionId, React.ReactNode> = {
  "pay-fee": <PayIcon />,
  "open-link": <LinkIcon />,
  "open-app": <AppIcon />,
  "delete-report": <DeleteIcon />,
};
const choices: PresentedDecisionOption<CorvaDecisionId>[] =
  identityCitadelDecisionContent.choices.map((choice) => ({ ...choice, icon: icons[choice.id] }));
/** Renders the CorvaDecision experience/component and coordinates its user-facing callbacks. */
export default function CorvaDecision({
  evidence,
  onConfirm,
  onBack,
  isContextualised,
  submitting,
  submissionError,
}: Props) {
  const activeEvidenceIds = new Set(getIdentityCitadelClues(isContextualised).map(({ id }) => id));
  const activeEvidence = evidence.filter((evidenceId) => activeEvidenceIds.has(evidenceId));

  return (
    <DecisionScreen
      content={getIdentityCitadelDecisionContent(isContextualised)}
      choices={choices}
      markedEvidenceIds={activeEvidence}
      accent="indigo"
      onConfirm={onConfirm}
      onBack={onBack}
      submitting={submitting}
      submissionError={submissionError}
    />
  );
}
