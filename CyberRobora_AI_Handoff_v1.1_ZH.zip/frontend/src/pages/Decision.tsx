/**
 * @file Decision routed experience, responsible for composing its content, state callbacks, and accessible UI.
 */
import DecisionScreen, {
  type PresentedDecisionOption,
} from "../components/gameplay/DecisionScreen";
import { dataDistrictDecisionContent } from "../content/dataDistrict";
import type { DataDistrictDecision, DataDistrictEvidenceId } from "../game/types";

interface Props {
  evidence: DataDistrictEvidenceId[];
  onConfirm: (choice: DataDistrictDecision) => void;
  onBack: () => void;
  submitting?: boolean;
  submissionError?: string | null;
}
function AllowIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <circle cx="10" cy="10" r="8" stroke="currentColor" strokeWidth="1.4" />
      <path
        d="M6.5 10l2.5 2.5 4.5-4.5"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
function LaterIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <circle cx="10" cy="10" r="8" stroke="currentColor" strokeWidth="1.4" />
      <path
        d="M10 6.5v4l2.5 2.5"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
function CustomIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <path
        d="M3 6.5h14M3 10h7M3 13.5h14"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinecap="round"
      />
      <circle
        cx="13.5"
        cy="10"
        r="2.5"
        fill="currentColor"
        fillOpacity="0.1"
        stroke="currentColor"
        strokeWidth="1.2"
      />
    </svg>
  );
}
function WebIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <circle cx="10" cy="10" r="8" stroke="currentColor" strokeWidth="1.4" />
      <path
        d="M10 2c-1.8 2.8-2.8 5.2-2.8 8s1 5.2 2.8 8M10 2c1.8 2.8 2.8 5.2 2.8 8s-1 5.2-2.8 8"
        stroke="currentColor"
        strokeWidth="1.2"
        strokeLinecap="round"
      />
      <path d="M2 10h16" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  );
}
const icons: Record<DataDistrictDecision, React.ReactNode> = {
  "allow-all": <AllowIcon />,
  "allow-later": <LaterIcon />,
  customise: <CustomIcon />,
  "use-website": <WebIcon />,
};
const choices: PresentedDecisionOption<DataDistrictDecision>[] =
  dataDistrictDecisionContent.choices.map((choice) => ({ ...choice, icon: icons[choice.id] }));
/** Renders the Decision experience/component and coordinates its user-facing callbacks. */
export default function Decision({
  evidence,
  onConfirm,
  onBack,
  submitting,
  submissionError,
}: Props) {
  return (
    <DecisionScreen
      content={dataDistrictDecisionContent}
      choices={choices}
      markedEvidenceIds={evidence}
      accent="teal"
      onConfirm={onConfirm}
      onBack={onBack}
      submitting={submitting}
      submissionError={submissionError}
    />
  );
}
