/**
 * @file Landing routed experience, responsible for composing its content, state callbacks, and accessible UI.
 */
import cyberiaMap from "../assets/world/cyberia-map.png";
import Button from "../components/Button";
import CyberRoboSVG from "../components/CyberRoboSVG";

interface Props {
  onStart: () => void;
  onHowItWorks: () => void;
  onAboutCyberRobora: () => void;
}

function RouteIcon() {
  return (
    <svg
      viewBox="0 0 72 72"
      fill="none"
      aria-hidden="true"
      className="h-14 w-14 flex-shrink-0 text-teal"
    >
      <path
        d="M17 15c0 8-7 13-7 13S3 23 3 15a7 7 0 1 1 14 0Z"
        stroke="currentColor"
        strokeWidth="1.6"
      />
      <circle cx="10" cy="15" r="2.5" fill="currentColor" />
      <path
        d="M11 29c5 7 15 5 20 10 6 6-2 13 5 18 6 4 15-1 20-8"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeDasharray="4 5"
        strokeLinecap="round"
      />
      <path
        d="M69 42c0 8-7 13-7 13s-7-5-7-13a7 7 0 1 1 14 0Z"
        stroke="currentColor"
        strokeWidth="1.6"
      />
      <circle cx="62" cy="42" r="2.5" fill="currentColor" />
    </svg>
  );
}

function CompassIcon() {
  return (
    <svg
      viewBox="0 0 72 72"
      fill="none"
      aria-hidden="true"
      className="h-14 w-14 flex-shrink-0 text-ochre"
    >
      <circle cx="36" cy="36" r="25" stroke="currentColor" strokeWidth="1.4" />
      <circle cx="36" cy="36" r="4" stroke="currentColor" strokeWidth="1.4" />
      <path
        d="m36 5 5 26 26 5-26 5-5 26-5-26-26-5 26-5 5-26Z"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinejoin="round"
      />
      <path d="m36 17 3 16-3 3-3-3 3-16Z" fill="currentColor" fillOpacity="0.16" />
    </svg>
  );
}

/** Renders the Landing experience/component and coordinates its user-facing callbacks. */
export default function Landing({ onStart, onHowItWorks, onAboutCyberRobora }: Props) {
  return (
    <div id="landing-home" className="min-h-dvh overflow-x-hidden bg-paper text-ink">
      <header className="relative z-20 border-b border-ink/15 bg-paper/95">
        <div className="mx-auto flex max-w-[1536px] flex-wrap items-center justify-between gap-x-6 gap-y-2 px-4 py-2.5 sm:px-8 lg:px-12">
          <div className="flex items-center gap-3" aria-label="CyberRobora team">
            <CyberRoboSVG size={28} className="flex-shrink-0" />
            <p className="text-sm font-semibold tracking-[0.14em] text-ink sm:text-base">
              CYBERROBORA
            </p>
          </div>

          <nav
            aria-label="Home page"
            className="flex w-full items-center gap-3 text-sm sm:w-auto sm:gap-5"
          >
            <button
              type="button"
              className="inline-flex items-center text-muted transition-colors hover:text-teal"
              onClick={onHowItWorks}
            >
              How It Works
            </button>
            <button
              type="button"
              className="inline-flex items-center text-muted transition-colors hover:text-teal"
              onClick={onAboutCyberRobora}
            >
              About CyberRobora
            </button>
          </nav>
        </div>
      </header>

      <section
        className="relative isolate flex min-h-[clamp(34rem,68vh,46rem)] items-center justify-center overflow-hidden border-b border-ink/15 px-4 py-12 sm:px-8 sm:py-16"
        aria-label="The Quest of Cyberia introduction"
      >
        <img
          src={cyberiaMap}
          alt=""
          aria-hidden="true"
          className="absolute inset-0 -z-20 h-full w-full object-cover object-center"
        />
        <div className="absolute inset-0 -z-10 bg-paper/25" aria-hidden="true" />

        <div className="relative w-full max-w-3xl text-center">
          <div
            className="absolute -inset-x-8 -inset-y-10 -z-10 sm:-inset-x-20 sm:-inset-y-14"
            style={{
              background:
                "radial-gradient(ellipse at center, rgba(245,239,227,0.98) 0%, rgba(245,239,227,0.88) 48%, rgba(245,239,227,0) 76%)",
            }}
            aria-hidden="true"
          />

          <p className="mb-4 text-[10px] font-semibold uppercase tracking-[0.3em] text-ink/75 sm:text-xs">
            A Cybersecurity Field Investigation
          </p>
          <h1
            className="font-display text-[clamp(3.6rem,9vw,7.5rem)] font-bold uppercase leading-[0.77] text-ink"
            style={{ fontFamily: "'Caveat', cursive" }}
          >
            <span className="block text-[0.58em] tracking-[0.04em]">The Quest of</span>
            <span className="mt-3 block text-teal">Cyberia</span>
          </h1>

          <div
            className="mx-auto my-5 flex max-w-xs items-center gap-3 text-ink/50"
            aria-hidden="true"
          >
            <span className="h-px flex-1 bg-current" />
            <span className="text-lg">✦</span>
            <span className="h-px flex-1 bg-current" />
          </div>

          <p className="mx-auto max-w-xl text-base leading-7 text-muted sm:text-lg">
            Explore Cyberia. Investigate digital disturbances.
            <span className="block italic text-teal-deep">See how your choices connect.</span>
          </p>

          <div className="mt-7 flex justify-center">
            <Button
              type="button"
              onClick={onStart}
              size="lg"
              className="min-w-[min(100%,18rem)] justify-center bg-teal uppercase tracking-[0.08em] hover:bg-teal-deep hover:border-teal-deep"
              aria-label="Start The Quest of Cyberia adventure"
            >
              Start Adventure
              <span aria-hidden="true">✦</span>
            </Button>
          </div>

          <div className="h-8 sm:h-10" aria-hidden="true" />
        </div>
      </section>

      <section className="border-b border-ink/15 bg-paper-dark/75" aria-label="Adventure overview">
        <div className="mx-auto grid max-w-7xl grid-cols-1 px-5 sm:grid-cols-2 sm:px-8 lg:grid-cols-3 lg:px-12">
          <article className="flex items-center gap-5 border-b border-ink/15 py-7 sm:col-span-2 lg:col-span-1 lg:border-b-0 lg:border-r lg:pr-8">
            <CyberRoboSVG size={54} className="flex-shrink-0" />
            <div>
              <h2 className="mb-1.5 text-xs font-semibold uppercase tracking-[0.12em] text-ink">
                Your Companion
              </h2>
              <p className="text-sm leading-6 text-muted">
                CyberRobo helps you make sense of the signals and discoveries you uncover.
              </p>
            </div>
          </article>

          <article className="flex items-center gap-5 border-b border-ink/15 py-7 sm:border-b-0 sm:border-r sm:pr-8 lg:pl-8">
            <RouteIcon />
            <div>
              <h2 className="mb-1.5 text-xs font-semibold uppercase tracking-[0.12em] text-ink">
                How It Works
              </h2>
              <p className="text-sm leading-6 text-muted">
                Explore locations, inspect evidence, and make choices that shape Cyberia.
              </p>
            </div>
          </article>

          <article className="flex items-center gap-5 py-7 sm:pl-8 lg:pl-8">
            <CompassIcon />
            <div>
              <h2 className="mb-1.5 text-xs font-semibold uppercase tracking-[0.12em] text-ink">
                Your Impact
              </h2>
              <p className="text-sm leading-6 text-muted">
                Your decisions change what happens next.
              </p>
            </div>
          </article>
        </div>
      </section>

      <footer className="border-t border-ink/10 bg-paper px-5 py-4 text-center text-xs tracking-wide text-muted sm:px-8">
        <p>© CyberRobora</p>
      </footer>
    </div>
  );
}
