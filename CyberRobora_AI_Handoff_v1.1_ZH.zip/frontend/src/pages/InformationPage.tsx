/**
 * @file InformationPage routed experience, responsible for composing its content, state callbacks, and accessible UI.
 */
import PageHeader from "../components/gameplay/PageHeader";

type InformationPageKind = "how-it-works" | "about-cyberrobora";

interface Props {
  kind: InformationPageKind;
  onBack: () => void;
}

const howItWorksSteps = [
  {
    title: "Explore Cyberia",
    detail: "Visit locations where digital disturbances have appeared.",
  },
  {
    title: "Inspect evidence",
    detail: "Look closely at the signals, permissions, and messages you find.",
  },
  {
    title: "Make decisions",
    detail: "Choose an informed response using the evidence you have gathered.",
  },
  {
    title: "See what changes",
    detail: "Discover how your choices shape what happens next in Cyberia.",
  },
];

/** Renders the InformationPage experience/component and coordinates its user-facing callbacks. */
export default function InformationPage({ kind, onBack }: Props) {
  const isHowItWorks = kind === "how-it-works";
  const title = isHowItWorks ? "How It Works" : "About CyberRobora";

  return (
    <div className="min-h-dvh bg-paper">
      <PageHeader
        center="The Quest of Cyberia"
        onBack={onBack}
        backLabel="Landing"
        backAriaLabel="Back to Landing"
      />

      <section className="mx-auto w-full max-w-3xl px-5 py-12 sm:px-8 sm:py-16">
        <p className="mb-3 text-[10px] font-semibold uppercase tracking-[0.28em] text-muted">
          CyberRobora Field Guide
        </p>
        <h1
          className="font-display text-5xl font-bold leading-tight text-ink sm:text-6xl"
          style={{ fontFamily: "'Caveat', cursive" }}
        >
          {title}
        </h1>
        <div className="mt-4 h-px w-16 bg-teal/60" aria-hidden="true" />

        {isHowItWorks ? (
          <ol className="mt-9 grid grid-cols-1 gap-4 sm:grid-cols-2">
            {howItWorksSteps.map((step, index) => (
              <li key={step.title} className="border border-ink/15 bg-paper-dark px-5 py-5">
                <p className="mb-2 text-[10px] font-semibold uppercase tracking-[0.18em] text-teal">
                  Step {index + 1}
                </p>
                <h2 className="text-base font-semibold text-ink">{step.title}</h2>
                <p className="mt-2 text-sm leading-6 text-muted">{step.detail}</p>
              </li>
            ))}
          </ol>
        ) : (
          <div className="mt-9 space-y-5 border-l-2 border-teal/40 pl-5 text-base leading-7 text-muted sm:pl-7">
            <p>
              CyberRobora is the team behind The Quest of Cyberia, an interactive cybersecurity and
              digital-rights adventure set in the fictional world of Cyberia.
            </p>
            <p>
              CyberRobo accompanies players as they investigate digital disturbances and reflect on
              the consequences of their choices.
            </p>
          </div>
        )}
      </section>
    </div>
  );
}
