import { afterEach, describe, expect, it, vi } from "vitest";
import { getChatModels, trimChatHistory, type ChatMessage } from "./chatApi";

afterEach(() => { vi.unstubAllGlobals(); vi.unstubAllEnvs(); vi.resetModules(); });
const config = {
  models: [
    { provider: "qwen", model: "qwen", label: "Qwen", configured: true },
    { provider: "groq", model: "groq", label: "Groq", configured: true },
  ],
  history_limits: { messages: 100, characters: 60000 },
};
function pairs(count: number): ChatMessage[] {
  return Array.from({ length: count }, (_, i) => [
    { role: "user" as const, content: `Question ${i}` },
    { role: "assistant" as const, content: `Reply ${i}` },
  ]).flat();
}
describe("handoff history and deployment contract", () => {
  it("uses the server's 50-pair setting without the old 12-pair clamp", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({ ok: true, json: async () => config }));
    expect((await getChatModels(new AbortController().signal)).history_limits.messages).toBe(100);
    const history = pairs(50);
    expect(trimChatHistory(history, config.history_limits)).toEqual(history);
  });
  it("removes only the oldest full pair at the 51st exchange", () => {
    const history = pairs(51);
    expect(trimChatHistory(history, config.history_limits)).toEqual(history.slice(2));
  });
  it("honours the character budget before the pair limit", () => {
    const history = pairs(3);
    const budget = history.slice(2).reduce((n, m) => n + m.content.length, 0);
    expect(trimChatHistory(history, { messages: 100, characters: budget })).toEqual(history.slice(2));
  });
  it("rejects malformed odd-length capacity from the service", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({ ok: true, json: async () => ({ ...config, history_limits: { messages: 99, characters: 60000 } }) }));
    await expect(getChatModels(new AbortController().signal)).rejects.toThrow("configuration");
  });
  it("sends credentials to the explicitly configured game gateway", async () => {
    vi.stubEnv("VITE_CHAT_API_BASE_URL", "https://api.example.test/api/chat/");
    const fetcher = vi.fn().mockResolvedValue({ ok: true, json: async () => config });
    vi.stubGlobal("fetch", fetcher);
    const api = await import("./chatApi");
    await api.getChatModels(new AbortController().signal);
    expect(fetcher).toHaveBeenCalledWith("https://api.example.test/api/chat/models", expect.objectContaining({ credentials: "include" }));
  });
  it("keeps the direct local proxy path when no gateway is configured", async () => {
    vi.stubEnv("VITE_CHAT_API_BASE_URL", "");
    const fetcher = vi.fn().mockResolvedValue({ ok: true, json: async () => config });
    vi.stubGlobal("fetch", fetcher);
    const api = await import("./chatApi");
    await api.getChatModels(new AbortController().signal);
    expect(fetcher).toHaveBeenCalledWith("/chat-api/models", expect.objectContaining({ credentials: "omit" }));
  });
  it("offers New chat when the gateway no longer owns the continuation", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({ ok: false, status: 409 }));
    const api = await import("./chatApi");
    await expect(api.sendChat({ provider: "qwen", message: "hello", previous_response_id: "old", history: [] }, new AbortController().signal)).rejects.toThrow("start a new chat");
  });
});
