/**
 * @file Typed frontend boundary for fetching regions/scenarios and submitting choices without trusting unknown JSON.
 */
const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL ?? "http://localhost:3000").replace(
  /\/$/,
  "",
);
const REQUEST_TIMEOUT_MS = 8000;

/** Defines the shared Region contract. */
export interface Region {
  id: string;
  name: string;
  description: string;
  topic: string;
  defaultState: string;
  displayOrder: number;
}

/** Defines the shared MissionScenario contract. */
export interface MissionScenario {
  scenario: {
    id: string;
    familyId: string;
    regionId: string;
    title: string;
    text: string;
    senderDisplay: string;
    senderAddress: string;
    linkDisplay: string | null;
    linkTarget: string | null;
  };
  clues: Array<{ id: string; type: string; label: string; text: string }>;
  actions: Array<{ id: string; label: string }>;
}

export interface SessionProgress {
  investigatedRegions: string[];
  dataDistrictExposure: "broad" | "limited" | null;
  worldState: Record<string, unknown>;
  journalEntries: Partial<Record<"data-district" | "identity-citadel", string>>;
}

export type CanonicalJourneyId = "nimbo" | "corva";

export interface ResultContent {
  outcomeLabel: string;
  paragraphs: string[];
  relevantEvidence: Array<{ label: string; detail: string }>;
  saferAction: string;
  cyberRoboReflection?: string;
  sourceReference?: {
    heading: string;
    text: string;
    source: string;
    url: string;
  };
}

export interface CommittedJourneyResult {
  version: 1;
  journeyId: CanonicalJourneyId;
  selectedAction: { id: string; label: string };
  status: "safer" | "riskier";
  content: ResultContent;
  revelation?: {
    contextualised: boolean;
    heading: string;
    paragraphs: string[];
    connector: string;
    reflection: string;
    priorDecisionLabel: string | null;
    limitedExposure?: string;
  };
  progress: SessionProgress;
}

/** Defines the shared ChoiceOutcome contract. */
export interface ChoiceOutcome {
  safe: boolean;
  outcome: string;
  explanation: string;
  realWorldTip: string;
  progress: SessionProgress;
}

/** Represents the public ApiClientError error/service contract. */
/** Safe frontend-facing API failure; deliberately omits server and transport details. */
export class ApiClientError extends Error {}

/** Narrows unknown decoded JSON before any property is trusted. */
function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null;
}

/**
 * Fetches JSON with a bounded timeout and converts all transport/protocol failures
 * into the stable error type consumed by mission retry UI.
 */
async function requestJson(path: string, init?: RequestInit): Promise<unknown> {
  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    const response = await fetch(`${API_BASE_URL}${path}`, {
      ...init,
      credentials: "include",
      signal: controller.signal,
      headers: { "Content-Type": "application/json", ...init?.headers },
    });
    let data: unknown;
    try {
      data = await response.json();
    } catch {
      throw new ApiClientError("The server returned an invalid response");
    }
    if (!response.ok) throw new ApiClientError("Mission data is unavailable");
    return data;
  } catch (error) {
    if (error instanceof ApiClientError) throw error;
    throw new ApiClientError("Mission data is unavailable");
  } finally {
    window.clearTimeout(timeout);
  }
}

/** Requires a string response field or rejects the entire untrusted payload. */
function requireString(value: unknown, field: string): string {
  if (typeof value !== "string") throw new ApiClientError(`Invalid ${field}`);
  return value;
}

function parseSessionProgress(data: unknown): SessionProgress {
  if (!isObject(data) || !Array.isArray(data.investigatedRegions)) {
    throw new ApiClientError("Invalid session response");
  }
  const exposure = data.dataDistrictExposure;
  if (exposure !== null && exposure !== "broad" && exposure !== "limited") {
    throw new ApiClientError("Invalid session exposure");
  }
  const journalEntries = isObject(data.journalEntries) ? data.journalEntries : {};
  const dataDistrictJournal = journalEntries["data-district"];
  const identityCitadelJournal = journalEntries["identity-citadel"];
  if (
    (dataDistrictJournal !== undefined && typeof dataDistrictJournal !== "string") ||
    (identityCitadelJournal !== undefined && typeof identityCitadelJournal !== "string")
  ) {
    throw new ApiClientError("Invalid session journal");
  }
  return {
    investigatedRegions: data.investigatedRegions.map((item) => requireString(item, "region")),
    dataDistrictExposure: exposure,
    worldState: isObject(data.worldState) ? data.worldState : {},
    journalEntries: {
      ...(typeof dataDistrictJournal === "string" ? { "data-district": dataDistrictJournal } : {}),
      ...(typeof identityCitadelJournal === "string"
        ? { "identity-citadel": identityCitadelJournal }
        : {}),
    },
  };
}

function parseStringArray(value: unknown, field: string): string[] {
  if (!Array.isArray(value)) throw new ApiClientError(`Invalid ${field}`);
  return value.map((item) => requireString(item, field));
}

function parseResultContent(value: unknown): ResultContent {
  if (!isObject(value) || !Array.isArray(value.relevantEvidence)) {
    throw new ApiClientError("Invalid result content");
  }
  const source = value.sourceReference;
  const sourceReference =
    source === undefined
      ? undefined
      : isObject(source)
        ? {
            heading: requireString(source.heading, "source heading"),
            text: requireString(source.text, "source text"),
            source: requireString(source.source, "source name"),
            url: requireString(source.url, "source URL"),
          }
        : (() => {
            throw new ApiClientError("Invalid source reference");
          })();
  return {
    outcomeLabel: requireString(value.outcomeLabel, "outcome label"),
    paragraphs: parseStringArray(value.paragraphs, "result paragraph"),
    relevantEvidence: value.relevantEvidence.map((item) => {
      if (!isObject(item)) throw new ApiClientError("Invalid relevant evidence");
      return {
        label: requireString(item.label, "evidence label"),
        detail: requireString(item.detail, "evidence detail"),
      };
    }),
    saferAction: requireString(value.saferAction, "safer action"),
    ...(value.cyberRoboReflection === undefined
      ? {}
      : { cyberRoboReflection: requireString(value.cyberRoboReflection, "reflection") }),
    ...(sourceReference ? { sourceReference } : {}),
  };
}

function parseCommittedJourneyResult(data: unknown): CommittedJourneyResult {
  if (
    !isObject(data) ||
    data.version !== 1 ||
    (data.journeyId !== "nimbo" && data.journeyId !== "corva") ||
    !isObject(data.selectedAction) ||
    (data.status !== "safer" && data.status !== "riskier")
  )
    throw new ApiClientError("Invalid committed result");
  let revelation: CommittedJourneyResult["revelation"];
  if (data.revelation !== undefined) {
    if (!isObject(data.revelation) || typeof data.revelation.contextualised !== "boolean") {
      throw new ApiClientError("Invalid result revelation");
    }
    const priorDecisionLabel = data.revelation.priorDecisionLabel;
    if (priorDecisionLabel !== null && typeof priorDecisionLabel !== "string") {
      throw new ApiClientError("Invalid prior decision label");
    }
    revelation = {
      contextualised: data.revelation.contextualised,
      heading: requireString(data.revelation.heading, "revelation heading"),
      paragraphs: parseStringArray(data.revelation.paragraphs, "revelation paragraph"),
      connector: requireString(data.revelation.connector, "revelation connector"),
      reflection: requireString(data.revelation.reflection, "revelation reflection"),
      priorDecisionLabel,
      ...(data.revelation.limitedExposure === undefined
        ? {}
        : { limitedExposure: requireString(data.revelation.limitedExposure, "limited exposure") }),
    };
  }
  if (data.journeyId === "corva" && !revelation) {
    throw new ApiClientError("Invalid result revelation");
  }
  return {
    version: 1,
    journeyId: data.journeyId,
    selectedAction: {
      id: requireString(data.selectedAction.id, "selected action ID"),
      label: requireString(data.selectedAction.label, "selected action label"),
    },
    status: data.status,
    content: parseResultContent(data.content),
    ...(revelation ? { revelation } : {}),
    progress: parseSessionProgress(data.progress),
  };
}

export async function getSessionProgress(): Promise<SessionProgress> {
  return parseSessionProgress(await requestJson("/api/session"));
}

/** Fetches and validates region metadata from the database-backed API. */
export async function getRegions(): Promise<Region[]> {
  const data = await requestJson("/api/regions");
  if (!Array.isArray(data)) throw new ApiClientError("Invalid regions response");
  return data.map((item) => {
    if (!isObject(item)) throw new ApiClientError("Invalid region response");
    return {
      id: requireString(item.id, "region ID"),
      name: requireString(item.name, "region name"),
      description: requireString(item.description, "region description"),
      topic: requireString(item.topic, "region topic"),
      defaultState: requireString(item.defaultState, "region state"),
      displayOrder: typeof item.displayOrder === "number" ? item.displayOrder : 0,
    };
  });
}

/** Issues a canonical journey to this session without disclosing result data. */
export async function startJourney(journeyId: CanonicalJourneyId): Promise<void> {
  const data = await requestJson(`/api/journeys/${encodeURIComponent(journeyId)}`, {
    method: "PUT",
    body: "{}",
  });
  if (
    !isObject(data) ||
    data.journeyId !== journeyId ||
    (data.status !== "active" && data.status !== "committed")
  ) {
    throw new ApiClientError("Invalid journey response");
  }
}

/** Submits only the selected action ID and validates the committed server result. */
export async function submitJourneyChoice(
  journeyId: CanonicalJourneyId,
  actionId: string,
): Promise<CommittedJourneyResult> {
  const result = parseCommittedJourneyResult(
    await requestJson(`/api/journeys/${encodeURIComponent(journeyId)}/choice`, {
      method: "POST",
      body: JSON.stringify({ actionId }),
    }),
  );
  if (result.journeyId !== journeyId) throw new ApiClientError("Invalid committed result");
  return result;
}

/** Reads an already committed result; this endpoint never advances game progress. */
export async function getCommittedJourneyResult(
  journeyId: CanonicalJourneyId,
): Promise<CommittedJourneyResult> {
  const result = parseCommittedJourneyResult(
    await requestJson(`/api/journeys/${encodeURIComponent(journeyId)}/result`),
  );
  if (result.journeyId !== journeyId) throw new ApiClientError("Invalid committed result");
  return result;
}

/**
 * Fetches an answer-safe scenario projection for a backend region identifier.
 * Correctness and outcomes are intentionally absent until `submitScenarioChoice`.
 */
export async function getNextScenario(regionId: string): Promise<MissionScenario> {
  const data = await requestJson(`/api/scenarios/next?region=${encodeURIComponent(regionId)}`);
  if (
    !isObject(data) ||
    !isObject(data.scenario) ||
    !Array.isArray(data.clues) ||
    !Array.isArray(data.actions)
  ) {
    throw new ApiClientError("Invalid scenario response");
  }
  const scenario = data.scenario;
  return {
    scenario: {
      id: requireString(scenario.id, "scenario ID"),
      familyId: requireString(scenario.familyId, "family ID"),
      regionId: requireString(scenario.regionId, "region ID"),
      title: requireString(scenario.title, "title"),
      text: requireString(scenario.text, "scenario text"),
      senderDisplay: requireString(scenario.senderDisplay, "sender"),
      senderAddress: requireString(scenario.senderAddress, "sender address"),
      linkDisplay:
        scenario.linkDisplay === null ? null : requireString(scenario.linkDisplay, "link label"),
      linkTarget:
        scenario.linkTarget === null ? null : requireString(scenario.linkTarget, "link target"),
    },
    clues: data.clues.map((item) => {
      if (!isObject(item)) throw new ApiClientError("Invalid clue response");
      return {
        id: requireString(item.id, "clue ID"),
        type: requireString(item.type, "clue type"),
        label: requireString(item.label, "clue label"),
        text: requireString(item.text, "clue text"),
      };
    }),
    actions: data.actions.map((item) => {
      if (!isObject(item)) throw new ApiClientError("Invalid action response");
      return {
        id: requireString(item.id, "action ID"),
        label: requireString(item.label, "action label"),
      };
    }),
  };
}

/** Provides the public submitScenarioChoice behavior used across the application. */
/** Submits one action and validates the server-disclosed outcome and learning guidance. */
export async function submitScenarioChoice(
  scenarioId: string,
  actionId: string,
): Promise<ChoiceOutcome> {
  const data = await requestJson(`/api/scenarios/${encodeURIComponent(scenarioId)}/choice`, {
    method: "POST",
    body: JSON.stringify({ actionId }),
  });
  if (!isObject(data) || typeof data.safe !== "boolean")
    throw new ApiClientError("Invalid outcome response");
  return {
    safe: data.safe,
    outcome: requireString(data.outcome, "outcome"),
    explanation: requireString(data.explanation, "explanation"),
    realWorldTip: requireString(data.realWorldTip, "real-world tip"),
    progress: parseSessionProgress(data.progress),
  };
}
