/** Chat uses its own service; the existing game API URL stays unchanged. */
const configuredBase = import.meta.env.VITE_CHAT_API_BASE_URL?.trim();
const CHAT_API_BASE_URL = (configuredBase || "/chat-api").replace(/\/$/, "");
export type ChatProvider = "qwen" | "groq";
export interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}
export interface ChatModel {
  provider: ChatProvider;
  model: string;
  label: string;
  configured: boolean;
}
export interface ChatConfig {
  models: ChatModel[];
  history_limits: { messages: number; characters: number };
}
export interface ChatRequest {
  provider: ChatProvider;
  message: string;
  previous_response_id: string | null;
  history: ChatMessage[];
}
export interface ChatReply {
  reply: string;
  response_id: string | null;
  provider: ChatProvider;
  model: string;
}

async function request(path: string, signal: AbortSignal, body?: ChatRequest) {
  let response: Response;
  try {
    response = await fetch(`${CHAT_API_BASE_URL}/${path}`, {
      method: body ? "POST" : "GET",
      headers: body ? { "Content-Type": "application/json" } : undefined,
      body: body ? JSON.stringify(body) : undefined,
      credentials: configuredBase ? "include" : "omit",
      cache: "no-store",
      signal,
    });
  } catch (error) {
    if (signal.aborted) throw error;
    throw new Error("Cannot reach CyberRobo. Please try again shortly.");
  }
  if (!response.ok) {
    // Do not display raw upstream responses or configuration details to players.
    if (response.status === 409)
      throw new Error("This conversation expired or changed. Please start a new chat.");
    if (response.status === 429 || response.status === 503)
      throw new Error("This model is unavailable or its usage limit was reached. Try again later.");
    if (response.status === 504) throw new Error("The model took too long. Please try again.");
    if ([400, 413, 415, 422].includes(response.status))
      throw new Error(
        "The message could not be accepted. Start a new chat or try a shorter question.",
      );
    throw new Error("CyberRobo could not reply. Please try again shortly.");
  }
  try {
    return await response.json();
  } catch {
    throw new Error("CyberRobo returned an unreadable response. Please try again.");
  }
}

export async function getChatModels(signal: AbortSignal): Promise<ChatConfig> {
  const data = await request("models", signal);
  const models = data?.models;
  const limits = data?.history_limits;
  if (
    !Array.isArray(models) ||
    models.length !== 2 ||
    !models.every(
      (item) =>
        item &&
        ["qwen", "groq"].includes(item.provider) &&
        typeof item.model === "string" &&
        typeof item.label === "string" &&
        typeof item.configured === "boolean",
    ) ||
    new Set(models.map((item) => item.provider)).size !== 2 ||
    !models.some((item) => item.provider === "qwen" && item.configured) ||
    !Number.isInteger(limits?.messages) ||
    limits.messages < 2 ||
    limits.messages > 200 ||
    limits.messages % 2 !== 0 ||
    !Number.isInteger(limits?.characters) ||
    limits.characters < 1 ||
    limits.characters > 100000
  )
    throw new Error("The chat service configuration is unavailable. Please try again.");
  return {
    models,
    history_limits: {
      messages: limits.messages,
      characters: limits.characters,
    },
  };
}

export async function sendChat(body: ChatRequest, signal: AbortSignal): Promise<ChatReply> {
  const data = await request("chat", signal, body);
  if (
    !data ||
    data.provider !== body.provider ||
    typeof data.model !== "string" ||
    typeof data.reply !== "string" ||
    !data.reply.trim() ||
    data.reply.length > 12000 ||
    (body.provider === "qwen" &&
      (typeof data.response_id !== "string" ||
        !data.response_id.trim() ||
        data.response_id.length > 256)) ||
    (body.provider === "groq" && data.response_id !== null)
  )
    throw new Error("CyberRobo returned an incomplete reply. Please try again.");
  return data;
}

/** Drop complete oldest exchanges, never half a user/assistant pair. */
export function trimChatHistory(messages: ChatMessage[], limits: ChatConfig["history_limits"]) {
  const recent = [...messages];
  while (
    recent.length > limits.messages ||
    recent.reduce((count, item) => count + item.content.length, 0) > limits.characters
  ) {
    recent.splice(0, 2);
  }
  return recent;
}
