/** @vitest-environment jsdom */

import { beforeEach, describe, expect, it, vi } from "vitest";
import {
  getCommittedJourneyResult,
  getNextScenario,
  startJourney,
  submitJourneyChoice,
  submitScenarioChoice,
} from "./cyberroboraApi";

const scenario = {
  scenario: {
    id: "v1",
    familyId: "f1",
    regionId: "data_district",
    title: "Mission",
    text: "Message",
    senderDisplay: "Sender",
    senderAddress: "sender@example.test",
    linkDisplay: null,
    linkTarget: null,
  },
  clues: [{ id: "c1", type: "request", label: "Request", text: "Access" }],
  actions: [{ id: "a1", label: "Review" }],
};

describe("cyberrobora API client", () => {
  beforeEach(() => vi.restoreAllMocks());

  it("loads and validates a scenario", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue(new Response(JSON.stringify(scenario), { status: 200 })),
    );
    await expect(getNextScenario("data_district")).resolves.toEqual(scenario);
    expect(fetch).toHaveBeenCalledWith(
      "http://localhost:3000/api/scenarios/next?region=data_district",
      expect.objectContaining({ signal: expect.any(AbortSignal), credentials: "include" }),
    );
  });

  it("rejects malformed scenario data", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue(new Response(JSON.stringify({ scenario: {} }), { status: 200 })),
    );
    await expect(getNextScenario("data_district")).rejects.toThrow(/Invalid scenario/);
  });

  it("does not expose server details for failed requests", async () => {
    vi.stubGlobal(
      "fetch",
      vi
        .fn()
        .mockResolvedValue(
          new Response(JSON.stringify({ error: { message: "SQL secret" } }), { status: 503 }),
        ),
    );
    await expect(getNextScenario("data_district")).rejects.toThrow("Mission data is unavailable");
  });

  it("submits only the action ID and validates the outcome", async () => {
    const outcome = {
      safe: true,
      outcome: "Good",
      explanation: "Why",
      realWorldTip: "Tip",
      progress: {
        investigatedRegions: ["data-district"],
        dataDistrictExposure: "limited",
        worldState: { "data_district.excess_access_granted": false },
        journalEntries: {},
      },
    };
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue(new Response(JSON.stringify(outcome), { status: 200 })),
    );
    await expect(submitScenarioChoice("v1", "a1")).resolves.toEqual(outcome);
    expect(fetch).toHaveBeenCalledWith(
      "http://localhost:3000/api/scenarios/v1/choice",
      expect.objectContaining({
        method: "POST",
        body: JSON.stringify({ actionId: "a1" }),
        credentials: "include",
      }),
    );
  });

  it("starts a canonical journey without accepting or receiving outcome material", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue(
        new Response(
          JSON.stringify({
            journeyId: "nimbo",
            status: "active",
          }),
          { status: 200 },
        ),
      ),
    );
    await expect(startJourney("nimbo")).resolves.toBeUndefined();
    expect(fetch).toHaveBeenCalledWith(
      "http://localhost:3000/api/journeys/nimbo",
      expect.objectContaining({ method: "PUT", body: "{}", credentials: "include" }),
    );
  });

  it("submits only a canonical action ID and validates the committed result DTO", async () => {
    const result = {
      version: 1,
      journeyId: "nimbo",
      selectedAction: { id: "customise", label: "Customise the permissions" },
      status: "safer",
      content: {
        outcomeLabel: "Committed outcome",
        paragraphs: ["What happened"],
        relevantEvidence: [{ label: "Evidence", detail: "Why it mattered" }],
        saferAction: "Practical guidance",
      },
      progress: {
        investigatedRegions: ["data-district"],
        dataDistrictExposure: "limited",
        worldState: {},
        journalEntries: { "data-district": "Completed" },
      },
    };
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue(new Response(JSON.stringify(result), { status: 200 })),
    );

    await expect(submitJourneyChoice("nimbo", "customise")).resolves.toEqual(result);
    expect(fetch).toHaveBeenCalledWith(
      "http://localhost:3000/api/journeys/nimbo/choice",
      expect.objectContaining({
        method: "POST",
        body: JSON.stringify({ actionId: "customise" }),
        credentials: "include",
      }),
    );
  });

  it("validates hydrated committed results instead of trusting JSON", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue(new Response(JSON.stringify({ version: 1 }), { status: 200 })),
    );
    await expect(getCommittedJourneyResult("corva")).rejects.toThrow(/Invalid committed result/);
  });
});
