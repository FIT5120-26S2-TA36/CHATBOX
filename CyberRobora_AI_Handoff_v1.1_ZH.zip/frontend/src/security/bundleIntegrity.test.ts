/** @file Proves the production bundle gate rejects injected server-owned result copy. */
import { execFileSync } from "node:child_process";
import { mkdtempSync, mkdirSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { describe, expect, it } from "vitest";

describe("bundle integrity gate", () => {
  it("fails when forbidden server-owned content is injected into production JavaScript", () => {
    const fixture = mkdtempSync(path.join(tmpdir(), "cyberrobora-bundle-"));
    const source = path.join(fixture, "content");
    const dist = path.join(fixture, "dist");
    mkdirSync(source);
    mkdirSync(dist);
    writeFileSync(path.join(source, "safe.ts"), "export const briefing = 'pre-choice';\n");
    writeFileSync(path.join(dist, "app.js"), "console.log('Fee paid. Link opened.');\n");

    expect(() =>
      execFileSync(
        process.execPath,
        ["scripts/check-bundle-integrity.mjs", "--source", source, "--dist", dist],
        { cwd: process.cwd(), stdio: "pipe" },
      ),
    ).toThrow();
  });
});
