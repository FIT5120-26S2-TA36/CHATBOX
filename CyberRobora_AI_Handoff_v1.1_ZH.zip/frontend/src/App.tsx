/**
 * Coordinates canonical URLs with gameplay state. Route location stays in React Router, while the
 * reducer owns progress and normalizes externally supplied initial state exactly once.
 * MapExperience is mounted only for its persistent map/cinematic presentation, so returning to the
 * map after gameplay does not restart the intro.
 */
import { useCallback, useEffect, useReducer, useRef, useState } from "react";
import { Navigate, Route, Routes, useLocation, useNavigate } from "react-router-dom";
import {
  getCommittedJourneyResult,
  getSessionProgress,
  startJourney,
  submitJourneyChoice,
  type CanonicalJourneyId,
  type CommittedJourneyResult,
  type SessionProgress,
} from "./api/cyberroboraApi";
import { orientPageAfterTransition } from "./a11y/page";
import ExperienceHost from "./components/ExperienceHost";
import CyberRoboChat from "./components/CyberRoboChat";
import CyberRoboSVG from "./components/CyberRoboSVG";
import {
  gameSessionReducer,
  initialGameSession,
  isCorvaContextualised,
  normalizeGameSession,
  type GameSessionInput,
} from "./game/session";
import type {
  CorvaDecision as CorvaDecisionId,
  CorvaEvidenceId,
  DataDistrictDecision,
  DataDistrictEvidenceId,
  DataDistrictExposure,
  RegionId,
} from "./game/types";
import { canAccessRoute, getRouteRecoveryPath } from "./navigation/routeGuards";
import {
  isCinematicPresentation,
  isExperienceVisible,
  type ExperiencePresentation,
} from "./navigation/experiencePresentation";
import { getRouteId, ROUTES } from "./navigation/routes";
import { getRouteAnnouncement, getRouteTitle } from "./navigation/titles";
import CitadelOverview from "./pages/CitadelOverview";
import Consequence from "./pages/Consequence";
import CorvaConsequence from "./pages/CorvaConsequence";
import CorvaDecision from "./pages/CorvaDecision";
import CorvaInvestigation from "./pages/CorvaInvestigation";
import Decision from "./pages/Decision";
import InformationPage from "./pages/InformationPage";
import Investigation from "./pages/Investigation";
import Landing from "./pages/Landing";
import MapExperience from "./pages/Map";
import NotFound from "./pages/NotFound";
import RegionOverview from "./pages/RegionOverview";
import ApiMission from "./pages/ApiMission";

interface Props {
  initialSession?: GameSessionInput;
}

/** Renders the App experience/component and coordinates its user-facing callbacks. */
function asRegionIds(values: string[]): RegionId[] {
  return values.filter(
    (value): value is RegionId =>
      value === "data-district" ||
      value === "identity-citadel" ||
      value === "social-square" ||
      value === "inbox-harbour",
  );
}

function asExposure(value: SessionProgress["dataDistrictExposure"]): DataDistrictExposure | null {
  return value === "broad" || value === "limited" ? value : null;
}

function asDataDistrictDecision(value: string): DataDistrictDecision | null {
  return value === "allow-all" ||
    value === "allow-later" ||
    value === "customise" ||
    value === "use-website"
    ? value
    : null;
}

function asCorvaDecision(value: string): CorvaDecisionId | null {
  return value === "pay-fee" ||
    value === "open-link" ||
    value === "open-app" ||
    value === "delete-report"
    ? value
    : null;
}

function SessionHydrationStatus() {
  return (
    <div
      role="status"
      aria-live="polite"
      aria-label="Loading field operations"
      className="flex min-h-dvh items-center justify-center bg-paper px-5 text-center text-sm text-muted"
    >
      Loading field operations…
    </div>
  );
}

export default function App({ initialSession = initialGameSession }: Props) {
  const [chatOpen, setChatOpen] = useState(false);
  const chatTrigger = useRef<HTMLElement | null>(null);
  const openChat = useCallback(() => {
    chatTrigger.current =
      document.activeElement instanceof HTMLElement ? document.activeElement : null;
    setChatOpen(true);
  }, []);
  const closeChat = useCallback(() => {
    setChatOpen(false);
    requestAnimationFrame(() => {
      const target = chatTrigger.current?.isConnected
        ? chatTrigger.current
        : (document.getElementById("cyberrobo-floating-trigger") ??
          document.getElementById("main-content"));
      target?.focus({ preventScroll: true });
    });
  }, []);
  const [session, dispatch] = useReducer(gameSessionReducer, initialSession, normalizeGameSession);
  const [sessionReady, setSessionReady] = useState(false);
  const [journalEntries, setJournalEntries] = useState<SessionProgress["journalEntries"]>({});
  const [nimboResult, setNimboResult] = useState<CommittedJourneyResult | null>(null);
  const [corvaResult, setCorvaResult] = useState<CommittedJourneyResult | null>(null);
  const [resultLoadState, setResultLoadState] = useState<
    Record<CanonicalJourneyId, "idle" | "loading" | "ready" | "missing">
  >({
    nimbo: "idle",
    corva: "idle",
  });
  const [submittingJourney, setSubmittingJourney] = useState<CanonicalJourneyId | null>(null);
  const [submissionError, setSubmissionError] = useState<Record<CanonicalJourneyId, string | null>>(
    { nimbo: null, corva: null },
  );
  const [experiencePresentation, setExperiencePresentation] =
    useState<ExperiencePresentation>("inactive");
  const location = useLocation();
  const navigate = useNavigate();
  const routeId = getRouteId(location.pathname);
  // Until the first /api/session settles, do not treat empty local progress as authoritative.
  const outcomeJourney: CanonicalJourneyId | null =
    routeId === "nimboOutcome" ? "nimbo" : routeId === "corvaOutcome" ? "corva" : null;
  const outcomeResult =
    outcomeJourney === "nimbo" ? nimboResult : outcomeJourney === "corva" ? corvaResult : null;
  const resultMissing = outcomeJourney ? resultLoadState[outcomeJourney] === "missing" : false;
  const outcomeHydrationPending = Boolean(outcomeJourney && !outcomeResult && !resultMissing);
  const recoveryPath = sessionReady
    ? resultMissing
      ? ROUTES.map
      : outcomeJourney
        ? null
        : getRouteRecoveryPath(routeId, session)
    : null;
  const holdingForSession =
    (!sessionReady && !canAccessRoute(routeId, session)) || outcomeHydrationPending;
  const cinematicActive = isCinematicPresentation(experiencePresentation);
  const showMapExperience = isExperienceVisible(experiencePresentation, routeId);
  const corvaIsContextualised = isCorvaContextualised(session);

  useEffect(() => {
    let cancelled = false;
    void getSessionProgress()
      .then((progress) => {
        if (cancelled) return;
        dispatch({
          type: "HYDRATE_FROM_SERVER",
          investigatedRegions: asRegionIds(progress.investigatedRegions),
          dataDistrictExposure: asExposure(progress.dataDistrictExposure),
        });
        setJournalEntries(progress.journalEntries);
      })
      .catch(() => {
        // Offline/API failure keeps the local empty session; gameplay can still start.
      })
      .finally(() => {
        if (!cancelled) setSessionReady(true);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!sessionReady) return;
    const journey =
      routeId === "nimbo" || routeId === "nimboDecision"
        ? "nimbo"
        : routeId === "corva" || routeId === "corvaDecision"
          ? "corva"
          : null;
    if (journey) void startJourney(journey).catch(() => undefined);
  }, [routeId, sessionReady]);

  useEffect(() => {
    if (
      !sessionReady ||
      !outcomeJourney ||
      outcomeResult ||
      resultMissing ||
      resultLoadState[outcomeJourney] === "loading"
    )
      return;
    setResultLoadState((current) => ({ ...current, [outcomeJourney]: "loading" }));
    void getCommittedJourneyResult(outcomeJourney)
      .then((result) => {
        if (outcomeJourney === "nimbo") {
          const decision = asDataDistrictDecision(result.selectedAction.id);
          if (!decision) throw new Error("Invalid committed action");
          setNimboResult(result);
          dispatch({ type: "START_DATA_DISTRICT_INVESTIGATION" });
          dispatch({ type: "CONFIRM_DATA_DISTRICT_DECISION", decision });
        } else {
          const decision = asCorvaDecision(result.selectedAction.id);
          if (!decision) throw new Error("Invalid committed action");
          setCorvaResult(result);
          dispatch({ type: "START_CORVA_INVESTIGATION" });
          dispatch({ type: "CONFIRM_CORVA_DECISION", decision });
        }
        dispatch({
          type: "HYDRATE_FROM_SERVER",
          investigatedRegions: asRegionIds(result.progress.investigatedRegions),
          dataDistrictExposure: asExposure(result.progress.dataDistrictExposure),
        });
        setJournalEntries(result.progress.journalEntries);
        setResultLoadState((current) => ({ ...current, [outcomeJourney]: "ready" }));
      })
      .catch(() => {
        setResultLoadState((current) => ({ ...current, [outcomeJourney]: "missing" }));
      });
  }, [outcomeJourney, outcomeResult, resultLoadState, resultMissing, sessionReady]);

  useEffect(() => {
    document.title = getRouteTitle(routeId, cinematicActive);
  }, [cinematicActive, routeId]);

  useEffect(() => {
    // The live region announces the new route; resetting scroll avoids also forcing focus away
    // from the control that initiated navigation.
    if (routeId !== "map") orientPageAfterTransition(window);
  }, [location.key, routeId]);

  useEffect(() => {
    if (routeId === "map" && experiencePresentation === "handoff") {
      setExperiencePresentation("inactive");
    }
  }, [experiencePresentation, routeId]);

  function startAdventure() {
    setExperiencePresentation("cinematic");
  }

  function completeIntro() {
    setExperiencePresentation("handoff");
    navigate(ROUTES.map);
  }

  function addDdEvidence(evidenceId: DataDistrictEvidenceId) {
    dispatch({ type: "INSPECT_DATA_DISTRICT_EVIDENCE", evidenceId });
  }

  function startDdInvestigation() {
    dispatch({ type: "START_DATA_DISTRICT_INVESTIGATION" });
    navigate(ROUTES.dataDistrictMission);
  }

  async function handleDdConfirmDecision(decision: DataDistrictDecision) {
    setSubmittingJourney("nimbo");
    setSubmissionError((current) => ({ ...current, nimbo: null }));
    try {
      await startJourney("nimbo");
      const result = await submitJourneyChoice("nimbo", decision);
      setNimboResult(result);
      setJournalEntries(result.progress.journalEntries);
      dispatch({ type: "CONFIRM_DATA_DISTRICT_DECISION", decision });
      dispatch({
        type: "HYDRATE_FROM_SERVER",
        investigatedRegions: asRegionIds(result.progress.investigatedRegions),
        dataDistrictExposure: asExposure(result.progress.dataDistrictExposure),
      });
      setResultLoadState((current) => ({ ...current, nimbo: "ready" }));
      navigate(ROUTES.nimboOutcome);
    } catch {
      setSubmissionError((current) => ({
        ...current,
        nimbo: "Your decision could not be recorded. Please try again.",
      }));
    } finally {
      setSubmittingJourney(null);
    }
  }

  function handleContinueFromDdConsequence() {
    dispatch({ type: "COMPLETE_DATA_DISTRICT" });
    navigate(ROUTES.map);
  }

  function handleContinueFromApiMission(progress: SessionProgress) {
    dispatch({
      type: "HYDRATE_FROM_SERVER",
      investigatedRegions: asRegionIds(progress.investigatedRegions),
      dataDistrictExposure: asExposure(progress.dataDistrictExposure),
    });
    setJournalEntries(progress.journalEntries);
    navigate(ROUTES.map);
  }

  function addCorvaEvidence(evidenceId: CorvaEvidenceId) {
    dispatch({ type: "INSPECT_CORVA_EVIDENCE", evidenceId });
  }

  function startCorvaInvestigation() {
    dispatch({ type: "START_CORVA_INVESTIGATION" });
    navigate(ROUTES.corva);
  }

  async function handleCorvaConfirmDecision(decision: CorvaDecisionId) {
    setSubmittingJourney("corva");
    setSubmissionError((current) => ({ ...current, corva: null }));
    try {
      await startJourney("corva");
      const result = await submitJourneyChoice("corva", decision);
      setCorvaResult(result);
      setJournalEntries(result.progress.journalEntries);
      dispatch({ type: "CONFIRM_CORVA_DECISION", decision });
      dispatch({
        type: "HYDRATE_FROM_SERVER",
        investigatedRegions: asRegionIds(result.progress.investigatedRegions),
        dataDistrictExposure: asExposure(result.progress.dataDistrictExposure),
      });
      setResultLoadState((current) => ({ ...current, corva: "ready" }));
      navigate(ROUTES.corvaOutcome);
    } catch {
      setSubmissionError((current) => ({
        ...current,
        corva: "Your decision could not be recorded. Please try again.",
      }));
    } finally {
      setSubmittingJourney(null);
    }
  }

  function handleContinueFromCorvaConsequence() {
    dispatch({ type: "COMPLETE_CORVA" });
    navigate(ROUTES.map);
  }

  function handleEnterRegion(regionId: RegionId) {
    if (regionId === "data-district") navigate(ROUTES.dataDistrict);
    if (regionId === "identity-citadel") navigate(ROUTES.identityCitadel);
  }

  return (
    <>
      <a href="#main-content" className="skip-link">
        Skip to main content
      </a>
      <p className="sr-only" role="status" aria-live="polite" aria-atomic="true">
        {getRouteAnnouncement(routeId, cinematicActive)}
      </p>
      <main
        id="main-content"
        tabIndex={-1}
        inert={chatOpen}
        className="min-h-full min-w-0 focus:outline-none"
      >
        <ExperienceHost active={showMapExperience}>
          {sessionReady ? (
            <MapExperience
              onOpenChat={openChat}
              introActive={cinematicActive}
              onIntroComplete={completeIntro}
              onEnterRegion={handleEnterRegion}
              investigatedRegions={session.investigatedRegions}
              journalEntries={journalEntries}
            />
          ) : (
            <SessionHydrationStatus />
          )}
        </ExperienceHost>
        {!showMapExperience &&
          (holdingForSession ? (
            <SessionHydrationStatus />
          ) : recoveryPath ? (
            <Navigate to={recoveryPath} replace />
          ) : (
            <Routes>
              <Route
                path={ROUTES.home}
                element={
                  <Landing
                    onStart={startAdventure}
                    onHowItWorks={() => navigate(ROUTES.howItWorks)}
                    onAboutCyberRobora={() => navigate(ROUTES.about)}
                  />
                }
              />
              <Route
                path={ROUTES.howItWorks}
                element={
                  <InformationPage kind="how-it-works" onBack={() => navigate(ROUTES.home)} />
                }
              />
              <Route
                path={ROUTES.about}
                element={
                  <InformationPage kind="about-cyberrobora" onBack={() => navigate(ROUTES.home)} />
                }
              />
              <Route path={ROUTES.map} element={null} />
              <Route
                path={ROUTES.dataDistrict}
                element={
                  <RegionOverview
                    onOpenChat={openChat}
                    onBack={() => navigate(ROUTES.map)}
                    onStart={startDdInvestigation}
                  />
                }
              />
              <Route
                path={ROUTES.dataDistrictMission}
                element={
                  <ApiMission
                    onBack={() => navigate(ROUTES.dataDistrict)}
                    onComplete={handleContinueFromApiMission}
                  />
                }
              />
              <Route
                path={ROUTES.nimbo}
                element={
                  <Investigation
                    evidence={session.dataDistrictEvidence}
                    onAddEvidence={addDdEvidence}
                    onBack={() => navigate(ROUTES.dataDistrict)}
                    onDecide={() => navigate(ROUTES.nimboDecision)}
                  />
                }
              />
              <Route
                path={ROUTES.nimboDecision}
                element={
                  <Decision
                    evidence={session.dataDistrictEvidence}
                    onConfirm={handleDdConfirmDecision}
                    onBack={() => navigate(ROUTES.nimbo)}
                    submitting={submittingJourney === "nimbo"}
                    submissionError={submissionError.nimbo}
                  />
                }
              />
              <Route
                path={ROUTES.nimboOutcome}
                element={
                  nimboResult ? (
                    <Consequence
                      result={nimboResult}
                      onContinue={handleContinueFromDdConsequence}
                    />
                  ) : null
                }
              />
              <Route
                path={ROUTES.identityCitadel}
                element={
                  <CitadelOverview
                    onOpenChat={openChat}
                    onBack={() => navigate(ROUTES.map)}
                    onStart={startCorvaInvestigation}
                  />
                }
              />
              <Route
                path={ROUTES.corva}
                element={
                  <CorvaInvestigation
                    evidence={session.corvaEvidence}
                    onAddEvidence={addCorvaEvidence}
                    onBack={() => navigate(ROUTES.identityCitadel)}
                    onDecide={() => navigate(ROUTES.corvaDecision)}
                    isContextualised={corvaIsContextualised}
                  />
                }
              />
              <Route
                path={ROUTES.corvaDecision}
                element={
                  <CorvaDecision
                    evidence={session.corvaEvidence}
                    onConfirm={handleCorvaConfirmDecision}
                    onBack={() => navigate(ROUTES.corva)}
                    isContextualised={corvaIsContextualised}
                    submitting={submittingJourney === "corva"}
                    submissionError={submissionError.corva}
                  />
                }
              />
              <Route
                path={ROUTES.corvaOutcome}
                element={
                  corvaResult ? (
                    <CorvaConsequence
                      result={corvaResult}
                      onContinue={handleContinueFromCorvaConsequence}
                    />
                  ) : null
                }
              />
              <Route
                path="*"
                element={
                  <NotFound
                    onReturnToCyberia={() => navigate(ROUTES.map)}
                    onReturnHome={() => navigate(ROUTES.home)}
                  />
                }
              />
            </Routes>
          ))}
      </main>
      {!chatOpen &&
        !cinematicActive &&
        sessionReady &&
        !holdingForSession &&
        !recoveryPath &&
        [
          "dataDistrictMission",
          "nimbo",
          "nimboDecision",
          "nimboOutcome",
          "corva",
          "corvaDecision",
          "corvaOutcome",
        ].includes(routeId) && (
          <button
            id="cyberrobo-floating-trigger"
            type="button"
            className="cyberrobo-chat-trigger cyberrobo-chat-launcher"
            aria-label="Open CyberRobo chat"
            aria-haspopup="dialog"
            onClick={openChat}
          >
            <CyberRoboSVG size={32} />
            <span>Chat</span>
          </button>
        )}
      <CyberRoboChat open={chatOpen} onClose={closeChat} />
    </>
  );
}
