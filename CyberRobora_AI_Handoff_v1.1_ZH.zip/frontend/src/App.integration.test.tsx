/** @vitest-environment jsdom */

import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { MemoryRouter, useLocation } from "react-router-dom";
import { beforeEach, describe, expect, it, vi } from "vitest";
import App from "./App";
import { gameSessionReducer, initialGameSession, type GameSessionInput } from "./game/session";
import { ROUTES } from "./navigation/routes";
import "./test/dom";

function RouteProbe() {
  const location = useLocation();
  return <output aria-label="Current route">{location.pathname}</output>;
}

function renderApp(path: string, initialSession: GameSessionInput = initialGameSession) {
  render(
    <MemoryRouter initialEntries={[path]}>
      <App initialSession={initialSession} />
      <RouteProbe />
    </MemoryRouter>,
  );
}

function currentRoute(path: string) {
  expect(screen.getByLabelText("Current route").textContent).toBe(path);
}

function completedDataDistrictSession() {
  let session = gameSessionReducer(initialGameSession, {
    type: "START_DATA_DISTRICT_INVESTIGATION",
  });
  session = gameSessionReducer(session, {
    type: "CONFIRM_DATA_DISTRICT_DECISION",
    decision: "allow-all",
  });
  return gameSessionReducer(session, { type: "COMPLETE_DATA_DISTRICT" });
}

const emptyServerSession = {
  investigatedRegions: [],
  dataDistrictExposure: null,
  worldState: {},
  journalEntries: {},
};

function committedResult(journeyId: "nimbo" | "corva") {
  const corva = journeyId === "corva";
  return {
    version: 1,
    journeyId,
    selectedAction: corva
      ? { id: "delete-report", label: "Delete and report to Scamwatch" }
      : { id: "customise", label: "Customise the permissions" },
    status: "safer",
    content: {
      outcomeLabel: corva ? "Deleted and reported." : "Nimbo result from server",
      paragraphs: ["Server-owned consequence."],
      relevantEvidence: [{ label: "Evidence", detail: "Server-owned explanation." }],
      saferAction: "Server-owned practical guidance.",
      cyberRoboReflection: "Server-owned reflection.",
    },
    ...(corva
      ? {
          revelation: {
            contextualised: true,
            heading: "The message knew your address.",
            paragraphs: ["Connection one.", "Connection two.", "Connection three."],
            connector: "Information can travel",
            reflection: "Verify identity independently.",
            priorDecisionLabel: "Allow everything",
          },
        }
      : {}),
    progress: {
      investigatedRegions: corva ? ["data-district", "identity-citadel"] : ["data-district"],
      dataDistrictExposure: corva ? "broad" : "limited",
      worldState: { "data_district.excess_access_granted": corva },
      journalEntries: {
        "data-district": "Data result recorded.",
        ...(corva ? { "identity-citadel": "Citadel result recorded." } : {}),
      },
    },
  };
}

describe("router and GameSession coordination", () => {
  beforeEach(() => vi.unstubAllGlobals());
  it("shows a retryable player-safe error when mission data is unavailable", async () => {
    vi.stubGlobal("fetch", vi.fn().mockRejectedValue(new Error("database connection secret")));
    renderApp(ROUTES.dataDistrictMission, { dataDistrictInvestigationStarted: true });

    expect(
      await screen.findByRole("heading", { name: "Mission data is temporarily unavailable." }),
    ).toBeInstanceOf(HTMLElement);
    expect(screen.getByRole("button", { name: "Retry mission" })).toBeInstanceOf(HTMLElement);
    expect(screen.queryByText(/database connection secret/)).toBeNull();
  });

  it("starts a backend-loaded Data District mission, submits a choice, and returns to the persistent map", async () => {
    const scenario = {
      scenario: {
        id: "dd_app_permissions_v1",
        familyId: "dd_app_permissions",
        regionId: "data_district",
        title: "Update your app permissions",
        text: "Review this permission request.",
        senderDisplay: "Test Service",
        senderAddress: "support@test.example",
        linkDisplay: null,
        linkTarget: null,
      },
      clues: [
        {
          id: "c1",
          type: "request",
          label: "Requested access",
          text: "The app requests contacts.",
        },
      ],
      actions: [{ id: "a1", label: "Review requested permissions" }],
    };
    const choice = {
      safe: true,
      outcome: "Access was limited.",
      explanation: "The request was broader than necessary.",
      realWorldTip: "Allow only required permissions.",
      progress: {
        investigatedRegions: ["data-district"],
        dataDistrictExposure: "limited",
        worldState: { "data_district.excess_access_granted": false },
        journalEntries: { "data-district": "Completed" },
      },
    };
    vi.stubGlobal(
      "fetch",
      vi.fn(async (input: RequestInfo | URL) => {
        const url = String(input);
        if (url.includes("/api/session")) {
          return new Response(
            JSON.stringify({
              investigatedRegions: [],
              dataDistrictExposure: null,
              worldState: {},
            }),
            { status: 200 },
          );
        }
        if (url.includes("/api/scenarios/next")) {
          return new Response(JSON.stringify(scenario), { status: 200 });
        }
        if (url.includes("/choice")) {
          return new Response(JSON.stringify(choice), { status: 200 });
        }
        return new Response("{}", { status: 404 });
      }),
    );
    renderApp(ROUTES.dataDistrict);

    fireEvent.click(screen.getByRole("button", { name: "Start investigating the Data District" }));
    await waitFor(() => currentRoute(ROUTES.dataDistrictMission));
    expect(
      await screen.findByRole("heading", { name: "Update your app permissions" }),
    ).toBeInstanceOf(HTMLElement);
    expect(screen.getByText("The app requests contacts.")).toBeInstanceOf(HTMLElement);
    fireEvent.click(screen.getByRole("button", { name: "Review requested permissions" }));
    expect(await screen.findByRole("heading", { name: "Safer choice" })).toBeInstanceOf(
      HTMLElement,
    );
    expect(screen.getByText("Allow only required permissions.")).toBeInstanceOf(HTMLElement);

    fireEvent.click(screen.getByRole("button", { name: "Continue to Cyberia" }));
    await waitFor(() => currentRoute(ROUTES.map));
    expect(screen.getByRole("heading", { name: "Cyberia" })).toBeInstanceOf(HTMLElement);
    expect(
      screen.getByRole("button", {
        name: "Identity Citadel — New disturbance detected — available for investigation",
      }),
    ).toBeInstanceOf(HTMLElement);
    expect(
      screen.queryByRole("button", { name: "Skip intro and open the Cyberia map" }),
    ).toBeNull();
  });

  it("starts Identity Citadel from committed world state and confirms the Corva decision", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
        const url = String(input);
        if (url.endsWith("/api/session")) {
          return new Response(
            JSON.stringify({
              ...emptyServerSession,
              investigatedRegions: ["data-district"],
              dataDistrictExposure: "broad",
            }),
            { status: 200 },
          );
        }
        if (url.endsWith("/api/journeys/corva") && init?.method === "PUT") {
          return new Response(JSON.stringify({ journeyId: "corva", status: "active" }), {
            status: 200,
          });
        }
        if (url.endsWith("/api/journeys/corva/choice")) {
          return new Response(JSON.stringify(committedResult("corva")), { status: 200 });
        }
        return new Response("{}", { status: 404 });
      }),
    );
    renderApp(ROUTES.identityCitadel, completedDataDistrictSession());

    fireEvent.click(
      screen.getByRole("button", { name: "Start investigating the Identity Citadel" }),
    );
    await waitFor(() => currentRoute(ROUTES.corva));
    expect(
      screen.getByRole("button", { name: "Inspect personal details in this message" }),
    ).toBeInstanceOf(HTMLElement);
    fireEvent.click(screen.getByRole("button", { name: "Proceed to make your decision" }));
    await waitFor(() => currentRoute(ROUTES.corvaDecision));
    fireEvent.click(screen.getByRole("button", { name: /^Delete and report to Scamwatch:/ }));
    fireEvent.click(
      screen.getByRole("button", { name: "Confirm: Delete and report to Scamwatch" }),
    );
    await waitFor(() => currentRoute(ROUTES.corvaOutcome));

    expect(screen.getByRole("heading", { name: "Deleted and reported." })).toBeInstanceOf(
      HTMLElement,
    );
    expect(screen.getByRole("heading", { name: "The message knew your address." })).toBeInstanceOf(
      HTMLElement,
    );
  });

  it("hydrates a committed result when an outcome route is opened directly", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async (input: RequestInfo | URL) => {
        const url = String(input);
        if (url.endsWith("/api/session")) {
          return new Response(
            JSON.stringify({
              ...emptyServerSession,
              investigatedRegions: ["data-district"],
              dataDistrictExposure: "limited",
            }),
            { status: 200 },
          );
        }
        if (url.endsWith("/api/journeys/nimbo/result")) {
          return new Response(JSON.stringify(committedResult("nimbo")), { status: 200 });
        }
        return new Response("{}", { status: 404 });
      }),
    );

    renderApp(ROUTES.nimboOutcome);
    expect(await screen.findByRole("heading", { name: "Nimbo result from server" })).toBeInstanceOf(
      HTMLElement,
    );
    currentRoute(ROUTES.nimboOutcome);
  });

  it("recovers safely when an outcome deep link has no committed server result", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async (input: RequestInfo | URL) => {
        if (String(input).endsWith("/api/session")) {
          return new Response(JSON.stringify(emptyServerSession), { status: 200 });
        }
        return new Response(JSON.stringify({ error: { code: "RESULT_NOT_FOUND" } }), {
          status: 404,
        });
      }),
    );

    renderApp(ROUTES.nimboOutcome);
    await waitFor(() => currentRoute(ROUTES.map));
    expect(screen.getByRole("heading", { name: "Cyberia" })).toBeInstanceOf(HTMLElement);
  });

  it("waits for session hydration before showing map region status", async () => {
    let resolveSession!: (value: Response) => void;
    const sessionResponse = new Promise<Response>((resolve) => {
      resolveSession = resolve;
    });
    vi.stubGlobal(
      "fetch",
      vi.fn(async (input: RequestInfo | URL) => {
        if (String(input).includes("/api/session")) return sessionResponse;
        return new Response("{}", { status: 404 });
      }),
    );
    renderApp(ROUTES.map);

    expect(screen.getByRole("status", { name: "Loading field operations" }).textContent).toBe(
      "Loading field operations…",
    );
    expect(
      screen.queryByRole("button", { name: /Data District — Available for investigation/ }),
    ).toBeNull();
    expect(
      screen.queryByRole("button", {
        name: /Data District — Investigated — original case available for review/,
      }),
    ).toBeNull();

    resolveSession(
      new Response(
        JSON.stringify({
          investigatedRegions: ["data-district"],
          dataDistrictExposure: "limited",
          worldState: {},
        }),
        { status: 200 },
      ),
    );

    expect(
      await screen.findByRole("button", {
        name: "Data District — Investigated — original case available for review",
      }),
    ).toBeInstanceOf(HTMLElement);
    expect(
      screen.queryByRole("button", { name: /Data District — Available for investigation/ }),
    ).toBeNull();
  });

  it("holds Identity Citadel until hydration instead of unlocking from empty local state", async () => {
    let resolveSession!: (value: Response) => void;
    const sessionResponse = new Promise<Response>((resolve) => {
      resolveSession = resolve;
    });
    vi.stubGlobal(
      "fetch",
      vi.fn(async (input: RequestInfo | URL) => {
        if (String(input).includes("/api/session")) return sessionResponse;
        return new Response("{}", { status: 404 });
      }),
    );
    renderApp(ROUTES.identityCitadel);

    expect(screen.getByRole("status", { name: "Loading field operations" }).textContent).toBe(
      "Loading field operations…",
    );
    currentRoute(ROUTES.identityCitadel);
    expect(
      screen.queryByRole("button", { name: "Start investigating the Identity Citadel" }),
    ).toBeNull();

    resolveSession(
      new Response(
        JSON.stringify({
          investigatedRegions: ["data-district"],
          dataDistrictExposure: "broad",
          worldState: {},
        }),
        { status: 200 },
      ),
    );

    expect(
      await screen.findByRole("button", { name: "Start investigating the Identity Citadel" }),
    ).toBeInstanceOf(HTMLElement);
    currentRoute(ROUTES.identityCitadel);
  });

  it("normalizes contradictory external exposure before selecting the Corva variant", () => {
    renderApp(ROUTES.corva, {
      dataDistrictDecision: "customise",
      dataDistrictExposure: "broad",
      investigatedRegions: ["data-district"],
      corvaInvestigationStarted: true,
    });

    currentRoute(ROUTES.corva);
    expect(screen.getByText(/Parcel details unavailable/)).toBeInstanceOf(HTMLElement);
    expect(
      screen.queryByRole("button", { name: "Inspect personal details in this message" }),
    ).toBeNull();
  });
});
