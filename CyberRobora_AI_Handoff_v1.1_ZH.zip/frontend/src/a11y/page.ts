/**
 * @file page reusable accessibility and focus-management behavior.
 */
interface PageScrollViewport {
  scrollTo(options: ScrollToOptions): void;
}

/**
 * Restores the visual reading origin after route changes without forcing keyboard or assistive-
 * technology focus; route changes are announced separately by App's live region.
 */
export function orientPageAfterTransition(viewport: PageScrollViewport): void {
  viewport.scrollTo({ top: 0, left: 0, behavior: "auto" });
}
