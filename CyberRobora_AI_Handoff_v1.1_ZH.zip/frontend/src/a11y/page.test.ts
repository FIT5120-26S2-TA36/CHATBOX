/**
 * @file Regression scope for page, including its externally observable contracts and edge cases.
 */
import { describe, expect, it } from "vitest";
import {
  cinematicTitle,
  getRouteAnnouncement,
  getRouteTitle,
  routeTitles,
} from "../navigation/titles";
import { orientPageAfterTransition } from "./page";

describe("route accessibility metadata", () => {
  it("provides a meaningful title for every canonical destination", () => {
    expect(Object.keys(routeTitles)).toHaveLength(14);
    for (const title of Object.values(routeTitles)) {
      expect(title).toContain("The Quest of Cyberia");
      expect(title).not.toContain("The Quest of CyberRobora");
    }
  });

  it("provides canonical public-route titles and announcements", () => {
    expect(getRouteTitle("home")).toBe("The Quest of Cyberia");
    expect(getRouteTitle("howItWorks")).toBe("How It Works — The Quest of Cyberia");
    expect(getRouteTitle("about")).toBe("About CyberRobora — The Quest of Cyberia");
    expect(getRouteAnnouncement("about")).toBe(
      "About CyberRobora — The Quest of Cyberia. Page loaded.",
    );
    expect(getRouteTitle("map")).toBe("Cyberia Map — The Quest of Cyberia");
  });

  it("announces the cinematic without treating it as a URL route", () => {
    expect(getRouteTitle("home", true)).toBe(cinematicTitle);
    expect(getRouteAnnouncement("home", true)).toContain("Entering Cyberia");
  });

  it("resets page scroll without moving focus", () => {
    const calls: ScrollToOptions[] = [];
    orientPageAfterTransition({
      scrollTo(options: ScrollToOptions) {
        calls.push(options);
      },
    });

    expect(calls).toEqual([{ top: 0, left: 0, behavior: "auto" }]);
  });
});
