/**
 * @file Regression scope for dialog, including its externally observable contracts and edge cases.
 */
import { describe, expect, it, vi } from "vitest";
import { getFocusWrapTarget, restoreFocusToTrigger } from "./dialog";

describe("dialog focus containment", () => {
  it("wraps forward from the last control to the first", () => {
    expect(getFocusWrapTarget(2, 3, false)).toBe(0);
  });

  it("wraps backward from the first control to the last", () => {
    expect(getFocusWrapTarget(0, 3, true)).toBe(2);
  });

  it("does not interfere with normal tab movement", () => {
    expect(getFocusWrapTarget(1, 3, false)).toBeNull();
  });
});

describe("dialog focus restoration", () => {
  it("returns focus to the Journal trigger instead of an unrelated Back control", () => {
    const journalTrigger = { focus: vi.fn() };
    const backButton = { focus: vi.fn() };

    restoreFocusToTrigger(journalTrigger);

    expect(journalTrigger.focus).toHaveBeenCalledWith({ preventScroll: true });
    expect(backButton.focus).not.toHaveBeenCalled();
  });

  it("does nothing when the trigger is no longer mounted", () => {
    expect(() => restoreFocusToTrigger(null)).not.toThrow();
  });
});
