/** Returns a wrap target only when Tab would otherwise leave a modal's focusable range. */
export function getFocusWrapTarget(
  activeIndex: number,
  itemCount: number,
  shiftKey: boolean,
): number | null {
  if (itemCount <= 0) return null;
  if (shiftKey && activeIndex === 0) return itemCount - 1;
  if (!shiftKey && activeIndex === itemCount - 1) return 0;
  return null;
}

interface FocusTarget {
  focus(options?: FocusOptions): void;
}

/** Provides the public restoreFocusToTrigger behavior used across the application. */
export function restoreFocusToTrigger(trigger: FocusTarget | null): void {
  // preventScroll keeps closing a panel from moving the map beneath the returning focus indicator.
  trigger?.focus({ preventScroll: true });
}
