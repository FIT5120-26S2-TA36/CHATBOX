/** @vitest-environment jsdom */
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { expect, it, vi } from "vitest";
import App from "./App";
import { initialGameSession } from "./game/session";
import "./test/dom";

vi.mock("./api/cyberroboraApi", async (importOriginal) => ({
  ...(await importOriginal<typeof import("./api/cyberroboraApi")>()),
  getSessionProgress: async () => ({
    investigatedRegions: [],
    dataDistrictExposure: null,
    worldState: {},
    journalEntries: {},
  }),
  startJourney: async () => undefined,
}));

it("opens chat from the real map robot, blocks background focus and restores the trigger", async () => {
  const fetchMock = vi.fn().mockResolvedValue(
    new Response(
      JSON.stringify({
        models: [
          { provider: "qwen", model: "qwen3.7-plus", label: "Qwen", configured: true },
          { provider: "groq", model: "openai/gpt-oss-20b", label: "Groq", configured: false },
        ],
        history_limits: { messages: 24, characters: 24000 },
      }),
    ),
  );
  vi.stubGlobal("fetch", fetchMock);
  render(
    <MemoryRouter initialEntries={["/map"]}>
      <App />
    </MemoryRouter>,
  );
  const trigger = await screen.findByRole("button", { name: "Open CyberRobo chat" });
  expect(fetchMock).not.toHaveBeenCalled();
  trigger.focus();
  fireEvent.click(trigger);
  expect(screen.getByRole("dialog", { name: "Chat with CyberRobo" })).toBeInstanceOf(HTMLElement);
  expect(document.getElementById("main-content")!.hasAttribute("inert")).toBe(true);
  await waitFor(() => expect(fetchMock).toHaveBeenCalledOnce());
  fireEvent.click(screen.getByRole("button", { name: "Close chat" }));
  await waitFor(() => expect(document.activeElement).toBe(trigger));
  expect(screen.queryByRole("dialog")).toBeNull();
  expect(document.getElementById("main-content")!.hasAttribute("inert")).toBe(false);
});

it("returns focus to the mission launcher after it remounts", async () => {
  vi.stubGlobal(
    "fetch",
    vi.fn().mockResolvedValue(
      new Response(
        JSON.stringify({
          models: [
            { provider: "qwen", model: "qwen3.7-plus", label: "Qwen", configured: true },
            { provider: "groq", model: "openai/gpt-oss-20b", label: "Groq", configured: false },
          ],
          history_limits: { messages: 24, characters: 24000 },
        }),
      ),
    ),
  );
  render(
    <MemoryRouter initialEntries={["/regions/data-district/nimbo"]}>
      <App initialSession={{ ...initialGameSession, dataDistrictInvestigationStarted: true }} />
    </MemoryRouter>,
  );
  const trigger = await screen.findByRole("button", { name: "Open CyberRobo chat" });
  trigger.focus();
  fireEvent.click(trigger);
  fireEvent.click(screen.getByRole("button", { name: "Close chat" }));
  await waitFor(() =>
    expect(document.activeElement).toBe(
      screen.getByRole("button", { name: "Open CyberRobo chat" }),
    ),
  );
});
