# CyberRobora frontend handoff

Run npm ci then npm run dev for the local experiment. Read ../docs/01_Installation_Report_EN.md and ../docs/03_Engineering_Integration_Guide_EN.md for complete setup. This directory is a runtime snapshot, not a replacement for the official repo's docs, CI or LFS configuration.
