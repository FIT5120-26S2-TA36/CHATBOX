/**
 * @file Vite development/build configuration, including React, Tailwind, the `@`
 * source alias, and the configurable development/preview port.
 */
import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import path from "node:path";
import { defineConfig } from "vite";

export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  server: {
    host: "127.0.0.1",
    port: parseInt(process.env.PORT || "8443"),
    strictPort: true,
    // Local chat experiment: independent from VITE_API_BASE_URL and game cookies.
    proxy: {
      "/chat-api/": {
        target: "http://127.0.0.1:8000",
        rewrite: (url) => url.replace(/^\/chat-api/, ""),
        proxyTimeout: 75000,
      },
    },
  },
  preview: {
    host: "127.0.0.1",
    port: parseInt(process.env.PORT || "8443"),
  },
});
