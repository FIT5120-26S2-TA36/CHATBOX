import { readdir, readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const repositoryRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const argumentsMap = new Map();
for (let index = 2; index < process.argv.length; index += 2) {
  argumentsMap.set(process.argv[index], process.argv[index + 1]);
}
const sourceRoot = path.resolve(argumentsMap.get("--source") ?? path.join(repositoryRoot, "src/content"));
const distRoot = path.resolve(argumentsMap.get("--dist") ?? path.join(repositoryRoot, "dist"));

const forbiddenContentStructure = [
  /\bconsequences\s*:/,
  /\boutcomeLabel\s*:/,
  /\brelevantEvidence\s*:/,
  /\bsaferAction\s*:/,
  /export\s+(?:const|function)\s+\w*(?:Consequence|Revelation|JournalContent)/,
];

// These markers are server-owned editorial copy, not schema/property names that minifiers can alter.
const forbiddenBundleMarkers = [
  "Setup completed without issue. Nimbo launched",
  "Nimbo continues to operate with broad access",
  "Nimbo is installed with adjusted permissions",
  "The website version asked for much less",
  "Fee paid. Link opened.",
  "Link opened. Payment withheld.",
  "The message knew your address.",
  "Verification Gate investigation concluded.",
];

async function filesUnder(directory, extensionPattern) {
  const entries = await readdir(directory, { withFileTypes: true });
  const nested = await Promise.all(entries.map(async (entry) => {
    const target = path.join(directory, entry.name);
    if (entry.isDirectory()) return filesUnder(target, extensionPattern);
    return extensionPattern.test(entry.name) ? [target] : [];
  }));
  return nested.flat();
}

const failures = [];
for (const file of await filesUnder(sourceRoot, /\.(?:ts|tsx)$/)) {
  const source = await readFile(file, "utf8");
  for (const pattern of forbiddenContentStructure) {
    if (pattern.test(source)) failures.push(`${path.relative(repositoryRoot, file)} matches ${pattern}`);
  }
}
for (const file of await filesUnder(distRoot, /\.js$/)) {
  const bundle = await readFile(file, "utf8");
  for (const marker of forbiddenBundleMarkers) {
    if (bundle.includes(marker)) failures.push(`${path.relative(repositoryRoot, file)} contains ${JSON.stringify(marker)}`);
  }
}

if (failures.length) {
  console.error("Bundle integrity check failed:\n" + failures.map((failure) => `- ${failure}`).join("\n"));
  process.exitCode = 1;
} else {
  console.log("Bundle integrity check passed: no server-owned outcome material found.");
}
