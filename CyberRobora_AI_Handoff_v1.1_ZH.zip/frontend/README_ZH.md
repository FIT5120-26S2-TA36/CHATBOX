# CyberRobora 前端交接说明

本地实验先运行 npm ci，再运行 npm run dev。完整设置步骤见 [安装报告](../docs/01_Installation_Report_ZH.md) 和 [工程集成指南](../docs/03_Engineering_Integration_Guide_ZH.md)。本目录是可运行的代码快照，不能用来替换正式仓库中的文档、CI 或 Git LFS 配置。
