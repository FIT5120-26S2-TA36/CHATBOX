/**
 * @file Express application composition, CORS/security middleware, route mounting, and safe error responses.
 */
import cookieParser from "cookie-parser";
import cors from "cors";
import express, { type ErrorRequestHandler } from "express";
import helmet from "helmet";
import type { AppConfig } from "./config/env.js";
import type { Queryable } from "./db/pool.js";
import { ApiError } from "./errors.js";
import { sessionMiddleware } from "./middleware/session.js";
import { healthRouter } from "./routes/health.js";
import { journeysRouter } from "./routes/journeys.js";
import { regionsRouter } from "./routes/regions.js";
import { scenariosRouter } from "./routes/scenarios.js";
import { chatRouter } from "./routes/chat.js";
import { sessionRouter } from "./routes/session.js";
import { ScenarioService } from "./services/scenarioService.js";
import { JourneyService } from "./services/journeyService.js";
import { SessionService } from "./services/sessionService.js";

/**
 * Builds the testable Express application around an injected database interface.
 *
 * The application enforces one configured CORS origin, limits JSON bodies, and
 * converts unexpected failures into generic responses that do not expose internals.
 */
export function createApp(config: AppConfig, db: Queryable) {
  const app = express();
  const sessions = new SessionService(db);
  const service = new ScenarioService(db, config.allowDrafts, sessions);
  const journeys = new JourneyService(db, sessions);
  app.disable("x-powered-by");
  app.use(helmet({ contentSecurityPolicy: false }));
  app.use(cors({
    origin: config.frontendOrigin,
    credentials: true,
  }));
  app.use(cookieParser());
  const chatServiceUrl = process.env.CHAT_SERVICE_URL;
  if (chatServiceUrl) {
    app.use("/api/chat", sessionMiddleware(config, sessions), chatRouter({
      frontendOrigin: config.frontendOrigin,
      serviceUrl: chatServiceUrl,
      serviceKey: process.env.CHAT_SERVICE_KEY ?? "",
    }));
  }
  app.use(express.json({ limit: "32kb" }));
  app.use("/api/health", healthRouter(db));
  app.use("/api/session", sessionMiddleware(config, sessions), sessionRouter(sessions));
  app.use("/api/regions", regionsRouter(service));
  app.use("/api/scenarios", sessionMiddleware(config, sessions), scenariosRouter(service));
  app.use("/api/journeys", sessionMiddleware(config, sessions), journeysRouter(journeys));
  app.use((_request, response) => response.status(404).json({ error: { code: "NOT_FOUND", message: "Route not found" } }));

  const errorHandler: ErrorRequestHandler = (error, _request, response, _next) => {
    if (error instanceof ApiError) {
      response.status(error.status).json({ error: { code: error.code, message: error.message } });
      return;
    }
    if (config.nodeEnv !== "test") console.error("Unhandled request error", error);
    response.status(500).json({ error: { code: "INTERNAL_ERROR", message: "The request could not be completed" } });
  };
  app.use(errorHandler);
  return app;
}
