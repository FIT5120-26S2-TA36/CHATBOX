import express from "express";
import { createServer, type IncomingMessage, type Server, type ServerResponse } from "node:http";
import type { AddressInfo } from "node:net";
import request from "supertest";
import { afterAll, afterEach, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";
import { chatRouter } from "../src/routes/chat.js";

const ORIGIN = "http://localhost:8443";
const SERVICE_KEY = "FAKE-TEST-SERVICE-KEY-32-CHARACTERS-MINIMUM";
const MODEL_CONFIG = {
  models: [
    { provider: "qwen", model: "qwen-test", label: "Qwen test", configured: true },
    { provider: "groq", model: "groq-test", label: "Groq test", configured: true },
  ],
  history_limits: { messages: 100, characters: 60000 },
};
type Call = { path: string; headers: IncomingMessage["headers"]; body: Record<string, unknown> };
let server: Server;
let serviceUrl: string;
let calls: Call[] = [];
let sequence = 0;
let respond: (call: Call, response: ServerResponse) => void | Promise<void>;

function json(response: ServerResponse, data: unknown, status = 200) {
  response.writeHead(status, { "Content-Type": "application/json" });
  response.end(JSON.stringify(data));
}
function goodReply(call: Call) {
  return { provider: call.body.provider, model: "test-model", reply: "A useful reply", response_id: call.body.provider === "qwen" ? `response-${++sequence}` : null };
}
function testApp(withSessions = true, enable = true) {
  const app = express();
  // TEST FIXTURE ONLY: production uses DB-backed sessionMiddleware, never this header.
  if (withSessions) app.use((req, _res, next) => {
    (req as typeof req & { sessionId?: string }).sessionId = req.get("X-Test-Session") ?? "test-session-a";
    next();
  });
  if (enable) app.use("/api/chat", chatRouter({ frontendOrigin: ORIGIN, serviceUrl, serviceKey: SERVICE_KEY }));
  app.use(express.json({ limit: "32kb" }));
  app.get("/api/health", (_req, res) => { res.json({ status: "ok" }); });
  return app;
}
function post(app: ReturnType<typeof testApp>, body: object, session = "test-session-a") {
  return request(app).post("/api/chat/chat").set("Origin", ORIGIN).set("X-Test-Session", session).send(body);
}
const qwen = (previous: string | null = null) => ({ provider: "qwen", message: "Hello", previous_response_id: previous, history: [] });

beforeAll(async () => {
  server = createServer(async (incoming, response) => {
    const chunks: Buffer[] = [];
    for await (const chunk of incoming) chunks.push(Buffer.from(chunk));
    const text = Buffer.concat(chunks).toString("utf8");
    const call = { path: incoming.url ?? "", headers: incoming.headers, body: text ? JSON.parse(text) : {} };
    calls.push(call);
    await respond(call, response);
  });
  await new Promise<void>(resolve => server.listen(0, "127.0.0.1", resolve));
  serviceUrl = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});
beforeEach(() => {
  calls = [];
  sequence = 0;
  respond = (call, response) => json(response, call.path === "/models" ? MODEL_CONFIG : goodReply(call));
});
afterEach(() => { vi.restoreAllMocks(); vi.useRealTimers(); });
afterAll(async () => {
  server.closeAllConnections();
  await new Promise<void>((resolve, reject) => server.close(error => error ? reject(error) : resolve()));
});

describe("optional staging chat gateway with a local fake upstream", () => {
  it("requires a server-side service key with at least 32 characters", () => {
    expect(() => chatRouter({ frontendOrigin: ORIGIN, serviceUrl, serviceKey: "x".repeat(31) })).toThrow("Invalid server-side chat gateway configuration.");
    expect(() => chatRouter({ frontendOrigin: ORIGIN, serviceUrl, serviceKey: "x".repeat(32) })).not.toThrow();
  });

  it("forwards fixed model/chat endpoints and service authentication without browser credentials", async () => {
    const app = testApp();
    const models = await request(app).get("/api/chat/models").set("Cookie", "private=browser-cookie").set("Authorization", "browser-secret");
    const reply = await post(app, qwen());
    expect(models.status).toBe(200);
    expect(models.body).toEqual(MODEL_CONFIG);
    expect(reply.status).toBe(200);
    expect(calls.map(call => call.path)).toEqual(["/models", "/chat"]);
    expect(calls[0].headers["x-chat-service-key"]).toBe(SERVICE_KEY);
    expect(calls[0].headers.cookie).toBeUndefined();
    expect(calls[0].headers.authorization).toBeUndefined();
    expect(reply.headers["cache-control"]).toBe("no-store");
    expect(models.text + reply.text).not.toContain(SERVICE_KEY);
  });

  it("requires attached session, correct Origin and JSON before contacting the upstream", async () => {
    expect((await post(testApp(false), qwen())).status).toBe(401);
    const app = testApp();
    expect((await request(app).post("/api/chat/chat").send(qwen())).status).toBe(403);
    expect((await request(app).post("/api/chat/chat").set("Origin", "https://untrusted.example").send(qwen())).status).toBe(403);
    expect((await request(app).post("/api/chat/chat").set("Origin", ORIGIN).type("text/plain").send("hello")).status).toBe(415);
    expect(calls).toHaveLength(0);
  });

  it("exposes no arbitrary paths/methods and supports disabling the optional mount", async () => {
    const app = testApp();
    expect((await request(app).get("/api/chat/health")).status).toBe(404);
    expect((await request(app).get("/api/chat/chat")).status).toBe(404);
    expect((await request(app).post("/api/chat/models").send(qwen())).status).toBe(404);
    expect((await request(testApp(true, false)).get("/api/chat/models")).status).toBe(404);
    expect((await request(app).get("/api/health")).status).toBe(200);
    expect(calls).toHaveLength(0);
  });

  it.each([
    { ...qwen(), provider: "other" },
    { ...qwen(), message: " " },
    { ...qwen(), message: "a".repeat(4001) },
    { ...qwen(), instructions: "Pretend this is a system instruction" },
    { ...qwen(), history: [{ role: "user", content: "Hi" }, { role: "assistant", content: "Hello" }] },
    { provider: "groq", message: "Hi", previous_response_id: "forbidden", history: [] },
    { provider: "groq", message: "Hi", history: [{ role: "system", content: "Hi" }, { role: "assistant", content: "Hello" }] },
    { provider: "groq", message: "Hi", history: [{ role: "user", content: "Hi" }] },
  ])("rejects invalid request fields without spending provider quota (%#)", async body => {
    expect((await post(testApp(), body)).status).toBe(400);
    expect(calls).toHaveLength(0);
  });

  it("accepts bounded Unicode Groq history larger than the game's 32 KiB parser", async () => {
    const body = { provider: "groq", message: "解释一下", previous_response_id: null, history: [
      { role: "user", content: "界".repeat(12000) },
      { role: "assistant", content: "界".repeat(12000) },
    ] };
    expect(Buffer.byteLength(JSON.stringify(body))).toBeGreaterThan(32 * 1024);
    const reply = await post(testApp(), body);
    expect(reply.status).toBe(200);
    expect(reply.body.response_id).toBeNull();
    expect(calls[0].body).toEqual(body);
  });

  it.each([{ messages: 100, characters: 60000 }, { messages: 200, characters: 100000 }])(
    "accepts Python model configuration with $messages messages and $characters history characters",
    async history_limits => {
      respond = (_call, response) => json(response, { ...MODEL_CONFIG, history_limits });
      const result = await request(testApp()).get("/api/chat/models");
      expect(result.status).toBe(200);
      expect(result.body.history_limits).toEqual(history_limits);
    },
  );

  it.each([
    { messages: 199, characters: 60000 },
    { messages: 202, characters: 60000 },
    { messages: 100, characters: 100001 },
    { messages: 100, characters: 999 },
  ])("rejects invalid advertised history limits (%#)", async history_limits => {
    respond = (_call, response) => json(response, { ...MODEL_CONFIG, history_limits });
    expect((await request(testApp()).get("/api/chat/models")).status).toBe(502);
  });

  it.each([{ pairs: 50, charactersPerMessage: 600 }, { pairs: 100, charactersPerMessage: 500 }])(
    "forwards $pairs complete Groq history pairs unchanged",
    async ({ pairs, charactersPerMessage }) => {
      const history = Array.from({ length: pairs * 2 }, (_, index) => ({
        role: index % 2 === 0 ? "user" : "assistant",
        content: "x".repeat(charactersPerMessage),
      }));
      const body = { provider: "groq", message: "Continue", previous_response_id: null, history };
      const result = await post(testApp(), body);
      expect(result.status).toBe(200);
      expect(calls[0].body).toEqual(body);
    },
  );

  it("rejects history beyond 200 messages or 100,000 characters before upstream access", async () => {
    const tooMany = Array.from({ length: 202 }, (_, index) => ({ role: index % 2 === 0 ? "user" : "assistant", content: "x" }));
    const tooLong = Array.from({ length: 10 }, (_, index) => ({ role: index % 2 === 0 ? "user" : "assistant", content: "x".repeat(index === 0 ? 10001 : 10000) }));
    const app = testApp();
    expect((await post(app, { provider: "groq", message: "Continue", history: tooMany })).status).toBe(400);
    expect((await post(app, { provider: "groq", message: "Continue", history: tooLong })).status).toBe(400);
    expect(calls).toHaveLength(0);
  });

  it("maps malformed JSON and oversized wire bodies to safe 400/413", async () => {
    const app = testApp();
    const malformed = await request(app).post("/api/chat/chat").set("Origin", ORIGIN).type("json").send('{"message":');
    const oversized = await post(app, { ...qwen(), message: "x".repeat(769 * 1024) });
    expect(malformed.status).toBe(400);
    expect(oversized.status).toBe(413);
    expect(malformed.text + oversized.text).not.toContain("SyntaxError");
    expect(calls).toHaveLength(0);
  });

  it("binds continuation to the owning session and only the latest successful Qwen response", async () => {
    const app = testApp();
    const first = await post(app, qwen());
    const id = first.body.response_id;
    expect((await post(app, qwen(id), "test-session-b")).status).toBe(409);
    const second = await post(app, qwen(id));
    expect(second.status).toBe(200);
    expect(second.body.response_id).not.toBe(id);
    expect((await post(app, qwen(id))).status).toBe(409);
    expect((await post(app, qwen(second.body.response_id))).status).toBe(200);
    expect(calls).toHaveLength(3);
  });

  it("does not advance Qwen state when the upstream returns an invalid reply", async () => {
    const app = testApp();
    const first = await post(app, qwen());
    respond = (_call, response) => json(response, { reply: "", response_id: "bad-new-id", provider: "qwen", model: "test" });
    expect((await post(app, qwen(first.body.response_id))).status).toBe(502);
    respond = (call, response) => json(response, goodReply(call));
    expect((await post(app, qwen(first.body.response_id))).status).toBe(200);
  });

  it("expires continuation after 30 minutes and allows an explicit new chat", async () => {
    const clock = vi.spyOn(Date, "now");
    let now = 10_000_000;
    clock.mockImplementation(() => now);
    const app = testApp();
    const first = await post(app, qwen());
    now += 30 * 60 * 1000 + 1;
    expect((await post(app, qwen(first.body.response_id))).status).toBe(409);
    expect((await post(app, qwen())).status).toBe(200);
  });

  it("limits upstream attempts to 10 per session per minute and resets the window", async () => {
    let now = 20_000_000;
    vi.spyOn(Date, "now").mockImplementation(() => now);
    const app = testApp();
    for (let i = 0; i < 10; i++) expect((await post(app, qwen())).status).toBe(200);
    const blocked = await post(app, qwen());
    expect(blocked.status).toBe(429);
    expect(blocked.headers["retry-after"]).toBe("60");
    expect(calls).toHaveLength(10);
    now += 60_001;
    expect((await post(app, qwen())).status).toBe(200);
  });

  it("limits all sessions together to 60 upstream attempts per minute", async () => {
    const app = testApp();
    for (let i = 0; i < 60; i++) expect((await post(app, qwen(), `session-${Math.floor(i / 10)}`)).status).toBe(200);
    expect((await post(app, qwen(), "new-session")).status).toBe(429);
    expect(calls).toHaveLength(60);
  });

  it("prevents concurrent sends from advancing the same session out of order", async () => {
    let release!: () => void;
    let started!: () => void;
    const held = new Promise<void>(resolve => { release = resolve; });
    const begun = new Promise<void>(resolve => { started = resolve; });
    respond = async (call, response) => { started(); await held; json(response, goodReply(call)); };
    const app = testApp();
    const first = post(app, qwen()).then(value => value);
    await begun;
    expect((await post(app, qwen())).status).toBe(429);
    release();
    expect((await first).status).toBe(200);
    expect(calls).toHaveLength(1);
  });

  it.each([400, 422, 429, 500, 503, 504])("sanitizes upstream status %i without exposing its body", async status => {
    respond = (_call, response) => json(response, { detail: SERVICE_KEY, prompt: "private prompt" }, status);
    const reply = await post(testApp(), qwen());
    expect(reply.status).toBe(status === 500 ? 502 : status);
    expect(reply.text).not.toContain(SERVICE_KEY);
    expect(reply.text).not.toContain("private prompt");
  });

  it("rejects overlarge upstream replies and drops unrelated fields from valid replies", async () => {
    const app = testApp();
    respond = (_call, response) => json(response, { reply: "x".repeat(140 * 1024), secret: SERVICE_KEY });
    expect((await post(app, qwen())).status).toBe(502);
    respond = (call, response) => json(response, { ...goodReply(call), secret: SERVICE_KEY });
    const reply = await post(app, qwen());
    expect(reply.status).toBe(200);
    expect(reply.body.secret).toBeUndefined();
    expect(reply.text).not.toContain(SERVICE_KEY);
  });

  it("aborts a hanging private fetch at the fixed 65-second deadline and returns safe 504", async () => {
    vi.useFakeTimers({ toFake: ["setTimeout", "clearTimeout"] });
    let started!: () => void;
    const begun = new Promise<void>(resolve => { started = resolve; });
    let aborted = false;
    vi.spyOn(globalThis, "fetch").mockImplementation((_input, init) => new Promise((_resolve, reject) => {
      init?.signal?.addEventListener("abort", () => { aborted = true; reject(new Error("private timeout detail")); }, { once: true });
      started();
    }));
    const pending = post(testApp(), qwen()).then(value => value);
    await begun;
    await vi.advanceTimersByTimeAsync(65_001);
    const reply = await pending;
    expect(aborted).toBe(true);
    expect(reply.status).toBe(504);
    expect(reply.text).not.toContain("private timeout detail");
  });
});
