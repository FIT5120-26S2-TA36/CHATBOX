/**
 * Optional, single-instance staging gateway. Not a production auth or quota system.
 * Mount at /api/chat AFTER cookieParser/sessionMiddleware, BEFORE the game JSON parser.
 */
import express, { Router, type ErrorRequestHandler, type Request, type Response } from "express";

export interface ChatGatewayConfig {
  frontendOrigin: string;
  serviceUrl: string;
  serviceKey: string;
}

type Provider = "qwen" | "groq";
type History = { role: "user" | "assistant"; content: string };
type ChatBody = { provider: Provider; message: string; previous_response_id: string | null; history: History[] };
type SessionState = { lastQwenId: string | null; expiresAt: number; attempts: number[]; inFlight: boolean };
const TTL_MS = 30 * 60 * 1000;
const WINDOW_MS = 60 * 1000;
const MAX_SESSIONS = 1000;
const TIMEOUT_MS = 65 * 1000;
const MAX_RESPONSE_BYTES = 128 * 1024;

class GatewayFailure extends Error {
  constructor(readonly status: number, readonly code: string, message: string) { super(message); }
}

function object(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function boundedText(value: unknown, maximum: number): value is string {
  return typeof value === "string" && value.length <= maximum && Boolean(value.trim());
}
function invalid(): never {
  throw new GatewayFailure(400, "INVALID_CHAT_REQUEST", "The chat request is invalid.");
}
function validateBody(value: unknown): ChatBody {
  if (!object(value) || Object.keys(value).some(key => !["provider", "message", "previous_response_id", "history"].includes(key))) invalid();
  if ((value.provider !== "qwen" && value.provider !== "groq") || !boundedText(value.message, 4000)) invalid();
  const previous = value.previous_response_id ?? null;
  if (previous !== null && !boundedText(previous, 256)) invalid();
  const suppliedHistory = value.history ?? [];
  if (!Array.isArray(suppliedHistory) || suppliedHistory.length > 200) invalid();
  const history: History[] = [];
  let characters = 0;
  for (const [index, item] of suppliedHistory.entries()) {
    if (!object(item) || Object.keys(item).some(key => !["role", "content"].includes(key)) ||
        item.role !== (index % 2 === 0 ? "user" : "assistant") || !boundedText(item.content, 12000)) invalid();
    characters += item.content.length;
    history.push({ role: item.role as History["role"], content: item.content });
  }
  if (characters > 100000 || history.length % 2 !== 0) invalid();
  if (value.provider === "qwen" && history.length !== 0) invalid();
  if (value.provider === "groq" && previous !== null) invalid();
  return { provider: value.provider, message: value.message.trim(), previous_response_id: previous, history };
}

function badUpstream(): never {
  throw new GatewayFailure(502, "CHAT_UPSTREAM_ERROR", "The chat service returned an unusable response.");
}
function validateReply(value: unknown, provider: Provider) {
  if (!object(value) || value.provider !== provider || !boundedText(value.model, 256) || !boundedText(value.reply, 12000)) badUpstream();
  if (provider === "qwen" ? !boundedText(value.response_id, 256) : value.response_id !== null) badUpstream();
  return { provider, model: value.model, reply: value.reply, response_id: value.response_id as string | null };
}
function validateModels(value: unknown) {
  if (!object(value) || !Array.isArray(value.models) || value.models.length !== 2 || !object(value.history_limits)) badUpstream();
  const models = value.models.map((item: unknown) => {
    if (!object(item) || (item.provider !== "qwen" && item.provider !== "groq") || !boundedText(item.model, 256) ||
        !boundedText(item.label, 256) || typeof item.configured !== "boolean") badUpstream();
    return { provider: item.provider, model: item.model, label: item.label, configured: item.configured };
  });
  const { messages, characters } = value.history_limits;
  if (new Set(models.map(item => item.provider)).size !== 2 || !Number.isInteger(messages) ||
      typeof messages !== "number" || messages < 2 || messages > 200 || messages % 2 !== 0 || !Number.isInteger(characters) ||
      typeof characters !== "number" || characters < 1000 || characters > 100000) badUpstream();
  return { models, history_limits: { messages, characters } };
}

async function boundedJson(response: globalThis.Response): Promise<unknown> {
  if (!/^application\/json(?:\s*;|$)/i.test(response.headers.get("content-type") ?? "") || !response.body) badUpstream();
  const reader = response.body.getReader();
  const chunks: Uint8Array[] = [];
  let length = 0;
  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      length += value.byteLength;
      if (length > MAX_RESPONSE_BYTES) {
        await reader.cancel();
        badUpstream();
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  try { return JSON.parse(Buffer.concat(chunks).toString("utf8")); } catch { return badUpstream(); }
}

function writeFailure(response: Response, error: unknown) {
  if (response.destroyed || response.writableEnded) return;
  const safe = error instanceof GatewayFailure ? error : new GatewayFailure(502, "CHAT_UNAVAILABLE", "The chat service is unavailable.");
  if (safe.status === 429) response.setHeader("Retry-After", "60");
  response.status(safe.status).json({ error: { code: safe.code, message: safe.message } });
}

export function chatRouter(config: ChatGatewayConfig): Router {
  // This factory is only called when the optional service URL is configured.
  let service: URL;
  try {
    service = new URL(config.serviceUrl);
    const origin = new URL(config.frontendOrigin);
    if (!["http:", "https:"].includes(service.protocol) || service.username || service.password || service.search || service.hash ||
        service.pathname !== "/" || !["http:", "https:"].includes(origin.protocol) || origin.origin !== config.frontendOrigin ||
        config.serviceKey.trim().length < 32 || /[\r\n]/.test(config.serviceKey)) throw new Error();
  } catch { throw new Error("Invalid server-side chat gateway configuration."); }
  const serviceKey = config.serviceKey.trim();

  const router = Router();
  const sessions = new Map<string, SessionState>();
  let globalAttempts: number[] = [];

  router.use((_request, response, next) => {
    response.setHeader("Cache-Control", "no-store");
    next();
  });
  router.use((request, response, next) => {
    const known = (request.method === "GET" && request.path === "/models") || (request.method === "POST" && request.path === "/chat");
    if (!known) { response.status(404).json({ error: { code: "NOT_FOUND", message: "Chat route not found." } }); return; }
    // The real game middleware owns this field. Never use a browser header/body session ID.
    const sessionId = (request as Request & { sessionId?: string }).sessionId;
    if (!boundedText(sessionId, 128)) { writeFailure(response, new GatewayFailure(401, "SESSION_REQUIRED", "A play session is required.")); return; }
    if (request.method === "POST") {
      if (request.get("Origin") !== config.frontendOrigin) {
        writeFailure(response, new GatewayFailure(403, "ORIGIN_REJECTED", "The request origin is not allowed.")); return;
      }
      if (!request.is("application/json")) {
        writeFailure(response, new GatewayFailure(415, "JSON_REQUIRED", "Send a JSON chat request.")); return;
      }
    }
    next();
  });
  router.use(express.json({ limit: "768kb", inflate: false }));
  const parseErrors: ErrorRequestHandler = (error, _request, response, _next) => {
    const status = error?.type === "entity.too.large" ? 413 : error?.type === "encoding.unsupported" ? 415 : 400;
    writeFailure(response, new GatewayFailure(status, "INVALID_CHAT_BODY", "The chat request body could not be accepted."));
  };
  router.use(parseErrors);

  async function upstream(request: Request, response: Response, path: "/models" | "/chat", body?: ChatBody) {
    const controller = new AbortController();
    let timedOut = false;
    const timer = setTimeout(() => { timedOut = true; controller.abort(); }, TIMEOUT_MS);
    const disconnect = () => { if (!response.writableEnded) controller.abort(); };
    response.on("close", disconnect);
    request.on("aborted", disconnect);
    try {
      const result = await fetch(new URL(path, service), {
        method: body ? "POST" : "GET",
        headers: { "X-Chat-Service-Key": serviceKey, Accept: "application/json", ...(body ? { "Content-Type": "application/json" } : {}) },
        body: body ? JSON.stringify(body) : undefined,
        redirect: "error",
        signal: controller.signal,
      });
      if (!result.ok) {
        await result.body?.cancel();
        const status = [400, 422, 429, 503, 504].includes(result.status) ? result.status : 502;
        throw new GatewayFailure(status, "CHAT_UPSTREAM_ERROR", status === 504 ? "The chat service took too long." : "The chat service could not complete the request.");
      }
      return await boundedJson(result);
    } catch (error) {
      if (timedOut) throw new GatewayFailure(504, "CHAT_TIMEOUT", "The chat service took too long.");
      if (error instanceof GatewayFailure) throw error;
      throw new GatewayFailure(502, "CHAT_UNAVAILABLE", "The chat service is unavailable.");
    } finally {
      clearTimeout(timer);
      response.off("close", disconnect);
      request.off("aborted", disconnect);
    }
  }

  router.get("/models", async (request, response) => {
    try { response.json(validateModels(await upstream(request, response, "/models"))); }
    catch (error) { writeFailure(response, error); }
  });

  router.post("/chat", async (request, response) => {
    let state: SessionState | undefined;
    let locked = false;
    try {
      const body = validateBody(request.body);
      const now = Date.now();
      for (const [id, item] of sessions) if (item.expiresAt <= now && !item.inFlight) sessions.delete(id);
      globalAttempts = globalAttempts.filter(at => at > now - WINDOW_MS);
      if (globalAttempts.length >= 60) throw new GatewayFailure(429, "CHAT_RATE_LIMIT", "Chat is busy. Try again later.");
      const sessionId = (request as Request & { sessionId: string }).sessionId;
      state = sessions.get(sessionId);
      if (!state) {
        if (sessions.size >= MAX_SESSIONS) throw new GatewayFailure(503, "CHAT_CAPACITY", "Chat is busy. Try again later.");
        state = { lastQwenId: null, expiresAt: now + TTL_MS, attempts: [], inFlight: false };
        sessions.set(sessionId, state);
      }
      state.attempts = state.attempts.filter(at => at > now - WINDOW_MS);
      if (state.inFlight || state.attempts.length >= 10) throw new GatewayFailure(429, "CHAT_RATE_LIMIT", "Wait before sending another message.");
      if (body.provider === "qwen" && body.previous_response_id !== null && body.previous_response_id !== state.lastQwenId) {
        throw new GatewayFailure(409, "CHAT_CONTINUATION_INVALID", "This conversation expired or changed. Start a new chat.");
      }
      state.attempts.push(now);
      globalAttempts.push(now);
      state.expiresAt = now + TTL_MS;
      state.inFlight = true;
      locked = true;
      const reply = validateReply(await upstream(request, response, "/chat", body), body.provider);
      // Only a complete successful response advances Qwen ownership/continuation.
      if (body.provider === "qwen") state.lastQwenId = reply.response_id;
      if (!response.destroyed) response.json(reply);
    } catch (error) { writeFailure(response, error); }
    finally { if (state && locked) state.inFlight = false; }
  });
  return router;
}
