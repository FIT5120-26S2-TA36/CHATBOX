# Reference gateway validation

Validated in an isolated scratch directory against the existing backend's dependencies; no repository source files were edited. The temporary `node_modules` symlink is test setup only and must be excluded from the handoff archive.

| Check | Result |
| --- | --- |
| `npm run typecheck` | PASS |
| `npm test` | PASS — 1 test file, 37 tests |
| Provider calls | None; fake local HTTP upstream plus a mocked hanging fetch |
| AWS/deployment changes | None |

The tests cover the 32-character minimum service key, fixed endpoint/service-key forwarding, exclusion of browser credentials, attached session requirement, Origin/JSON rejection, optional route mounting, invalid payloads, Unicode history over 32 KiB, 100-message/60,000-character model configuration, 50-pair history forwarding unchanged, the 200-message/100,000-character ceiling, invalid/odd advertised limits, malformed/oversized wire JSON, Qwen ownership/latest-ID checks, preservation on invalid responses, TTL expiry, per-session/global quotas, concurrent sends, sanitized upstream errors, bounded responses, whitelisted successful fields and the 65-second abort deadline.

Fresh command output is saved in `evidence/typecheck.txt` and `evidence/tests.txt`.

This is a reference implementation for one staging Node process. It does not prove real provider compatibility, Python header validation, production proxy/cookie behavior, IP-based abuse protection, multi-instance consistency, spend caps, deployed TLS, or cancellation of billable work inside Python.

To reuse the tests in the existing backend, copy `src/routes/chat.ts` and `tests/chatGateway.test.ts` into their corresponding paths and run the existing typecheck/test scripts. The package/tsconfig in this reference directory are only a small test harness; they do not add dependencies or replace the application's own configuration.
