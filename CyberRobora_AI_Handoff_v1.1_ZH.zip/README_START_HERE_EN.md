# CyberRobora AI handoff v1.1
Read docs/01_Installation_Report_EN.md first, then the change report and engineering guide.

This package adds a configurable Groq history window (default 50 exchanges / 60,000 historical characters), a deployable Python source folder and a reference Node gateway. It is an integration handoff, not a production deployment or a trained-model file.

- Model owner: chat-service/ and docs/Current_Question_Context_CONTRACT.md.
- Frontend developer: frontend/ for a runnable snapshot; patches/ for a selective official-repository merge.
- Backend developer: backend-integration/, chat-service/ and the engineering guide.
- Test owner: evidence/ and docs/Smoke_Test_Checklist.md.

Do not replace a whole official repository with this mixed experiment snapshot. Preserve the team's game code, CI, docs and LFS setup. No production credentials are included. Provider keys are set only in Python hosting settings. CHAT_SERVICE_KEY is shared privately by Node/Python.

Current-question database context, learner profiling, recommendation, persistent conversation storage and cloud rollout are NOT included. A larger context window is not lossless permanent memory.
