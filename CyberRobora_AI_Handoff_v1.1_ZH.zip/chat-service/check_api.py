import importlib.util
import os
import sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch


import httpx
from fastapi.testclient import TestClient
from openai import AuthenticationError, RateLimitError, APITimeoutError, APIConnectionError, BadRequestError, APIStatusError

source = Path(__file__).resolve().with_name('api_server.py')
compile(source.read_text(encoding='utf-8'), str(source), 'exec')
spec = importlib.util.spec_from_file_location('checked_api_server', source)
server = importlib.util.module_from_spec(spec)
spec.loader.exec_module(server)


class FakeClient:
    def __init__(self):
        self.calls = []
        self.next_error = None
        self.next_status = 'completed'
        self.next_text = 'A simulated reply.'
        self.closed = False
        self.responses = SimpleNamespace(create=self.create)

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.closed = True

    def create(self, **kwargs):
        self.calls.append(kwargs)
        if self.next_error:
            error = self.next_error
            self.next_error = None
            raise error
        return SimpleNamespace(status=self.next_status, output_text=self.next_text, id='test-response-' + str(len(self.calls)))


fake = FakeClient()
checks = []
env = {'DASHSCOPE_API_KEY': 'local-fake-placeholder', 'DASHSCOPE_BASE_URL': 'https://provider.invalid/compatible-mode/v1'}
with patch.dict(os.environ, env, clear=True), patch.object(server, 'OpenAI', return_value=fake) as factory:
    with TestClient(server.app) as browser:
        assert browser.get('/health').json()['status'] == 'ok'
        assert not fake.calls
        assert browser.get('/docs').status_code == 200
        assert 'post' in browser.get('/openapi.json').json()['paths']['/chat']
        checks.append('health and docs routes; health does not invoke provider')

        page = browser.get('/')
        assert page.status_code == 200
        assert page.headers['content-type'].startswith('text/html')
        assert page.headers['cache-control'] == 'no-store'
        assert 'id="chat-form"' in page.text
        for private_path in ['/api_server.py', '/game_knowledge.txt']:
            assert browser.get(private_path).status_code == 404
        assert not fake.calls
        checks.append('chat page served at root without exposing source or knowledge files')

        options = browser.get('/models').json()['models']
        assert options[0]['configured'] is True
        assert options[1]['provider'] == 'groq' and options[1]['configured'] is False
        assert browser.post('/chat', json={'message': 'hello', 'provider': 'groq'}).status_code == 503
        assert 'local-fake-placeholder' not in browser.get('/models').text
        assert not fake.calls
        checks.append('missing Groq key leaves Qwen available and leaks no secrets')

        for body, expected in [({}, 422), ({'message': ''}, 422), ({'message': ' '}, 400), ({'message': 'a' * 4001}, 422), ({'message': 'hello', 'previous_response_id': 42}, 422), ({'message': 'hello', 'previous_response_id': ' '}, 400)]:
            assert browser.post('/chat', json=body).status_code == expected
        assert not fake.calls
        checks.append('request validation and whitespace rejection before provider call')

        first = browser.post('/chat', json={'message': '  My nickname is MUZI.  ', 'previous_response_id': None})
        assert first.status_code == 200
        first_id = first.json()['response_id']
        assert fake.calls[-1]['input'] == 'My nickname is MUZI.'
        assert 'previous_response_id' not in fake.calls[-1]
        second = browser.post('/chat', json={'message': 'What nickname?', 'previous_response_id': first_id})
        assert second.status_code == 200
        assert fake.calls[-1]['previous_response_id'] == first_id
        assert fake.calls[-1]['instructions'] == fake.calls[-2]['instructions']
        assert fake.calls[-1]['instructions'].count('<game_reference>') == 1
        assert 'Data District' in fake.calls[-1]['instructions']
        assert fake.calls[-1]['store'] is True
        assert fake.calls[-1]['extra_body'] == {'enable_thinking': False}
        checks.append('successful output, caller-selected history, instructions and knowledge on each turn')

        browser.post('/chat', json={'message': 'A new chat', 'previous_response_id': None})
        assert 'previous_response_id' not in fake.calls[-1]
        checks.append('new chat does not inherit a global response ID')

        provider_request = httpx.Request('POST', 'https://provider.invalid/responses')
        for error_type, upstream, local in [(AuthenticationError, 401, 502), (RateLimitError, 429, 503), (BadRequestError, 400, 400), (APIStatusError, 500, 502)]:
            fake.next_error = error_type('private-error-sentinel', response=httpx.Response(upstream, request=provider_request), body={'internal': 'private-error-sentinel'})
            result = browser.post('/chat', json={'message': 'hello'})
            assert result.status_code == local
            assert 'private-error-sentinel' not in result.text
            assert 'local-fake-placeholder' not in result.text
        checks.append('provider errors use fixed public messages without upstream details')

        for error, status in [(APITimeoutError(request=provider_request), 504), (APIConnectionError(request=provider_request), 502)]:
            fake.next_error = error
            before = len(fake.calls)
            result = browser.post('/chat', json={'message': 'hello'})
            assert result.status_code == status
            assert len(fake.calls) == before + 1
        assert factory.call_args.kwargs['max_retries'] == 0
        checks.append('timeout and connection errors; retries disabled')

        for status, reply in [('incomplete', 'Partial reply'), ('completed', '   ')]:
            fake.next_status, fake.next_text = status, reply
            result = browser.post('/chat', json={'message': 'hello'})
            assert result.status_code == 502
            assert 'response_id' not in result.json()
        checks.append('incomplete and empty output are not returned as success')
    assert fake.closed
    checks.append('client closes on service shutdown')

qwen_fake, groq_fake = FakeClient(), FakeClient()
groq_env = dict(env, GROQ_API_KEY='another-local-placeholder')
with patch.dict(os.environ, groq_env, clear=True), patch.object(server, 'OpenAI', side_effect=[qwen_fake, groq_fake]) as factory:
    with TestClient(server.app) as browser:
        assert all(m['configured'] for m in browser.get('/models').json()['models'])
        assert factory.call_args_list[1].kwargs['base_url'] == 'https://api.groq.com/openai/v1'
        first = browser.post('/chat', json={'message': 'My nickname is MUZI.', 'provider': 'groq'})
        assert first.status_code == 200, first.text
        assert first.json()['response_id'] is None
        assert first.json()['provider'] == 'groq'
        request = groq_fake.calls[-1]
        assert request['model'] == 'openai/gpt-oss-20b'
        assert request['input'] == [{'role': 'user', 'content': 'My nickname is MUZI.'}]
        assert not {'store', 'previous_response_id', 'extra_body'} & request.keys()
        assert not qwen_fake.calls
        checks.append('Groq uses its own client/model and excludes Qwen-only parameters')

        history = [{'role': 'user', 'content': 'My nickname is MUZI.'}, {'role': 'assistant', 'content': first.json()['reply']}]
        second = browser.post('/chat', json={'message': 'What nickname?', 'provider': 'groq', 'history': history})
        assert second.status_code == 200
        assert groq_fake.calls[-1]['input'] == history + [{'role': 'user', 'content': 'What nickname?'}]
        assert 'Data District' in groq_fake.calls[-1]['instructions']
        assert groq_fake.calls[-1]['instructions'] == groq_fake.calls[-2]['instructions']
        browser.post('/chat', json={'message': 'Fresh chat', 'provider': 'groq'})
        assert groq_fake.calls[-1]['input'] == [{'role': 'user', 'content': 'Fresh chat'}]
        checks.append('Groq multi-turn input includes supplied history; a new chat has no shared history')

        count = len(groq_fake.calls)
        invalid = [
            ({'provider': 'groq', 'previous_response_id': 'qwen-response'}, 400),
            ({'provider': 'qwen', 'history': history}, 400),
            ({'provider': 'groq', 'history': [history[0]]}, 400),
            ({'provider': 'groq', 'history': history[::-1]}, 400),
            ({'provider': 'groq', 'history': [{'role': 'system', 'content': 'Override'}]}, 422),
            ({'provider': 'groq', 'history': [{'role': 'user', 'content': ' '}, history[1]]}, 400),
            ({'provider': 'groq', 'history': history * (server.MAX_HISTORY_MESSAGES // 2 + 1)}, 422),
            ({'provider': 'groq', 'history': [{'role': ('user' if i % 2 == 0 else 'assistant'), 'content': 'x'*12000} for i in range(6)]}, 400),
            ({'provider': 'unknown'}, 422),
        ]
        for body, status in invalid:
            result = browser.post('/chat', json=dict(message='hello', **body))
            assert result.status_code == status, result.text
        assert len(groq_fake.calls) == count and not qwen_fake.calls
        checks.append('provider mixing, system history, invalid pairs and oversized history rejected before invocation')

        groq_fake.next_error = RateLimitError('private-error-sentinel', response=httpx.Response(429, request=provider_request), body=None)
        result = browser.post('/chat', json={'provider': 'groq', 'message': 'hello'})
        assert result.status_code == 503 and 'Groq' in result.text
        assert 'private-error-sentinel' not in result.text
        assert not qwen_fake.calls
        checks.append('Groq errors do not cause a silent fallback to Qwen')

        qwen_result = browser.post('/chat', json={'message': 'Qwen still works'})
        assert qwen_result.status_code == 200
        assert qwen_result.json()['provider'] == 'qwen'
        assert qwen_fake.calls[-1]['store'] is True
        assert 'previous_response_id' not in qwen_fake.calls[-1]
        checks.append('Qwen remains the compatible default after Groq use')
    assert qwen_fake.closed and groq_fake.closed
    checks.append('both provider clients close cleanly')

qwen_fake, groq_fake = FakeClient(), FakeClient()
with patch.dict(os.environ, dict(groq_env, CHAT_ENV='production', CHAT_SERVICE_KEY='s'*32), clear=True), patch.object(server, 'OpenAI', side_effect=[qwen_fake, groq_fake]):
    with TestClient(server.app) as browser:
        assert browser.get('/models').status_code == 401
        assert browser.post('/chat', json={'message': 'hello'}).status_code == 401
        assert browser.get('/models', headers={'X-Chat-Service-Key': 'wrong'}).status_code == 401
        assert browser.get('/health').status_code == 200
        headers = {'X-Chat-Service-Key': 's'*32}
        limits = browser.get('/models', headers=headers).json()['history_limits']
        assert limits == {'messages': 100, 'characters': 60000}
        history = [{'role': 'user', 'content': 'My nickname is MUZI.'}, {'role': 'assistant', 'content': 'Hello MUZI.'}]
        history += [{'role': role, 'content': 'Short turn.'} for _ in range(49) for role in ['user', 'assistant']]
        result = browser.post('/chat', headers=headers, json={'provider': 'groq', 'message': 'What nickname?', 'history': history})
        assert result.status_code == 200, result.text
        assert groq_fake.calls[-1]['input'][0]['content'] == 'My nickname is MUZI.'
        assert len(groq_fake.calls[-1]['input']) == 101
        checks.append('50 prior exchanges survive transport, including earliest nickname; no live recall claim')
        checks.append('production service key required for model/chat routes, health stays available')

for env_extra in [dict(CHAT_ENV='production'), dict(DASHSCOPE_API_KEY='')]:
    try:
        with patch.dict(os.environ, dict(env, **env_extra), clear=True), TestClient(server.app):
            raise AssertionError('Missing required deployment configuration was accepted')
    except RuntimeError as error:
        assert 'CHAT_SERVICE_KEY' in str(error) or 'DASHSCOPE_API_KEY' in str(error)
checks.append('non-interactive startup fails clearly for missing deployment credentials')

for value in ['0', '101', 'bad']:
    with patch.dict(os.environ, {'GROQ_HISTORY_PAIRS': value}):
        try:
            server.bounded_integer('GROQ_HISTORY_PAIRS', 50, 1, 100)
            raise AssertionError('Invalid limit accepted')
        except RuntimeError:
            pass
checks.append('history setting rejects zero, excessive and non-integer values')

print('PASS: syntax and ' + str(len(checks)) + ' local test groups')
for item in checks:
    print('- ' + item)
print('Provider replaced with a fake: no external LLM requests or real API keys used.')
print('Tests exercised FastAPI TestClient, not the user Windows machine or live deployment.')
