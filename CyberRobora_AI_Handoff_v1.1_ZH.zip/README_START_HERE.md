# CyberRobora AI 交接工程包 v1.1（中文版）

请先阅读 [安装报告](docs/01_Installation_Report_ZH.md)，再阅读 [代码变更报告](docs/02_Code_Change_Report_ZH.md) 和 [工程集成指南](docs/03_Engineering_Integration_Guide_ZH.md)。三份对应的中文 PDF 也放在 docs/ 目录中。

该工程包提供可配置的 Groq 历史记录窗口（默认保留 50 轮问答／60,000 个历史字符）、可部署的 Python 源码目录，以及供集成参考的 Node 网关。这是一套交接资料，并不表示已完成正式部署，也不是自行训练好的模型文件。

- 模型负责人：阅读 chat-service/ 和 [当前题目上下文接口约定](docs/Current_Question_Context_CONTRACT_ZH.md)。
- 前端同学：frontend/ 提供可运行的代码快照；patches/ 用于有选择地将改动合并到正式仓库。参见 [前端说明](frontend/README_ZH.md)。
- 后端同学：阅读 backend-integration/、chat-service/ 和工程集成指南；参见 [参考网关验证说明](backend-integration/VALIDATION_ZH.md)。
- 测试负责人：阅读 evidence/、[验证结果说明](evidence/VERIFICATION_ZH.md) 和 [冒烟测试清单](docs/Smoke_Test_Checklist_ZH.md)。

不要用这份混合实验快照直接覆盖整个正式仓库。应保留团队现有游戏代码、CI（持续集成）、文档和 Git LFS 配置。工程包不包含生产环境凭据。模型服务商的密钥仅设置在 Python 托管环境中，CHAT_SERVICE_KEY 则由 Node 和 Python 私下共享。

**工程包尚未包含：** 当前题目的数据库上下文接入、学习者画像、题目推荐、聊天记录持久化存储，以及云端正式上线。扩大上下文窗口不等于获得不会丢失信息的永久记忆。

本包为 v1.1 的中文交接版。代码、接口名称、配置项、补丁和原始测试日志保持原样；中文说明以 _ZH 命名，英文说明保留供对照。原入口文件保存在 README_START_HERE_EN.md。本次翻译没有新增功能或重新执行模型、集成与部署测试。
